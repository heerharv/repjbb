import time
import threading
import schedule
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any
from database import RiskMetrics, store_analysis_results
from data_analyzer import DataAnalyzer
import requests
from requests.auth import HTTPBasicAuth
import os

class RiskScheduler:
    """Automated scheduler for risk calculations and analysis"""
    
    def __init__(self, risk_engine):
        self.risk_engine = risk_engine
        self.data_analyzer = DataAnalyzer()
        self.risk_metrics = RiskMetrics()
        self.is_running = False
        self.scheduler_thread = None
        
        # JIRA Configuration
        self.jira_domain = os.environ.get("JIRA_DOMAIN", "uncia-team-vmevzjmu.atlassian.net")
        self.jira_email = os.environ.get("JIRA_EMAIL", "heerha@uncia.ai")
        self.jira_api_token = os.environ.get("JIRA_API_TOKEN", "ATATT3xFfGF02OVl2RLVinvafOJwvPadlqht-3HJ_MgBlv5RsOyvFS4cK096yscLLJlu3FurBnJ7vdPFzcb6mcRn_PEOstXoTMFnvNu7B6yyY56sFQ7bCdJTkrWN8_4vmdFhLriUPNoHalA1RYQosGN-Hvsy2NyseSbK1zET-FR_bZ0xd7WFKa8=06DE82DA")
        
        # Configure scheduled tasks
        self._setup_schedules()
        
        logging.info("Risk scheduler initialized")
    
    def _setup_schedules(self):
        """Setup scheduled tasks"""
        # Daily comprehensive analysis at 6 AM
        schedule.every().day.at("06:00").do(self._run_daily_analysis)
        
        # Hourly quick risk checks during business hours
        for hour in range(9, 18):  # 9 AM to 5 PM
            schedule.every().day.at(f"{hour:02d}:00").do(self._run_hourly_checks)
        
        # Weekly deep analysis on Mondays at 7 AM
        schedule.every().monday.at("07:00").do(self._run_weekly_analysis)
        
        # Data cleanup monthly
        schedule.every().month.do(self._cleanup_old_data)
        
        logging.info("Scheduled tasks configured")
    
    def start(self):
        """Start the scheduler"""
        if self.is_running:
            logging.warning("Scheduler is already running")
            return
        
        self.is_running = True
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self.scheduler_thread.start()
        
        logging.info("Risk scheduler started")
    
    def stop(self):
        """Stop the scheduler"""
        self.is_running = False
        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=5)
        
        logging.info("Risk scheduler stopped")
    
    def _scheduler_loop(self):
        """Main scheduler loop"""
        while self.is_running:
            try:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
            except Exception as e:
                logging.error(f"Scheduler loop error: {str(e)}")
                time.sleep(300)  # Wait 5 minutes on error
    
    def _run_daily_analysis(self):
        """Run daily comprehensive analysis for all active projects"""
        try:
            logging.info("Starting daily comprehensive analysis")
            
            # Get list of active projects
            active_projects = self._get_active_projects()
            
            for project_key in active_projects:
                try:
                    # Get project data
                    project_data = self._fetch_project_data(project_key)
                    if not project_data:
                        continue
                    
                    # Run comprehensive risk analysis
                    analysis_results = self.risk_engine.analyze_project_risks(project_data)
                    
                    # Store results in database
                    store_analysis_results(project_key, analysis_results)
                    
                    # Generate and store specific insights
                    self._generate_daily_insights(project_key, analysis_results)
                    
                    logging.info(f"Daily analysis completed for project {project_key}")
                    
                except Exception as e:
                    logging.error(f"Daily analysis failed for project {project_key}: {str(e)}")
                    continue
                
                # Small delay between projects to avoid API rate limits
                time.sleep(2)
            
            logging.info("Daily comprehensive analysis completed")
            
        except Exception as e:
            logging.error(f"Daily analysis error: {str(e)}")
    
    def _run_hourly_checks(self):
        """Run hourly quick risk checks"""
        try:
            logging.info("Starting hourly risk checks")
            
            # Get projects with recent activity
            active_projects = self._get_recently_active_projects()
            
            for project_key in active_projects:
                try:
                    # Get project data
                    project_data = self._fetch_project_data(project_key)
                    if not project_data:
                        continue
                    
                    # Run quick health check
                    health_analysis = self.data_analyzer.analyze_project_health(project_data['issues'])
                    
                    # Check for immediate risks
                    immediate_risks = self._identify_immediate_risks(health_analysis)
                    
                    # Store urgent insights
                    for risk in immediate_risks:
                        self._store_urgent_insight(project_key, risk)
                    
                    # Store key metrics
                    self._store_hourly_metrics(project_key, health_analysis)
                    
                except Exception as e:
                    logging.error(f"Hourly check failed for project {project_key}: {str(e)}")
                    continue
            
            logging.debug("Hourly risk checks completed")
            
        except Exception as e:
            logging.error(f"Hourly checks error: {str(e)}")
    
    def _run_weekly_analysis(self):
        """Run weekly deep analysis and trend identification"""
        try:
            logging.info("Starting weekly deep analysis")
            
            active_projects = self._get_active_projects()
            
            for project_key in active_projects:
                try:
                    # Get historical data for trend analysis
                    historical_metrics = self.risk_metrics.get_project_metrics(project_key, days_back=30)
                    
                    if len(historical_metrics) < 5:
                        continue  # Need minimum data for trend analysis
                    
                    # Analyze trends
                    trends = self._analyze_weekly_trends(project_key, historical_metrics)
                    
                    # Store trend analysis
                    self.risk_metrics.store_trend(
                        project_key=project_key,
                        trend_type='weekly_analysis',
                        time_period='7_days',
                        trend_data=trends,
                        trend_direction=trends.get('overall_direction', 'stable'),
                        trend_strength=trends.get('trend_strength', 0.5)
                    )
                    
                    # Generate predictive insights
                    predictions = self._generate_weekly_predictions(project_key, trends)
                    
                    # Store predictions
                    self.risk_metrics.store_prediction(
                        project_key=project_key,
                        prediction_type='weekly_forecast',
                        prediction_data=predictions,
                        prediction_date=datetime.now() + timedelta(days=7)
                    )
                    
                    logging.info(f"Weekly analysis completed for project {project_key}")
                    
                except Exception as e:
                    logging.error(f"Weekly analysis failed for project {project_key}: {str(e)}")
                    continue
            
            logging.info("Weekly deep analysis completed")
            
        except Exception as e:
            logging.error(f"Weekly analysis error: {str(e)}")
    
    def _cleanup_old_data(self):
        """Clean up old data beyond retention period"""
        try:
            logging.info("Starting monthly data cleanup")
            
            # Clean up data older than 90 days
            self.risk_metrics.cleanup_old_data(days_to_keep=90)
            
            # Get database stats
            stats = self.risk_metrics.get_database_stats()
            logging.info(f"Database stats after cleanup: {stats}")
            
            logging.info("Monthly data cleanup completed")
            
        except Exception as e:
            logging.error(f"Data cleanup error: {str(e)}")
    
    def _get_active_projects(self) -> List[str]:
        """Get list of active projects from JIRA"""
        try:
            url = f"https://{self.jira_domain}/rest/api/3/project"
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            auth = HTTPBasicAuth(self.jira_email, self.jira_api_token)
            
            response = requests.get(url, headers=headers, auth=auth, timeout=30)
            
            if response.status_code == 200:
                projects = response.json()
                # Return project keys for active projects
                return [project['key'] for project in projects if project.get('archived', False) is False]
            else:
                logging.error(f"Failed to fetch projects: {response.status_code}")
                return []
                
        except Exception as e:
            logging.error(f"Error fetching active projects: {str(e)}")
            return []
    
    def _get_recently_active_projects(self) -> List[str]:
        """Get projects with recent activity (last 24 hours)"""
        try:
            # For now, return all active projects
            # In a real implementation, you would query for projects with recent updates
            active_projects = self._get_active_projects()
            
            # Filter to projects with recent database activity
            recent_projects = []
            for project_key in active_projects:
                recent_metrics = self.risk_metrics.get_project_metrics(project_key, days_back=1)
                if recent_metrics or len(recent_projects) < 5:  # Limit to top 5 for hourly checks
                    recent_projects.append(project_key)
                    if len(recent_projects) >= 5:
                        break
            
            return recent_projects
            
        except Exception as e:
            logging.error(f"Error getting recently active projects: {str(e)}")
            return []
    
    def _fetch_project_data(self, project_key: str) -> Dict[str, Any]:
        """Fetch comprehensive project data from JIRA"""
        try:
            # Get project issues
            search_url = f"https://{self.jira_domain}/rest/api/3/search"
            
            params = {
                "jql": f"project = {project_key} ORDER BY updated DESC",
                "maxResults": 1000,
                "fields": [
                    "summary", "description", "status", "assignee", "reporter",
                    "priority", "issuetype", "created", "updated", "labels",
                    "components", "fixVersions", "resolution", "resolutiondate",
                    "worklog", "comment", "progress", "timeestimate", "timespent",
                    "duedate", "customfield_10016", "customfield_10020"
                ]
            }
            
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            auth = HTTPBasicAuth(self.jira_email, self.jira_api_token)
            
            response = requests.get(search_url, headers=headers, auth=auth, params=params, timeout=30)
            
            if response.status_code == 200:
                issues_data = response.json()
                
                # Process issues data
                processed_issues = []
                for issue in issues_data.get('issues', []):
                    fields = issue.get('fields', {})
                    
                    processed_issue = {
                        "key": issue.get('key'),
                        "id": issue.get('id'),
                        "summary": fields.get('summary'),
                        "description": fields.get('description'),
                        "status": {
                            "name": fields.get('status', {}).get('name'),
                            "category": fields.get('status', {}).get('statusCategory', {}).get('name')
                        },
                        "assignee": {
                            "name": fields.get('assignee', {}).get('displayName') if fields.get('assignee') else "Unassigned",
                            "email": fields.get('assignee', {}).get('emailAddress') if fields.get('assignee') else None
                        },
                        "reporter": {
                            "name": fields.get('reporter', {}).get('displayName') if fields.get('reporter') else None,
                            "email": fields.get('reporter', {}).get('emailAddress') if fields.get('reporter') else None
                        },
                        "priority": {
                            "name": fields.get('priority', {}).get('name') if fields.get('priority') else None,
                            "iconUrl": fields.get('priority', {}).get('iconUrl') if fields.get('priority') else None
                        },
                        "issuetype": {
                            "name": fields.get('issuetype', {}).get('name'),
                            "iconUrl": fields.get('issuetype', {}).get('iconUrl')
                        },
                        "created": fields.get('created'),
                        "updated": fields.get('updated'),
                        "labels": fields.get('labels', []),
                        "components": [comp.get('name') for comp in fields.get('components', [])],
                        "fixVersions": [version.get('name') for version in fields.get('fixVersions', [])],
                        "resolution": fields.get('resolution', {}).get('name') if fields.get('resolution') else None,
                        "resolutiondate": fields.get('resolutiondate'),
                        "progress": fields.get('progress', {}),
                        "timeestimate": fields.get('timeestimate'),
                        "timespent": fields.get('timespent'),
                        "duedate": fields.get('duedate'),
                        "storypoints": fields.get('customfield_10016'),
                        "sprint": fields.get('customfield_10020')
                    }
                    processed_issues.append(processed_issue)
                
                return {
                    "project_key": project_key,
                    "issues": processed_issues,
                    "total_issues": issues_data.get('total', 0)
                }
            else:
                logging.error(f"Failed to fetch project data for {project_key}: {response.status_code}")
                return None
                
        except Exception as e:
            logging.error(f"Error fetching project data for {project_key}: {str(e)}")
            return None
    
    def _generate_daily_insights(self, project_key: str, analysis_results: Dict):
        """Generate and store daily insights"""
        try:
            # Overall risk level insight
            risk_level = analysis_results.get('risk_level', 'medium')
            if risk_level in ['high', 'critical']:
                self.risk_metrics.store_insight(
                    project_key=project_key,
                    insight_type='daily_risk_alert',
                    title=f'High Risk Detected: {risk_level.title()}',
                    description=f'Project {project_key} shows {risk_level} risk level in daily analysis',
                    severity=risk_level,
                    recommendations=['Review risk mitigation strategies', 'Consider resource reallocation', 'Increase monitoring frequency']
                )
            
            # Say-Do ratio insight
            say_do_data = analysis_results.get('say_do_ratio', {})
            if isinstance(say_do_data, dict):
                ratio = say_do_data.get('overall_ratio', 0)
                if ratio < 70:
                    self.risk_metrics.store_insight(
                        project_key=project_key,
                        insight_type='delivery_performance',
                        title='Low Say-Do Ratio Detected',
                        description=f'Project delivery ratio is {ratio:.1f}%, below target of 80%',
                        severity='high' if ratio < 50 else 'medium',
                        recommendations=['Improve estimation accuracy', 'Review scope management', 'Enhance stakeholder communication']
                    )
            
            # Timeline variance insight
            timeline_data = analysis_results.get('timeline_variance', {})
            if isinstance(timeline_data, dict):
                variance_pct = timeline_data.get('variance_percentage', 0)
                if variance_pct > 20:
                    self.risk_metrics.store_insight(
                        project_key=project_key,
                        insight_type='timeline_variance',
                        title='Significant Timeline Variance',
                        description=f'Project timeline variance is {variance_pct:.1f}%, indicating potential delays',
                        severity='high' if variance_pct > 40 else 'medium',
                        recommendations=['Review project schedule', 'Identify bottlenecks', 'Consider scope adjustments']
                    )
            
        except Exception as e:
            logging.error(f"Error generating daily insights for {project_key}: {str(e)}")
    
    def _identify_immediate_risks(self, health_analysis: Dict) -> List[Dict]:
        """Identify immediate risks requiring attention"""
        immediate_risks = []
        
        try:
            # Check risk indicators
            risk_indicators = health_analysis.get('risk_indicators', [])
            for indicator in risk_indicators:
                if indicator.get('severity') == 'high':
                    immediate_risks.append({
                        'type': 'immediate_risk',
                        'title': f"Urgent: {indicator.get('type', 'Unknown').replace('_', ' ').title()}",
                        'description': indicator.get('description', 'High severity risk detected'),
                        'severity': 'critical',
                        'recommendations': ['Immediate attention required', 'Review and mitigate ASAP']
                    })
            
            # Check overall health score
            health_score = health_analysis.get('overall_health_score', 0.5)
            if health_score < 0.3:
                immediate_risks.append({
                    'type': 'health_critical',
                    'title': 'Critical Project Health',
                    'description': f'Project health score is {health_score:.2f}, indicating critical issues',
                    'severity': 'critical',
                    'recommendations': ['Emergency project review', 'Stakeholder escalation', 'Resource intervention']
                })
            
        except Exception as e:
            logging.error(f"Error identifying immediate risks: {str(e)}")
        
        return immediate_risks
    
    def _store_urgent_insight(self, project_key: str, risk: Dict):
        """Store urgent insight in database"""
        try:
            self.risk_metrics.store_insight(
                project_key=project_key,
                insight_type=risk['type'],
                title=risk['title'],
                description=risk['description'],
                severity=risk['severity'],
                recommendations=risk.get('recommendations', [])
            )
        except Exception as e:
            logging.error(f"Error storing urgent insight: {str(e)}")
    
    def _store_hourly_metrics(self, project_key: str, health_analysis: Dict):
        """Store key metrics from hourly analysis"""
        try:
            # Store overall health score
            health_score = health_analysis.get('overall_health_score', 0)
            self.risk_metrics.store_project_metric(
                project_key=project_key,
                metric_name='health_score',
                metric_value=health_score
            )
            
            # Store velocity metrics
            velocity_analysis = health_analysis.get('velocity_analysis', {})
            if isinstance(velocity_analysis, dict):
                avg_velocity = velocity_analysis.get('average_velocity', 0)
                self.risk_metrics.store_project_metric(
                    project_key=project_key,
                    metric_name='velocity',
                    metric_value=avg_velocity
                )
            
            # Store quality score
            quality_metrics = health_analysis.get('quality_metrics', {})
            if isinstance(quality_metrics, dict):
                quality_score = quality_metrics.get('quality_score', 0)
                self.risk_metrics.store_project_metric(
                    project_key=project_key,
                    metric_name='quality_score',
                    metric_value=quality_score
                )
            
        except Exception as e:
            logging.error(f"Error storing hourly metrics: {str(e)}")
    
    def _analyze_weekly_trends(self, project_key: str, historical_metrics: List[Dict]) -> Dict[str, Any]:
        """Analyze weekly trends from historical data"""
        try:
            trends = {
                'health_trend': 'stable',
                'velocity_trend': 'stable',
                'quality_trend': 'stable',
                'overall_direction': 'stable',
                'trend_strength': 0.5
            }
            
            # Group metrics by type
            metrics_by_type = {}
            for metric in historical_metrics:
                metric_name = metric['metric_name']
                if metric_name not in metrics_by_type:
                    metrics_by_type[metric_name] = []
                metrics_by_type[metric_name].append({
                    'value': metric['metric_value'],
                    'date': metric['measurement_date']
                })
            
            # Analyze trends for each metric type
            trend_scores = []
            
            for metric_name, values in metrics_by_type.items():
                if len(values) >= 3:  # Need minimum data points
                    # Sort by date
                    values.sort(key=lambda x: x['date'])
                    
                    # Calculate trend
                    recent_values = [v['value'] for v in values[-3:]]
                    older_values = [v['value'] for v in values[:-3]] if len(values) > 3 else [values[0]['value']]
                    
                    recent_avg = sum(recent_values) / len(recent_values)
                    older_avg = sum(older_values) / len(older_values)
                    
                    if recent_avg > older_avg * 1.1:
                        trend_direction = 'improving'
                        trend_score = 0.7
                    elif recent_avg < older_avg * 0.9:
                        trend_direction = 'declining'
                        trend_score = 0.3
                    else:
                        trend_direction = 'stable'
                        trend_score = 0.5
                    
                    trends[f'{metric_name}_trend'] = trend_direction
                    trend_scores.append(trend_score)
            
            # Calculate overall trend
            if trend_scores:
                avg_trend_score = sum(trend_scores) / len(trend_scores)
                trends['trend_strength'] = avg_trend_score
                
                if avg_trend_score > 0.6:
                    trends['overall_direction'] = 'improving'
                elif avg_trend_score < 0.4:
                    trends['overall_direction'] = 'declining'
                else:
                    trends['overall_direction'] = 'stable'
            
            return trends
            
        except Exception as e:
            logging.error(f"Error analyzing weekly trends: {str(e)}")
            return {'overall_direction': 'stable', 'trend_strength': 0.5}
    
    def _generate_weekly_predictions(self, project_key: str, trends: Dict) -> Dict[str, Any]:
        """Generate weekly predictions based on trends"""
        try:
            predictions = {
                'next_week_health_forecast': 'stable',
                'risk_escalation_probability': 0.3,
                'recommended_actions': [],
                'confidence_level': 0.7
            }
            
            overall_direction = trends.get('overall_direction', 'stable')
            trend_strength = trends.get('trend_strength', 0.5)
            
            # Predict next week's health
            if overall_direction == 'declining':
                predictions['next_week_health_forecast'] = 'declining'
                predictions['risk_escalation_probability'] = min(0.8, 0.4 + trend_strength * 0.4)
                predictions['recommended_actions'].extend([
                    'Increase monitoring frequency',
                    'Review resource allocation',
                    'Stakeholder communication'
                ])
            elif overall_direction == 'improving':
                predictions['next_week_health_forecast'] = 'improving'
                predictions['risk_escalation_probability'] = max(0.1, 0.3 - trend_strength * 0.2)
                predictions['recommended_actions'].append('Continue current practices')
            
            # Adjust confidence based on data quality
            if trend_strength > 0.7 or trend_strength < 0.3:
                predictions['confidence_level'] = 0.8  # Strong trends are more predictable
            else:
                predictions['confidence_level'] = 0.6  # Weak trends are less predictable
            
            return predictions
            
        except Exception as e:
            logging.error(f"Error generating weekly predictions: {str(e)}")
            return {'next_week_health_forecast': 'stable', 'confidence_level': 0.5}

def start_scheduler(risk_engine):
    """Start the automated risk scheduler"""
    try:
        scheduler = RiskScheduler(risk_engine)
        scheduler.start()
        
        logging.info("Automated risk scheduler started successfully")
        return scheduler
        
    except Exception as e:
        logging.error(f"Failed to start scheduler: {str(e)}")
        return None
