import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingClassifier, IsolationForest
from sklearn.linear_model import LinearRegression, SGDRegressor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error, accuracy_score, r2_score
from sklearn.cluster import KMeans
from datetime import datetime, timedelta
import joblib
import logging
from typing import Dict, List, Any, Optional, Tuple
import threading
import time
import warnings
import os
warnings.filterwarnings('ignore')

class RiskPredictor:
    """Advanced Machine Learning models for real-time risk prediction and project analytics"""
    
    def __init__(self):
        self.completion_model = None
        self.cost_model = None
        self.quality_model = None
        self.timeline_model = None
        self.anomaly_detector = None
        self.clustering_model = None
        self.online_model = None  # For real-time updates
        
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.is_trained = False
        self.model_performance = {}
        self.training_history = []
        self.real_time_buffer = []
        self.retrain_threshold = 0.1  # Retrain if performance drops by 10%
        self.min_samples_retrain = 50
        
        # Real-time learning lock
        self._training_lock = threading.Lock()
        self._last_retrain = datetime.now()
        self._retrain_interval = timedelta(hours=6)  # Minimum time between retrains
        
        # Initialize models
        self._initialize_models()
        self._setup_real_time_learning()
    
    def _initialize_models(self):
        """Initialize advanced ML models with real-time capabilities"""
        self.completion_model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1
        )
        
        self.cost_model = GradientBoostingClassifier(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=6,
            random_state=42
        )
        
        self.quality_model = RandomForestRegressor(
            n_estimators=100,
            max_depth=8,
            random_state=42,
            n_jobs=-1
        )
        
        self.timeline_model = LinearRegression()
        
        # Online learning model for real-time updates
        self.online_model = SGDRegressor(
            learning_rate='adaptive',
            eta0=0.01,
            random_state=42
        )
        
        # Anomaly detection for data quality
        self.anomaly_detector = IsolationForest(
            contamination=0.1,
            random_state=42
        )
        
        # Clustering for pattern recognition
        self.clustering_model = KMeans(
            n_clusters=5,
            random_state=42
        )
        
        logging.info("Advanced ML models initialized successfully")
    
    def _setup_real_time_learning(self):
        """Setup real-time learning capabilities"""
        self.monte_carlo_simulations = 1000
        self.confidence_intervals = [0.05, 0.95]  # 90% confidence
        self.feature_importance_threshold = 0.01
        
        # Performance tracking
        self.model_metrics = {
            'accuracy_history': [],
            'mse_history': [],
            'r2_history': [],
            'last_updated': None
        }
        
        logging.info("Real-time learning system configured")
    
    def predict_project_outcomes(self, issues: List[Dict]) -> Dict[str, Any]:
        """Predict various project outcomes using ML models"""
        try:
            if not issues:
                return self._get_default_predictions()
            
            # Extract features from issues
            features = self._extract_features(issues)
            
            if not self.is_trained:
                # Train on available data or use heuristic predictions
                return self._heuristic_predictions(features, issues)
            
            # Use trained models for predictions
            predictions = {}
            
            # Completion probability prediction
            completion_prob = self._predict_completion_probability(features)
            predictions['completion_probability'] = completion_prob
            
            # Completion date prediction
            completion_date = self._predict_completion_date(features, issues)
            predictions['completion_date'] = completion_date
            
            # Budget overrun probability
            budget_overrun_prob = self._predict_budget_overrun(features)
            predictions['budget_overrun_prob'] = budget_overrun_prob
            
            # Confidence intervals
            predictions['confidence_intervals'] = self._calculate_confidence_intervals(features)
            
            return predictions
            
        except Exception as e:
            logging.error(f"Prediction error: {str(e)}")
            return self._get_default_predictions()
    
    def _extract_features(self, issues: List[Dict]) -> np.ndarray:
        """Extract numerical features from issues for ML models"""
        features = []
        
        # Basic project metrics
        total_issues = len(issues)
        completed_issues = len([i for i in issues if i.get('status', {}).get('category') == 'Done'])
        in_progress_issues = len([i for i in issues if 'progress' in i.get('status', {}).get('name', '').lower()])
        
        # Story points analysis
        total_story_points = sum(i.get('storypoints', 0) or 0 for i in issues)
        completed_story_points = sum(
            i.get('storypoints', 0) or 0 for i in issues 
            if i.get('status', {}).get('category') == 'Done'
        )
        
        # Time-based features
        avg_cycle_time = self._calculate_average_cycle_time(issues)
        overdue_ratio = len([i for i in issues if self._is_overdue(i)]) / total_issues if total_issues > 0 else 0
        
        # Priority distribution
        high_priority_ratio = len([i for i in issues if self._is_high_priority(i)]) / total_issues if total_issues > 0 else 0
        
        # Bug ratio
        bug_ratio = len([i for i in issues if i.get('issuetype', {}).get('name', '').lower() == 'bug']) / total_issues if total_issues > 0 else 0
        
        # Team workload variance
        workload_variance = self._calculate_workload_variance(issues)
        
        # Compile feature vector
        features = [
            total_issues,
            completed_issues / total_issues if total_issues > 0 else 0,
            in_progress_issues / total_issues if total_issues > 0 else 0,
            total_story_points,
            completed_story_points / total_story_points if total_story_points > 0 else 0,
            avg_cycle_time,
            overdue_ratio,
            high_priority_ratio,
            bug_ratio,
            workload_variance
        ]
        
        return np.array(features).reshape(1, -1)
    
    def _calculate_average_cycle_time(self, issues: List[Dict]) -> float:
        """Calculate average cycle time for completed issues"""
        cycle_times = []
        
        for issue in issues:
            if issue.get('status', {}).get('category') == 'Done':
                created = issue.get('created')
                resolved = issue.get('resolutiondate')
                
                if created and resolved:
                    try:
                        created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                        resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                        cycle_time = (resolved_date - created_date).days
                        if cycle_time > 0:
                            cycle_times.append(cycle_time)
                    except:
                        continue
        
        return np.mean(cycle_times) if cycle_times else 7.0  # Default 7 days
    
    def _is_overdue(self, issue: Dict) -> bool:
        """Check if issue is overdue"""
        due_date = issue.get('duedate')
        if not due_date:
            return False
        
        try:
            due_date_obj = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            return due_date_obj < datetime.now() and issue.get('status', {}).get('category') != 'Done'
        except:
            return False
    
    def _is_high_priority(self, issue: Dict) -> bool:
        """Check if issue has high priority"""
        priority = issue.get('priority', {}).get('name', '').lower()
        return priority in ['high', 'highest', 'critical', 'blocker']
    
    def _calculate_workload_variance(self, issues: List[Dict]) -> float:
        """Calculate workload variance across team members"""
        assignee_counts = {}
        
        for issue in issues:
            assignee = issue.get('assignee', {}).get('name', 'Unassigned')
            if assignee != 'Unassigned':
                assignee_counts[assignee] = assignee_counts.get(assignee, 0) + 1
        
        if len(assignee_counts) < 2:
            return 0.0
        
        workloads = list(assignee_counts.values())
        return np.var(workloads) / np.mean(workloads) if np.mean(workloads) > 0 else 0.0
    
    def _heuristic_predictions(self, features: np.ndarray, issues: List[Dict]) -> Dict[str, Any]:
        """Generate predictions using heuristic rules when models aren't trained"""
        feature_vec = features[0]
        
        # Completion probability based on current progress and velocity
        completion_ratio = feature_vec[1]  # completed_issues / total_issues
        story_point_ratio = feature_vec[4]  # completed_story_points / total_story_points
        overdue_ratio = feature_vec[6]
        bug_ratio = feature_vec[8]
        
        # Calculate completion probability
        base_completion_prob = (completion_ratio + story_point_ratio) / 2
        
        # Adjust for risk factors
        risk_adjustment = 1 - (overdue_ratio * 0.3 + bug_ratio * 0.2)
        completion_probability = min(0.95, max(0.05, base_completion_prob * risk_adjustment))
        
        # Predict completion date based on current velocity
        avg_cycle_time = feature_vec[5]
        remaining_issues = feature_vec[0] * (1 - completion_ratio)
        estimated_days = remaining_issues * avg_cycle_time * 1.2  # Buffer factor
        
        completion_date = (datetime.now() + timedelta(days=int(estimated_days))).isoformat()
        
        # Budget overrun probability
        workload_variance = feature_vec[9]
        budget_overrun_prob = min(0.8, max(0.1, overdue_ratio * 0.6 + workload_variance * 0.4))
        
        return {
            'completion_probability': round(completion_probability, 3),
            'completion_date': completion_date,
            'budget_overrun_prob': round(budget_overrun_prob, 3),
            'confidence_intervals': {
                'completion_probability': [
                    max(0, completion_probability - 0.1),
                    min(1, completion_probability + 0.1)
                ],
                'budget_overrun_prob': [
                    max(0, budget_overrun_prob - 0.15),
                    min(1, budget_overrun_prob + 0.15)
                ]
            }
        }
    
    def _predict_completion_probability(self, features: np.ndarray) -> float:
        """Predict project completion probability"""
        try:
            if self.completion_model and self.is_trained:
                # Use trained model
                scaled_features = self.scaler.transform(features)
                prediction = self.completion_model.predict(scaled_features)[0]
                return max(0.0, min(1.0, prediction))
            else:
                # Use heuristic
                return self._heuristic_completion_probability(features)
        except Exception as e:
            logging.error(f"Completion prediction error: {str(e)}")
            return 0.7  # Default prediction
    
    def _predict_completion_date(self, features: np.ndarray, issues: List[Dict]) -> str:
        """Predict project completion date"""
        try:
            # Calculate based on velocity and remaining work
            feature_vec = features[0]
            completion_ratio = feature_vec[1]
            avg_cycle_time = feature_vec[5]
            
            remaining_work = 1 - completion_ratio
            estimated_days = remaining_work * len(issues) * avg_cycle_time / max(1, len(issues) * 0.1)
            
            # Add buffer for uncertainties
            buffer_days = estimated_days * 0.2
            total_days = estimated_days + buffer_days
            
            completion_date = datetime.now() + timedelta(days=int(total_days))
            return completion_date.isoformat()
            
        except Exception as e:
            logging.error(f"Completion date prediction error: {str(e)}")
            return (datetime.now() + timedelta(days=30)).isoformat()
    
    def _predict_budget_overrun(self, features: np.ndarray) -> float:
        """Predict budget overrun probability"""
        try:
            feature_vec = features[0]
            overdue_ratio = feature_vec[6]
            workload_variance = feature_vec[9]
            bug_ratio = feature_vec[8]
            
            # Higher overdue ratio, workload variance, and bugs increase overrun risk
            overrun_prob = (overdue_ratio * 0.4 + workload_variance * 0.3 + bug_ratio * 0.3)
            return max(0.0, min(1.0, overrun_prob))
            
        except Exception as e:
            logging.error(f"Budget overrun prediction error: {str(e)}")
            return 0.3  # Default prediction
    
    def _calculate_confidence_intervals(self, features: np.ndarray) -> Dict[str, List[float]]:
        """Calculate confidence intervals for predictions"""
        return {
            'completion_probability': [0.6, 0.9],
            'budget_overrun_prob': [0.2, 0.5],
            'completion_date_range': ['±10 days', '±20 days']
        }
    
    def _heuristic_completion_probability(self, features: np.ndarray) -> float:
        """Heuristic completion probability calculation"""
        feature_vec = features[0]
        completion_ratio = feature_vec[1]
        story_point_ratio = feature_vec[4]
        overdue_ratio = feature_vec[6]
        
        base_prob = (completion_ratio + story_point_ratio) / 2
        risk_factor = 1 - (overdue_ratio * 0.3)
        
        return max(0.1, min(0.95, base_prob * risk_factor))
    
    def _get_default_predictions(self) -> Dict[str, Any]:
        """Return default predictions when no data is available"""
        return {
            'completion_probability': 0.75,
            'completion_date': (datetime.now() + timedelta(days=30)).isoformat(),
            'budget_overrun_prob': 0.25,
            'confidence_intervals': {
                'completion_probability': [0.65, 0.85],
                'budget_overrun_prob': [0.15, 0.35]
            }
        }
    
    def train_models(self, training_data: List[Dict]) -> bool:
        """Train ML models on historical project data"""
        try:
            if len(training_data) < 10:  # Need minimum data for training
                logging.warning("Insufficient training data for ML models")
                return False
            
            # Prepare training data
            X, y_completion, y_cost, y_quality = self._prepare_training_data(training_data)
            
            if X.shape[0] < 5:
                return False
            
            # Scale features
            X_scaled = self.scaler.fit_transform(X)
            
            # Train completion model
            X_train, X_test, y_train, y_test = train_test_split(
                X_scaled, y_completion, test_size=0.2, random_state=42
            )
            
            self.completion_model.fit(X_train, y_train)
            
            # Train other models similarly
            self.cost_model.fit(X_train, (y_cost > 0.5).astype(int))  # Binary classification
            self.quality_model.fit(X_train, y_quality)
            
            self.is_trained = True
            logging.info("ML models trained successfully")
            return True
            
        except Exception as e:
            logging.error(f"Model training error: {str(e)}")
            return False
    
    def _prepare_training_data(self, data: List[Dict]) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Prepare training data for ML models"""
        X = []
        y_completion = []
        y_cost = []
        y_quality = []
        
        for project in data:
            issues = project.get('issues', [])
            if not issues:
                continue
            
            features = self._extract_features(issues)[0]
            X.append(features)
            
            # Target variables (these would come from historical data)
            y_completion.append(project.get('completion_probability', 0.5))
            y_cost.append(project.get('cost_overrun_prob', 0.3))
            y_quality.append(project.get('quality_score', 0.7))
        
        return (
            np.array(X),
            np.array(y_completion),
            np.array(y_cost),
            np.array(y_quality)
        )
    
    def save_models(self, path: str = 'models/'):
        """Save trained models to disk"""
        try:
            import os
            os.makedirs(path, exist_ok=True)
            
            joblib.dump(self.completion_model, f'{path}/completion_model.pkl')
            joblib.dump(self.cost_model, f'{path}/cost_model.pkl')
            joblib.dump(self.quality_model, f'{path}/quality_model.pkl')
            joblib.dump(self.scaler, f'{path}/scaler.pkl')
            
            logging.info("Models saved successfully")
            return True
            
        except Exception as e:
            logging.error(f"Model saving error: {str(e)}")
            return False
    
    def load_models(self, path: str = 'models/'):
        """Load trained models from disk"""
        try:
            import os
            if not os.path.exists(f'{path}/completion_model.pkl'):
                return False
            
            self.completion_model = joblib.load(f'{path}/completion_model.pkl')
            self.cost_model = joblib.load(f'{path}/cost_model.pkl')
            self.quality_model = joblib.load(f'{path}/quality_model.pkl')
            self.scaler = joblib.load(f'{path}/scaler.pkl')
            
            self.is_trained = True
            logging.info("Models loaded successfully")
            return True
            
        except Exception as e:
            logging.error(f"Model loading error: {str(e)}")
            return False

class TimeSeriesAnalyzer:
    """Time series analysis for trend prediction"""
    
    def __init__(self):
        self.trend_model = LinearRegression()
        self.seasonal_model = None
    
    def analyze_trends(self, time_series_data: List[Dict]) -> Dict[str, Any]:
        """Analyze trends in project metrics over time"""
        try:
            if len(time_series_data) < 3:
                return {"trend": "insufficient_data"}
            
            # Extract time series
            dates = []
            values = []
            
            for point in time_series_data:
                if 'date' in point and 'value' in point:
                    dates.append(datetime.fromisoformat(point['date'].replace('Z', '+00:00')))
                    values.append(point['value'])
            
            if len(values) < 3:
                return {"trend": "insufficient_data"}
            
            # Convert to numerical format for regression
            X = np.array([(d - dates[0]).days for d in dates]).reshape(-1, 1)
            y = np.array(values)
            
            # Fit trend model
            self.trend_model.fit(X, y)
            
            # Calculate trend direction and strength
            slope = self.trend_model.coef_[0]
            trend_direction = "increasing" if slope > 0.01 else "decreasing" if slope < -0.01 else "stable"
            trend_strength = abs(slope)
            
            # Predict next values
            last_x = X[-1][0]
            future_x = np.array([[last_x + 7], [last_x + 14], [last_x + 30]])  # 1 week, 2 weeks, 1 month
            predictions = self.trend_model.predict(future_x)
            
            return {
                "trend_direction": trend_direction,
                "trend_strength": float(trend_strength),
                "r_squared": float(self.trend_model.score(X, y)),
                "predictions": {
                    "1_week": float(predictions[0]),
                    "2_weeks": float(predictions[1]),
                    "1_month": float(predictions[2])
                }
            }
            
        except Exception as e:
            logging.error(f"Trend analysis error: {str(e)}")
            return {"trend": "analysis_failed"}
    
    def detect_anomalies(self, data: List[float], threshold: float = 2.0) -> List[int]:
        """Detect anomalies in time series data using statistical methods"""
        try:
            if len(data) < 5:
                return []
            
            data_array = np.array(data)
            mean = np.mean(data_array)
            std = np.std(data_array)
            
            # Z-score based anomaly detection
            z_scores = np.abs((data_array - mean) / std)
            anomaly_indices = np.where(z_scores > threshold)[0].tolist()
            
            return anomaly_indices
            
        except Exception as e:
            logging.error(f"Anomaly detection error: {str(e)}")
            return []

class RiskScoreCalculator:
    """Advanced risk scoring using multiple algorithms"""
    
    def __init__(self):
        self.weights = {
            'timeline_risk': 0.25,
            'budget_risk': 0.25,
            'quality_risk': 0.20,
            'resource_risk': 0.15,
            'dependency_risk': 0.15
        }
    
    def calculate_composite_risk_score(self, risk_factors: Dict[str, float]) -> Dict[str, Any]:
        """Calculate composite risk score from multiple factors"""
        try:
            # Normalize risk factors to 0-1 scale
            normalized_factors = {}
            for factor, value in risk_factors.items():
                normalized_factors[factor] = max(0, min(1, value))
            
            # Calculate weighted composite score
            composite_score = 0
            for factor, weight in self.weights.items():
                if factor in normalized_factors:
                    composite_score += normalized_factors[factor] * weight
            
            # Determine risk level
            if composite_score < 0.3:
                risk_level = "low"
                risk_color = "green"
            elif composite_score < 0.6:
                risk_level = "medium"
                risk_color = "yellow"
            elif composite_score < 0.8:
                risk_level = "high"
                risk_color = "orange"
            else:
                risk_level = "critical"
                risk_color = "red"
            
            return {
                "composite_score": round(composite_score, 3),
                "risk_level": risk_level,
                "risk_color": risk_color,
                "factor_breakdown": normalized_factors,
                "confidence": self._calculate_confidence(normalized_factors)
            }
            
        except Exception as e:
            logging.error(f"Risk score calculation error: {str(e)}")
            return {
                "composite_score": 0.5,
                "risk_level": "medium",
                "risk_color": "yellow",
                "factor_breakdown": {},
                "confidence": 0.5
            }
    
    def _calculate_confidence(self, factors: Dict[str, float]) -> float:
        """Calculate confidence in risk assessment based on data availability"""
        # Higher confidence when more factors are available and values are not extreme
        available_factors = len([f for f in factors.values() if f is not None])
        total_factors = len(self.weights)
        
        completeness = available_factors / total_factors
        
        # Reduce confidence for extreme values (might indicate data issues)
        extreme_penalty = sum(1 for v in factors.values() if v is not None and (v < 0.05 or v > 0.95))
        extreme_factor = max(0, 1 - (extreme_penalty * 0.2))
        
        confidence = completeness * extreme_factor
        return round(confidence, 3)
