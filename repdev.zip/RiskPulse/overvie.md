# UNCIA Intelligent Risk Engine Dashboard

## Overview

This repository contains a Flask-based web application that provides intelligent risk analysis and management for JIRA projects. The system integrates with Atlassian JIRA to fetch project data and performs comprehensive risk analytics using machine learning models and advanced data analysis techniques.

The application serves as a risk management dashboard that provides real-time insights into project health, velocity trends, resource utilization, and predictive analytics to help teams proactively manage project risks.

## System Architecture

### Backend Architecture
- **Flask Web Framework**: Core web application framework providing REST API endpoints
- **SQLite Database**: Local database for storing risk metrics, analysis results, and historical data
- **Machine Learning Pipeline**: Integrated ML models for predictive risk analysis using scikit-learn
- **Scheduled Tasks**: Automated background processes for continuous risk monitoring

### Frontend Architecture
- **Server-Side Rendered Templates**: Jinja2 templates for the main dashboard interface
- **Client-Side JavaScript**: Interactive dashboard with Chart.js for data visualization
- **Responsive CSS**: Custom styling with purple/violet theme matching UNCIA branding

### Integration Layer
- **JIRA REST API**: Direct integration with Atlassian JIRA for project data retrieval
- **HTTP Basic Authentication**: Secure authentication using JIRA API tokens

## Key Components

### Core Modules

1. **app.py**: Main Flask application entry point with CORS configuration and database initialization
2. **main.py**: Application runner for development and production deployment
3. **risk_engine.py**: Central risk analysis engine with comprehensive metrics calculation
4. **ml_models.py**: Machine learning models for predictive analytics (Random Forest, Gradient Boosting)
5. **data_analyzer.py**: Advanced data analysis utilities for project health assessment
6. **database.py**: SQLite database management with context managers and schema definitions
7. **scheduler.py**: Automated task scheduling for continuous risk monitoring

### Risk Analysis Features

- **Project Health Analysis**: Comprehensive health scoring based on multiple metrics
- **Velocity Trends**: Sprint velocity analysis and trend prediction
- **Resource Utilization**: Team performance and resource allocation analysis
- **Timeline Variance**: Schedule deviation tracking and prediction
- **Cost Variance**: Budget tracking and cost overrun prediction
- **Dependency Impact**: Cross-project dependency risk assessment
- **Spillover Analysis**: Risk propagation between related projects

### Machine Learning Components

- **Completion Prediction**: Random Forest model for project completion forecasting
- **Cost Prediction**: Gradient Boosting classifier for cost overrun risk assessment
- **Quality Metrics**: ML-based quality assessment and defect prediction
- **Timeline Forecasting**: Predictive models for schedule variance analysis

## Data Flow

1. **Data Ingestion**: JIRA API integration fetches project data, issues, and metadata
2. **Data Processing**: Raw JIRA data is cleaned, normalized, and prepared for analysis
3. **Risk Calculation**: Multiple risk engines process data to generate risk scores and metrics
4. **ML Analysis**: Machine learning models provide predictive insights and trend analysis
5. **Storage**: Results are persisted in SQLite database with timestamp tracking
6. **Visualization**: Frontend dashboard displays real-time risk metrics and trends
7. **Automation**: Scheduled tasks continuously update risk assessments

## External Dependencies

### Required Services
- **Atlassian JIRA**: Source system for project data and issue tracking
- **JIRA API Token**: Authentication credential for API access

### Python Dependencies
- **Flask**: Web framework and API development
- **Flask-CORS**: Cross-origin resource sharing support
- **Flask-SQLAlchemy**: Database ORM layer
- **Requests**: HTTP client for JIRA API integration
- **Pandas/NumPy**: Data analysis and numerical computing
- **Scikit-learn**: Machine learning algorithms and utilities
- **Schedule**: Task scheduling and automation
- **Gunicorn**: WSGI HTTP server for production deployment

### Frontend Dependencies
- **Chart.js**: Data visualization and charting library
- **Feather Icons**: Icon library for UI components

## Deployment Strategy

### Development Environment
- **Local Development**: Flask development server with debug mode enabled
- **Database**: SQLite file-based database for simplicity
- **Hot Reload**: Automatic reloading on code changes

### Production Environment
- **Replit Deployment**: Configured for Replit's autoscale deployment target
- **Gunicorn WSGI Server**: Production-grade Python web server
- **Process Management**: Multi-worker configuration with port binding
- **Environment Variables**: Secure configuration management for API tokens

### Containerization Support
- **Nix Environment**: Declarative package management with Python 3.11
- **System Dependencies**: PostgreSQL, OpenSSL, and locale support
- **Reproducible Builds**: Consistent environment across development and production

### Scaling Considerations
- **Database**: Ready for PostgreSQL migration for multi-user scenarios
- **Caching**: Analysis result caching for improved performance
- **Background Tasks**: Separate worker processes for scheduled risk calculations

## Changelog
- June 26, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.