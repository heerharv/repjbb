// Risk Analytics Dashboard JavaScript
// Manages the intelligent risk engine frontend interactions

class RiskAnalyticsDashboard {
    constructor() {
        this.currentProject = null;
        this.charts = {};
        this.analysisData = null;
        this.baseUrl = window.location.origin;
        
        // Initialize dashboard
        this.init();
    }
    
    async init() {
        try {
            await this.loadProjects();
            this.setupEventListeners();
        } catch (error) {
            console.error('Dashboard initialization failed:', error);
            this.showError('Failed to initialize dashboard');
        }
    }
    
    async loadProjects() {
        try {
            const response = await fetch(`${this.baseUrl}/api/jira-projects`);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to load projects');
            }
            
            const select = document.getElementById('projectSelect');
            select.innerHTML = '<option value="">Select a project...</option>';
            
            if (data.projects && data.projects.length > 0) {
                data.projects.forEach(project => {
                    const option = document.createElement('option');
                    option.value = project.key;
                    option.textContent = `${project.key} - ${project.name}`;
                    select.appendChild(option);
                });
            } else {
                select.innerHTML = '<option value="">No projects available</option>';
            }
        } catch (error) {
            console.error('Failed to load projects:', error);
            this.showError('Failed to load projects: ' + error.message);
        }
    }
    
    setupEventListeners() {
        // Project selection change
        const projectSelect = document.getElementById('projectSelect');
        projectSelect.addEventListener('change', (e) => {
            if (e.target.value) {
                this.currentProject = e.target.value;
                this.loadProjectData();
            }
        });
        
        // Refresh button
        const refreshBtn = document.querySelector('.refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                if (this.currentProject) {
                    this.loadProjectData();
                }
            });
        }
        
        // Analyze button
        const analyzeBtn = document.querySelector('.analyze-btn');
        if (analyzeBtn) {
            analyzeBtn.addEventListener('click', () => {
                if (this.currentProject) {
                    this.runComprehensiveAnalysis();
                }
            });
        }
    }
    
    async loadProjectData() {
        if (!this.currentProject) return;
        
        this.showLoading('Loading project data...');
        
        try {
            // Load basic project overview
            const issuesResponse = await fetch(`${this.baseUrl}/api/jira/issues/${this.currentProject}`);
            const issuesData = await issuesResponse.json();
            
            if (!issuesResponse.ok) {
                throw new Error(issuesData.error || 'Failed to load project issues');
            }
            
            this.updateOverviewStats(issuesData);
            this.hideLoading();
            
            // Load risk analysis data
            await this.loadRiskAnalysis();
            
        } catch (error) {
            console.error('Failed to load project data:', error);
            this.showError('Failed to load project data: ' + error.message);
            this.hideLoading();
        }
    }
    
    async loadRiskAnalysis() {
        if (!this.currentProject) return;
        
        try {
            const response = await fetch(`${this.baseUrl}/api/risk-engine/analysis/${this.currentProject}`);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to load risk analysis');
            }
            
            this.analysisData = data.analysis;
            this.updateRiskMetrics();
            this.updateCharts();
            this.updatePredictions();
            this.updateRecommendations();
            this.updateSuccessCriteria();
            
        } catch (error) {
            console.error('Failed to load risk analysis:', error);
            // Don't show error for risk analysis as it might not be available yet
            this.showDefaultRiskMetrics();
        }
    }
    
    async runComprehensiveAnalysis() {
        if (!this.currentProject) {
            this.showError('Please select a project first');
            return;
        }
        
        this.showLoading('Running comprehensive risk analysis...');
        
        try {
            const response = await fetch(`${this.baseUrl}/api/risk-engine/analysis/${this.currentProject}`);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Risk analysis failed');
            }
            
            this.analysisData = data.analysis;
            this.updateDashboardWithAnalysis();
            this.hideLoading();
            
        } catch (error) {
            console.error('Risk analysis failed:', error);
            this.showError('Risk analysis failed: ' + error.message);
            this.hideLoading();
        }
    }
    
    updateOverviewStats(issuesData) {
        const issues = issuesData.issues || [];
        
        // Count issues by status
        const statusCounts = {
            total: issues.length,
            completed: 0,
            inProgress: 0,
            todo: 0
        };
        
        issues.forEach(issue => {
            const statusCategory = issue.status?.category;
            if (statusCategory === 'Done') {
                statusCounts.completed++;
            } else if (statusCategory === 'In Progress' || issue.status?.name?.toLowerCase().includes('progress')) {
                statusCounts.inProgress++;
            } else {
                statusCounts.todo++;
            }
        });
        
        // Update DOM elements
        document.getElementById('totalIssues').textContent = statusCounts.total;
        document.getElementById('completedIssues').textContent = statusCounts.completed;
        document.getElementById('progressIssues').textContent = statusCounts.inProgress;
        document.getElementById('todoIssues').textContent = statusCounts.todo;
        
        // Calculate completion percentage
        const completionPercentage = statusCounts.total > 0 ? 
            Math.round((statusCounts.completed / statusCounts.total) * 100) : 0;
        
        // Update progress bar
        document.getElementById('progressText').textContent = `${completionPercentage}% Complete`;
        document.getElementById('progressBar').style.width = `${completionPercentage}%`;
        
        // Show overview sections
        document.getElementById('overviewStats').style.display = 'grid';
        document.getElementById('progressOverview').style.display = 'block';
    }
    
    updateDashboardWithAnalysis() {
        if (!this.analysisData) return;
        
        // Update overall risk score
        const riskScore = Math.round((this.analysisData.overall_risk_score || 0) * 100);
        const riskLevel = this.analysisData.risk_level || 'medium';
        
        document.getElementById('overallRiskScore').textContent = `${riskScore}%`;
        document.getElementById('riskLevel').textContent = this.formatRiskLevel(riskLevel);
        
        // Update success probability from predictions
        const predictions = this.analysisData.predictive_insights || {};
        const successProb = Math.round((predictions.completion_probability || 0.7) * 100);
        document.getElementById('successProbability').textContent = `${successProb}%`;
        
        // Update all sections
        this.updateRiskMetrics();
        this.updateCharts();
        this.updatePredictions();
        this.updateRecommendations();
        this.updateSuccessCriteria();
        this.updateTimeline();
    }
    
    updateRiskMetrics() {
        const container = document.getElementById('riskMetricsGrid');
        container.innerHTML = '';
        
        if (!this.analysisData) {
            this.showDefaultRiskMetrics();
            return;
        }
        
        const metrics = [
            {
                title: 'Say-Do Ratio',
                value: this.analysisData.say_do_ratio?.overall_ratio || 0,
                unit: '%',
                description: 'Delivery commitment accuracy',
                risk: this.getRiskLevel(this.analysisData.say_do_ratio?.overall_ratio || 0, 80, 60, true)
            },
            {
                title: 'Timeline Variance',
                value: Math.abs(this.analysisData.timeline_variance?.variance_percentage || 0),
                unit: '%',
                description: 'Schedule deviation from plan',
                risk: this.getRiskLevel(Math.abs(this.analysisData.timeline_variance?.variance_percentage || 0), 10, 25, false)
            },
            {
                title: 'Cost Variance',
                value: Math.abs(this.analysisData.cost_variance?.variance_percentage || 0),
                unit: '%',
                description: 'Budget deviation from plan',
                risk: this.getRiskLevel(Math.abs(this.analysisData.cost_variance?.variance_percentage || 0), 10, 20, false)
            },
            {
                title: 'Resource Utilization',
                value: (this.analysisData.resource_utilization?.overall_utilization || 0.8) * 100,
                unit: '%',
                description: 'Team capacity efficiency',
                risk: this.getRiskLevel((this.analysisData.resource_utilization?.overall_utilization || 0.8) * 100, 70, 50, true)
            },
            {
                title: 'Quality Score',
                value: (this.analysisData.benefit_case?.intangible_benefits?.code_quality || 0.7) * 100,
                unit: '%',
                description: 'Code and delivery quality',
                risk: this.getRiskLevel((this.analysisData.benefit_case?.intangible_benefits?.code_quality || 0.7) * 100, 70, 50, true)
            },
            {
                title: 'Speed to Market',
                value: this.analysisData.speed_to_market?.time_to_market || 90,
                unit: ' days',
                description: 'Estimated time to delivery',
                risk: this.getRiskLevel(this.analysisData.speed_to_market?.time_to_market || 90, 60, 120, false)
            }
        ];
        
        metrics.forEach(metric => {
            const card = this.createRiskMetricCard(metric);
            container.appendChild(card);
        });
    }
    
    createRiskMetricCard(metric) {
        const card = document.createElement('div');
        card.className = `risk-metric-card ${metric.risk}-risk`;
        
        card.innerHTML = `
            <div class="risk-metric-header">
                <h4 class="risk-metric-title">${metric.title}</h4>
                <span class="risk-score-badge ${metric.risk}">${metric.risk}</span>
            </div>
            <div class="risk-metric-value">
                ${Math.round(metric.value)}<span class="risk-metric-unit">${metric.unit}</span>
            </div>
            <div class="risk-metric-description">${metric.description}</div>
            <div class="risk-trend-indicator">
                <span class="trend-arrow ${this.getTrendClass(metric.risk)}">
                    ${this.getTrendArrow(metric.risk)}
                </span>
                <span class="trend-${this.getTrendClass(metric.risk)}">
                    ${this.getTrendText(metric.risk)}
                </span>
            </div>
        `;
        
        return card;
    }
    
    showDefaultRiskMetrics() {
        const container = document.getElementById('riskMetricsGrid');
        container.innerHTML = `
            <div class="risk-metric-card medium-risk">
                <div class="risk-metric-header">
                    <h4 class="risk-metric-title">Analysis Required</h4>
                    <span class="risk-score-badge medium">pending</span>
                </div>
                <div class="risk-metric-value">--</div>
                <div class="risk-metric-description">Click "Run Risk Analysis" to generate intelligent insights</div>
            </div>
        `;
    }
    
    updateCharts() {
        if (!this.analysisData) return;
        
        // Say-Do Ratio Chart
        this.createSayDoChart();
        
        // Timeline Chart
        this.createTimelineChart();
        
        // Cost Chart
        this.createCostChart();
        
        // Resource Chart
        this.createResourceChart();
    }
    
    createSayDoChart() {
        const ctx = document.getElementById('sayDoChart');
        if (!ctx || !this.analysisData.say_do_ratio) return;
        
        if (this.charts.sayDo) {
            this.charts.sayDo.destroy();
        }
        
        const ratio = this.analysisData.say_do_ratio.overall_ratio || 0;
        
        this.charts.sayDo = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Delivered', 'Not Delivered'],
                datasets: [{
                    data: [ratio, 100 - ratio],
                    backgroundColor: ['#10B981', '#EF4444'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    createTimelineChart() {
        const ctx = document.getElementById('timelineChart');
        if (!ctx || !this.analysisData.timeline_variance) return;
        
        if (this.charts.timeline) {
            this.charts.timeline.destroy();
        }
        
        const variance = this.analysisData.timeline_variance;
        
        this.charts.timeline = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Estimated', 'Actual'],
                datasets: [{
                    label: 'Days',
                    data: [variance.estimated_duration || 90, variance.actual_duration || 100],
                    backgroundColor: ['#3B82F6', '#EF4444'],
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    createCostChart() {
        const ctx = document.getElementById('costChart');
        if (!ctx || !this.analysisData.cost_variance) return;
        
        if (this.charts.cost) {
            this.charts.cost.destroy();
        }
        
        const variance = this.analysisData.cost_variance;
        
        this.charts.cost = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Planned', 'Current', 'Projected'],
                datasets: [{
                    label: 'Cost ($)',
                    data: [
                        variance.estimated_total || 100000,
                        variance.actual_total || 110000,
                        (variance.actual_total || 110000) * 1.1
                    ],
                    borderColor: '#F59E0B',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    createResourceChart() {
        const ctx = document.getElementById('resourceChart');
        if (!ctx || !this.analysisData.resource_utilization) return;
        
        if (this.charts.resource) {
            this.charts.resource.destroy();
        }
        
        const utilization = this.analysisData.resource_utilization.overall_utilization || 0.8;
        
        this.charts.resource = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['Capacity', 'Efficiency', 'Distribution', 'Productivity'],
                datasets: [{
                    label: 'Current',
                    data: [
                        utilization * 100,
                        (this.analysisData.resource_utilization.efficiency_score || 0.8) * 100,
                        75, // Mock distribution score
                        80  // Mock productivity score
                    ],
                    borderColor: '#7C3AED',
                    backgroundColor: 'rgba(124, 58, 237, 0.2)',
                    pointBackgroundColor: '#7C3AED'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    updatePredictions() {
        const container = document.getElementById('predictionCards');
        container.innerHTML = '';
        
        if (!this.analysisData || !this.analysisData.predictive_insights) {
            container.innerHTML = '<p>Run risk analysis to generate predictions</p>';
            return;
        }
        
        const predictions = this.analysisData.predictive_insights;
        
        const predictionItems = [
            {
                title: 'Completion Probability',
                value: Math.round((predictions.completion_probability || 0.7) * 100) + '%',
                confidence: 'High',
                class: 'prediction-success'
            },
            {
                title: 'Budget Overrun Risk',
                value: Math.round((predictions.budget_overrun_prob || 0.3) * 100) + '%',
                confidence: 'Medium',
                class: 'prediction-warning'
            },
            {
                title: 'Estimated Completion',
                value: this.formatDate(predictions.completion_date) || 'TBD',
                confidence: 'Medium',
                class: 'prediction-info'
            }
        ];
        
        predictionItems.forEach(item => {
            const card = document.createElement('div');
            card.className = `prediction-card ${item.class}`;
            card.innerHTML = `
                <div class="prediction-title">${item.title}</div>
                <div class="prediction-value ${item.class}">${item.value}</div>
                <div class="prediction-confidence">Confidence: ${item.confidence}</div>
            `;
            container.appendChild(card);
        });
    }
    
    updateRecommendations() {
        const container = document.getElementById('recommendationsList');
        container.innerHTML = '';
        
        if (!this.analysisData) {
            container.innerHTML = '<li>Run risk analysis to generate recommendations</li>';
            return;
        }
        
        // Collect recommendations from various analyses
        const recommendations = [];
        
        // From say-do ratio
        if (this.analysisData.say_do_ratio?.recommendations) {
            recommendations.push(...this.analysisData.say_do_ratio.recommendations.map(r => ({
                text: r,
                priority: 'high'
            })));
        }
        
        // From timeline variance
        if (this.analysisData.timeline_variance?.recommendations) {
            recommendations.push(...this.analysisData.timeline_variance.recommendations.map(r => ({
                text: r,
                priority: 'medium'
            })));
        }
        
        // From cost variance
        if (this.analysisData.cost_variance?.recommendations) {
            recommendations.push(...this.analysisData.cost_variance.recommendations.map(r => ({
                text: r,
                priority: 'medium'
            })));
        }
        
        // From benefit case
        if (this.analysisData.benefit_case?.recommendations) {
            recommendations.push(...this.analysisData.benefit_case.recommendations.map(r => ({
                text: r,
                priority: 'low'
            })));
        }
        
        if (recommendations.length === 0) {
            container.innerHTML = '<li>No specific recommendations at this time. Project appears to be on track.</li>';
            return;
        }
        
        recommendations.slice(0, 8).forEach(rec => {
            const li = document.createElement('li');
            li.innerHTML = `
                <span class="recommendation-text">${rec.text}</span>
                <span class="recommendation-priority ${rec.priority}">${rec.priority}</span>
            `;
            container.appendChild(li);
        });
    }
    
    updateSuccessCriteria() {
        const container = document.getElementById('criteriaList');
        container.innerHTML = '';
        
        if (!this.analysisData || !this.analysisData.success_criteria) {
            container.innerHTML = '<div>Run risk analysis to evaluate success criteria</div>';
            return;
        }
        
        const criteria = this.analysisData.success_criteria.criteria_breakdown || {};
        
        const criteriaItems = [
            { name: 'Scope Completion', score: criteria.scope_completion || 0 },
            { name: 'Quality Standards', score: criteria.quality_standards || 0 },
            { name: 'Timeline Adherence', score: criteria.timeline_adherence || 0 },
            { name: 'Budget Compliance', score: criteria.budget_compliance || 0 },
            { name: 'Stakeholder Satisfaction', score: criteria.stakeholder_satisfaction || 0 },
            { name: 'Team Performance', score: criteria.team_performance || 0 }
        ];
        
        criteriaItems.forEach(item => {
            const score = Math.round(item.score * 100);
            const status = score >= 80 ? 'achieved' : score >= 60 ? 'at-risk' : 'failed';
            const statusText = score >= 80 ? 'On Track' : score >= 60 ? 'At Risk' : 'Behind';
            
            const div = document.createElement('div');
            div.className = `criteria-item ${status}`;
            div.innerHTML = `
                <div class="criteria-name">${item.name}</div>
                <div class="criteria-progress">
                    <div class="criteria-score">${score}%</div>
                    <div class="criteria-status ${status}">${statusText}</div>
                </div>
            `;
            container.appendChild(div);
        });
    }
    
    updateTimeline() {
        const container = document.getElementById('timelinePoints');
        if (!container) return;
        
        container.innerHTML = '';
        
        const timelineData = [
            { label: 'Project Start', date: '2024-01-01', status: 'completed' },
            { label: 'Requirements', date: '2024-01-15', status: 'completed' },
            { label: 'Development', date: '2024-02-01', status: 'current' },
            { label: 'Testing', date: '2024-03-01', status: 'future' },
            { label: 'Deployment', date: '2024-03-15', status: 'future' }
        ];
        
        timelineData.forEach(item => {
            const point = document.createElement('div');
            point.className = 'timeline-point';
            point.innerHTML = `
                <div class="timeline-marker ${item.status}"></div>
                <div class="timeline-label">${item.label}</div>
                <div class="timeline-date">${this.formatDate(item.date)}</div>
            `;
            container.appendChild(point);
        });
        
        document.getElementById('riskTimeline').style.display = 'block';
    }
    
    // Tab switching functionality
    switchTab(tabName) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Remove active class from all tab buttons
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Show selected tab
        document.getElementById(`${tabName}-tab`).classList.add('active');
        
        // Add active class to clicked button
        event.target.classList.add('active');
    }
    
    // Utility functions
    getRiskLevel(value, goodThreshold, badThreshold, higherIsBetter = true) {
        if (higherIsBetter) {
            if (value >= goodThreshold) return 'low';
            if (value >= badThreshold) return 'medium';
            return 'high';
        } else {
            if (value <= goodThreshold) return 'low';
            if (value <= badThreshold) return 'medium';
            return 'high';
        }
    }
    
    getTrendClass(risk) {
        switch (risk) {
            case 'low': return 'improving';
            case 'high': return 'declining';
            default: return 'stable';
        }
    }
    
    getTrendArrow(risk) {
        switch (risk) {
            case 'low': return '↗';
            case 'high': return '↘';
            default: return '→';
        }
    }
    
    getTrendText(risk) {
        switch (risk) {
            case 'low': return 'Good';
            case 'high': return 'Needs Attention';
            default: return 'Monitor';
        }
    }
    
    formatRiskLevel(level) {
        const levels = {
            low: 'Low Risk',
            medium: 'Medium Risk',
            high: 'High Risk',
            critical: 'Critical Risk'
        };
        return levels[level] || 'Medium Risk';
    }
    
    formatDate(dateString) {
        if (!dateString) return 'TBD';
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric',
                year: 'numeric'
            });
        } catch {
            return 'TBD';
        }
    }
    
    showLoading(message = 'Loading...') {
        const loadingEl = document.getElementById('loadingMessage');
        if (loadingEl) {
            loadingEl.textContent = message;
            loadingEl.style.display = 'flex';
        }
    }
    
    hideLoading() {
        const loadingEl = document.getElementById('loadingMessage');
        if (loadingEl) {
            loadingEl.style.display = 'none';
        }
    }
    
    showError(message) {
        const errorEl = document.getElementById('errorMessage');
        if (errorEl) {
            errorEl.textContent = message;
            errorEl.style.display = 'block';
        }
        
        // Hide error after 10 seconds
        setTimeout(() => {
            if (errorEl) {
                errorEl.style.display = 'none';
            }
        }, 10000);
    }
}

// Global functions for HTML event handlers
let dashboard;

function initializeDashboard() {
    dashboard = new RiskAnalyticsDashboard();
}

function loadProjectData() {
    if (dashboard) {
        dashboard.loadProjectData();
    }
}

function runComprehensiveAnalysis() {
    if (dashboard) {
        dashboard.runComprehensiveAnalysis();
    }
}

function refreshDashboard() {
    if (dashboard && dashboard.currentProject) {
        dashboard.loadProjectData();
    } else if (dashboard) {
        dashboard.loadProjects();
    }
}

function switchTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    const targetTab = document.getElementById(`${tabName}-tab`);
    if (targetTab) {
        targetTab.classList.add('active');
    }
    
    // Add active class to clicked button
    const clickedButton = Array.from(document.querySelectorAll('.tab-button'))
        .find(btn => btn.textContent.toLowerCase().includes(tabName.toLowerCase()));
    if (clickedButton) {
        clickedButton.classList.add('active');
    }
}

// Export for module use if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RiskAnalyticsDashboard;
}
