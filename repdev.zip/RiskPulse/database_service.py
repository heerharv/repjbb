from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
from sqlalchemy.orm import sessionmaker
from sqlalchemy import desc, and_, or_
import json

class DatabaseService:
    """Service layer for database operations with risk analysis data"""
    
    def __init__(self):
        from app import db
        from models import Project, RiskAssessment, MLPrediction, NotificationLog, ModelPerformance, DataUpdate
        
        self.db = db
        self.session = db.session
        self.Project = Project
        self.RiskAssessment = RiskAssessment
        self.MLPrediction = MLPrediction
        self.NotificationLog = NotificationLog
        self.ModelPerformance = ModelPerformance
        self.DataUpdate = DataUpdate
        logging.info("Database service initialized")
    
    # Project Management
    def get_or_create_project(self, project_key: str, project_name: str = None, description: str = None):
        """Get existing project or create new one"""
        try:
            project = self.session.query(Project).filter_by(key=project_key).first()
            
            if not project:
                project = Project(
                    key=project_key,
                    name=project_name or project_key,
                    description=description
                )
                self.session.add(project)
                self.session.commit()
                logging.info(f"Created new project: {project_key}")
            
            return project
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"Error creating/getting project {project_key}: {str(e)}")
            raise
    
    def get_project_by_key(self, project_key: str) -> Optional[Project]:
        """Get project by key"""
        try:
            return self.session.query(Project).filter_by(key=project_key).first()
        except Exception as e:
            logging.error(f"Error getting project {project_key}: {str(e)}")
            return None
    
    # Risk Assessment Storage
    def save_risk_assessment(self, project_key: str, risk_data: Dict[str, Any]) -> bool:
        """Save risk assessment results to database"""
        try:
            project = self.get_or_create_project(project_key)
            
            risk_assessment = RiskAssessment(
                project_id=project.id,
                overall_risk_score=risk_data.get('overall_risk_score', 0.0),
                completion_risk=risk_data.get('completion_risk', 0.0),
                budget_risk=risk_data.get('budget_risk', 0.0),
                timeline_risk=risk_data.get('timeline_risk', 0.0),
                quality_risk=risk_data.get('quality_risk', 0.0),
                resource_risk=risk_data.get('resource_risk', 0.0),
                severity_level=risk_data.get('severity_level', 'medium'),
                risk_trend=risk_data.get('risk_trend', 'stable'),
                total_issues=risk_data.get('total_issues', 0),
                completed_issues=risk_data.get('completed_issues', 0),
                overdue_issues=risk_data.get('overdue_issues', 0),
                blocked_issues=risk_data.get('blocked_issues', 0),
                velocity_score=risk_data.get('velocity_score', 0.0),
                team_performance_score=risk_data.get('team_performance_score', 0.0),
                dependency_risk=risk_data.get('dependency_risk', 0.0)
            )
            
            self.session.add(risk_assessment)
            self.session.commit()
            
            logging.info(f"Saved risk assessment for project {project_key}")
            return True
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"Error saving risk assessment for {project_key}: {str(e)}")
            return False
    
    def get_latest_risk_assessment(self, project_key: str) -> Optional[RiskAssessment]:
        """Get latest risk assessment for project"""
        try:
            project = self.get_project_by_key(project_key)
            if not project:
                return None
            
            return self.session.query(RiskAssessment)\
                .filter_by(project_id=project.id)\
                .order_by(desc(RiskAssessment.analysis_timestamp))\
                .first()
                
        except Exception as e:
            logging.error(f"Error getting latest risk assessment for {project_key}: {str(e)}")
            return None
    
    def get_risk_history(self, project_key: str, days: int = 30) -> List[RiskAssessment]:
        """Get risk assessment history for project"""
        try:
            project = self.get_project_by_key(project_key)
            if not project:
                return []
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            return self.session.query(RiskAssessment)\
                .filter(and_(
                    RiskAssessment.project_id == project.id,
                    RiskAssessment.analysis_timestamp >= cutoff_date
                ))\
                .order_by(RiskAssessment.analysis_timestamp)\
                .all()
                
        except Exception as e:
            logging.error(f"Error getting risk history for {project_key}: {str(e)}")
            return []
    
    # ML Prediction Storage
    def save_ml_prediction(self, project_key: str, prediction_data: Dict[str, Any]) -> bool:
        """Save ML prediction results to database"""
        try:
            project = self.get_or_create_project(project_key)
            
            # Extract Monte Carlo results
            completion_prob = prediction_data.get('completion_probability', {})
            budget_risk = prediction_data.get('budget_overrun_risk', {})
            timeline_var = prediction_data.get('timeline_variance', {})
            
            ml_prediction = MLPrediction(
                project_id=project.id,
                completion_probability=completion_prob.get('mean', 0.7),
                completion_probability_ci_low=completion_prob.get('confidence_interval', [0, 0])[0] if completion_prob.get('confidence_interval') else 0,
                completion_probability_ci_high=completion_prob.get('confidence_interval', [0, 0])[1] if completion_prob.get('confidence_interval') else 0,
                budget_overrun_probability=budget_risk.get('mean', 0.3),
                budget_overrun_ci_low=budget_risk.get('confidence_interval', [0, 0])[0] if budget_risk.get('confidence_interval') else 0,
                budget_overrun_ci_high=budget_risk.get('confidence_interval', [0, 0])[1] if budget_risk.get('confidence_interval') else 0,
                timeline_variance_days=timeline_var.get('mean_days', 10),
                timeline_variance_ci_low=timeline_var.get('confidence_interval', [0, 0])[0] if timeline_var.get('confidence_interval') else 0,
                timeline_variance_ci_high=timeline_var.get('confidence_interval', [0, 0])[1] if timeline_var.get('confidence_interval') else 0,
                monte_carlo_simulations=prediction_data.get('simulation_metadata', {}).get('simulations_run', 1000),
                confidence_level=prediction_data.get('simulation_metadata', {}).get('confidence_level', 95),
                model_confidence=completion_prob.get('std', 0.1),
                prediction_quality='high' if completion_prob.get('std', 0.1) < 0.1 else 'medium',
                best_case_scenario=prediction_data.get('risk_scenarios', {}).get('best_case'),
                worst_case_scenario=prediction_data.get('risk_scenarios', {}).get('worst_case'),
                most_likely_scenario=prediction_data.get('risk_scenarios', {}).get('most_likely'),
                ai_recommendations=prediction_data.get('ai_recommendations', [])
            )
            
            # Calculate estimated completion date
            if timeline_var.get('mean_days'):
                ml_prediction.estimated_completion_date = datetime.utcnow() + timedelta(days=timeline_var['mean_days'])
            
            self.session.add(ml_prediction)
            self.session.commit()
            
            logging.info(f"Saved ML prediction for project {project_key}")
            return True
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"Error saving ML prediction for {project_key}: {str(e)}")
            return False
    
    def get_latest_ml_prediction(self, project_key: str) -> Optional[MLPrediction]:
        """Get latest ML prediction for project"""
        try:
            project = self.get_project_by_key(project_key)
            if not project:
                return None
            
            return self.session.query(MLPrediction)\
                .filter_by(project_id=project.id)\
                .order_by(desc(MLPrediction.prediction_timestamp))\
                .first()
                
        except Exception as e:
            logging.error(f"Error getting latest ML prediction for {project_key}: {str(e)}")
            return None
    
    def get_prediction_history(self, project_key: str, days: int = 30) -> List[MLPrediction]:
        """Get ML prediction history for project"""
        try:
            project = self.get_project_by_key(project_key)
            if not project:
                return []
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            return self.session.query(MLPrediction)\
                .filter(and_(
                    MLPrediction.project_id == project.id,
                    MLPrediction.prediction_timestamp >= cutoff_date
                ))\
                .order_by(MLPrediction.prediction_timestamp)\
                .all()
                
        except Exception as e:
            logging.error(f"Error getting prediction history for {project_key}: {str(e)}")
            return []
    
    # Notification Logging
    def log_notification(self, project_key: str, alert_data: Dict[str, Any], delivery_status: Dict[str, bool] = None) -> bool:
        """Log notification sending attempt"""
        try:
            project = self.get_or_create_project(project_key)
            
            notification = NotificationLog(
                project_id=project.id,
                alert_type=alert_data.get('type', 'unknown'),
                severity=alert_data.get('severity', 'medium'),
                title=alert_data.get('title', ''),
                message=alert_data.get('message', ''),
                sent_to_slack=delivery_status.get('slack', False) if delivery_status else False,
                sent_to_teams=delivery_status.get('teams', False) if delivery_status else False,
                delivery_status='sent' if delivery_status and any(delivery_status.values()) else 'failed',
                alert_data=alert_data.get('data', {}),
                sent_at=datetime.utcnow() if delivery_status and any(delivery_status.values()) else None
            )
            
            self.session.add(notification)
            self.session.commit()
            
            return True
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"Error logging notification for {project_key}: {str(e)}")
            return False
    
    def get_recent_notifications(self, project_key: str = None, hours: int = 24) -> List[NotificationLog]:
        """Get recent notifications"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=hours)
            
            query = self.session.query(NotificationLog)\
                .filter(NotificationLog.created_at >= cutoff_time)
            
            if project_key:
                project = self.get_project_by_key(project_key)
                if project:
                    query = query.filter(NotificationLog.project_id == project.id)
            
            return query.order_by(desc(NotificationLog.created_at)).all()
            
        except Exception as e:
            logging.error(f"Error getting recent notifications: {str(e)}")
            return []
    
    # Model Performance Tracking
    def save_model_performance(self, model_type: str, metrics: Dict[str, Any]) -> bool:
        """Save model performance metrics"""
        try:
            performance = ModelPerformance(
                model_type=model_type,
                accuracy=metrics.get('accuracy', 0.0),
                mse=metrics.get('mse', 0.0),
                r2_score=metrics.get('r2_score', 0.0),
                training_samples=metrics.get('training_samples', 0),
                last_trained=datetime.utcnow(),
                model_drift_score=metrics.get('drift_score', 0.0),
                accuracy_history=metrics.get('accuracy_history', []),
                performance_trend=metrics.get('trend', 'stable')
            )
            
            self.session.add(performance)
            self.session.commit()
            
            return True
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"Error saving model performance for {model_type}: {str(e)}")
            return False
    
    def get_model_performance_history(self, model_type: str = None, days: int = 30) -> List[ModelPerformance]:
        """Get model performance history"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            query = self.session.query(ModelPerformance)\
                .filter(ModelPerformance.recorded_at >= cutoff_date)
            
            if model_type:
                query = query.filter(ModelPerformance.model_type == model_type)
            
            return query.order_by(ModelPerformance.recorded_at).all()
            
        except Exception as e:
            logging.error(f"Error getting model performance history: {str(e)}")
            return []
    
    # Data Update Tracking
    def log_data_update(self, project_key: str, update_type: str, results: Dict[str, Any]) -> bool:
        """Log data update operation"""
        try:
            project = self.get_or_create_project(project_key)
            
            data_update = DataUpdate(
                project_id=project.id,
                update_type=update_type,
                data_source=results.get('source', 'jira'),
                issues_updated=results.get('issues_updated', 0),
                new_issues=results.get('new_issues', 0),
                status_changes=results.get('status_changes', 0),
                processing_time_ms=results.get('processing_time_ms', 0),
                status=results.get('status', 'completed'),
                error_message=results.get('error_message'),
                completed_at=datetime.utcnow() if results.get('status') == 'completed' else None
            )
            
            self.session.add(data_update)
            self.session.commit()
            
            return True
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"Error logging data update for {project_key}: {str(e)}")
            return False
    
    # Analytics and Reporting
    def get_project_analytics(self, project_key: str, days: int = 30) -> Dict[str, Any]:
        """Get comprehensive project analytics"""
        try:
            project = self.get_project_by_key(project_key)
            if not project:
                return {}
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Get risk trend
            risk_assessments = self.session.query(RiskAssessment)\
                .filter(and_(
                    RiskAssessment.project_id == project.id,
                    RiskAssessment.analysis_timestamp >= cutoff_date
                ))\
                .order_by(RiskAssessment.analysis_timestamp)\
                .all()
            
            # Get prediction accuracy
            predictions = self.session.query(MLPrediction)\
                .filter(and_(
                    MLPrediction.project_id == project.id,
                    MLPrediction.prediction_timestamp >= cutoff_date
                ))\
                .order_by(MLPrediction.prediction_timestamp)\
                .all()
            
            # Get notification summary
            notifications = self.session.query(NotificationLog)\
                .filter(and_(
                    NotificationLog.project_id == project.id,
                    NotificationLog.created_at >= cutoff_date
                ))\
                .all()
            
            return {
                'project_key': project_key,
                'project_name': project.name,
                'analysis_period_days': days,
                'risk_assessments_count': len(risk_assessments),
                'predictions_count': len(predictions),
                'notifications_sent': len([n for n in notifications if n.delivery_status == 'sent']),
                'latest_risk_score': risk_assessments[-1].overall_risk_score if risk_assessments else 0,
                'risk_trend': risk_assessments[-1].risk_trend if risk_assessments else 'unknown',
                'latest_completion_probability': predictions[-1].completion_probability if predictions else 0,
                'prediction_confidence': predictions[-1].model_confidence if predictions else 0,
                'data_freshness_hours': (datetime.utcnow() - project.updated_at).total_seconds() / 3600 if project.updated_at else 0
            }
            
        except Exception as e:
            logging.error(f"Error getting project analytics for {project_key}: {str(e)}")
            return {}
    
    def get_system_health(self) -> Dict[str, Any]:
        """Get overall system health metrics"""
        try:
            # Count active projects
            active_projects = self.session.query(Project).count()
            
            # Recent assessments
            recent_assessments = self.session.query(RiskAssessment)\
                .filter(RiskAssessment.analysis_timestamp >= datetime.utcnow() - timedelta(hours=24))\
                .count()
            
            # Recent predictions
            recent_predictions = self.session.query(MLPrediction)\
                .filter(MLPrediction.prediction_timestamp >= datetime.utcnow() - timedelta(hours=24))\
                .count()
            
            # Recent notifications
            recent_notifications = self.session.query(NotificationLog)\
                .filter(NotificationLog.created_at >= datetime.utcnow() - timedelta(hours=24))\
                .count()
            
            # Model performance
            latest_model_perf = self.session.query(ModelPerformance)\
                .order_by(desc(ModelPerformance.recorded_at))\
                .first()
            
            return {
                'active_projects': active_projects,
                'assessments_24h': recent_assessments,
                'predictions_24h': recent_predictions,
                'notifications_24h': recent_notifications,
                'latest_model_accuracy': latest_model_perf.accuracy if latest_model_perf else 0,
                'system_status': 'healthy' if recent_assessments > 0 else 'idle',
                'database_status': 'connected',
                'last_update': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logging.error(f"Error getting system health: {str(e)}")
            return {'system_status': 'error', 'error': str(e)}
    
    # Cleanup Operations
    def cleanup_old_data(self, days_to_keep: int = 90) -> Dict[str, int]:
        """Clean up old data beyond retention period"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
            
            # Delete old risk assessments
            old_assessments = self.session.query(RiskAssessment)\
                .filter(RiskAssessment.analysis_timestamp < cutoff_date)\
                .delete()
            
            # Delete old predictions
            old_predictions = self.session.query(MLPrediction)\
                .filter(MLPrediction.prediction_timestamp < cutoff_date)\
                .delete()
            
            # Delete old notifications
            old_notifications = self.session.query(NotificationLog)\
                .filter(NotificationLog.created_at < cutoff_date)\
                .delete()
            
            # Delete old data updates
            old_updates = self.session.query(DataUpdate)\
                .filter(DataUpdate.started_at < cutoff_date)\
                .delete()
            
            self.session.commit()
            
            return {
                'risk_assessments_deleted': old_assessments,
                'predictions_deleted': old_predictions,
                'notifications_deleted': old_notifications,
                'data_updates_deleted': old_updates
            }
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"Error during cleanup: {str(e)}")
            return {'error': str(e)}