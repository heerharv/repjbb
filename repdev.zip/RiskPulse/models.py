from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Boolean, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

# Import db after declaration to avoid circular imports
def get_db():
    from app import db
    return db

class Project(get_db().Model):
    __tablename__ = 'projects'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    risk_assessments = relationship("RiskAssessment", back_populates="project")
    ml_predictions = relationship("MLPrediction", back_populates="project")
    notifications = relationship("NotificationLog", back_populates="project")

class RiskAssessment(db.Model):
    __tablename__ = 'risk_assessments'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    
    # Risk Scores
    overall_risk_score = db.Column(db.Float, nullable=False)
    completion_risk = db.Column(db.Float)
    budget_risk = db.Column(db.Float)
    timeline_risk = db.Column(db.Float)
    quality_risk = db.Column(db.Float)
    resource_risk = db.Column(db.Float)
    
    # Risk Categories
    severity_level = db.Column(db.String(20))  # low, medium, high, critical
    risk_trend = db.Column(db.String(20))      # improving, stable, deteriorating
    
    # Metrics
    total_issues = db.Column(db.Integer)
    completed_issues = db.Column(db.Integer)
    overdue_issues = db.Column(db.Integer)
    blocked_issues = db.Column(db.Integer)
    
    # Analysis Results
    velocity_score = db.Column(db.Float)
    team_performance_score = db.Column(db.Float)
    dependency_risk = db.Column(db.Float)
    
    # Metadata
    analysis_timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    analysis_version = db.Column(db.String(20), default='1.0')
    
    # Relationships
    project = relationship("Project", back_populates="risk_assessments")

class MLPrediction(db.Model):
    __tablename__ = 'ml_predictions'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    
    # Prediction Results
    completion_probability = db.Column(db.Float)
    completion_probability_ci_low = db.Column(db.Float)
    completion_probability_ci_high = db.Column(db.Float)
    
    budget_overrun_probability = db.Column(db.Float)
    budget_overrun_ci_low = db.Column(db.Float)
    budget_overrun_ci_high = db.Column(db.Float)
    
    timeline_variance_days = db.Column(db.Float)
    timeline_variance_ci_low = db.Column(db.Float)
    timeline_variance_ci_high = db.Column(db.Float)
    
    estimated_completion_date = db.Column(db.DateTime)
    
    # Monte Carlo Results
    monte_carlo_simulations = db.Column(db.Integer, default=1000)
    confidence_level = db.Column(db.Float, default=0.95)
    
    # Model Performance
    model_accuracy = db.Column(db.Float)
    model_confidence = db.Column(db.Float)
    prediction_quality = db.Column(db.String(20))  # high, medium, low
    
    # Scenarios (JSON)
    best_case_scenario = db.Column(db.JSON)
    worst_case_scenario = db.Column(db.JSON)
    most_likely_scenario = db.Column(db.JSON)
    
    # AI Recommendations (JSON)
    ai_recommendations = db.Column(db.JSON)
    
    # Metadata
    prediction_timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    model_version = db.Column(db.String(20), default='1.0')
    
    # Relationships
    project = relationship("Project", back_populates="ml_predictions")

class NotificationLog(db.Model):
    __tablename__ = 'notification_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    
    # Alert Details
    alert_type = db.Column(db.String(50), nullable=False)
    severity = db.Column(db.String(20), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text)
    
    # Integration Details
    sent_to_slack = db.Column(db.Boolean, default=False)
    sent_to_teams = db.Column(db.Boolean, default=False)
    delivery_status = db.Column(db.String(20), default='pending')
    
    # Alert Data (JSON)
    alert_data = db.Column(db.JSON)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    sent_at = db.Column(db.DateTime)
    
    # Relationships
    project = relationship("Project", back_populates="notifications")

class ModelPerformance(db.Model):
    __tablename__ = 'model_performance'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Model Metrics
    model_type = db.Column(db.String(50), nullable=False)  # completion, budget, timeline
    accuracy = db.Column(db.Float)
    mse = db.Column(db.Float)
    r2_score = db.Column(db.Float)
    
    # Training Details
    training_samples = db.Column(db.Integer)
    last_trained = db.Column(db.DateTime)
    model_drift_score = db.Column(db.Float, default=0.0)
    
    # Performance History (JSON)
    accuracy_history = db.Column(db.JSON)
    performance_trend = db.Column(db.String(20))  # improving, stable, declining
    
    # Metadata
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow)
    version = db.Column(db.String(20), default='1.0')

class DataUpdate(db.Model):
    __tablename__ = 'data_updates'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    
    # Update Details
    update_type = db.Column(db.String(50), nullable=False)  # scheduled, real_time, manual
    data_source = db.Column(db.String(50), default='jira')
    
    # Update Results
    issues_updated = db.Column(db.Integer, default=0)
    new_issues = db.Column(db.Integer, default=0)
    status_changes = db.Column(db.Integer, default=0)
    
    # Processing Time
    processing_time_ms = db.Column(db.Integer)
    
    # Status
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    error_message = db.Column(db.Text)
    
    # Metadata
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    # Relationships
    project = relationship("Project")