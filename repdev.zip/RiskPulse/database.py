import sqlite3
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
from contextlib import contextmanager
import os

# Database schema and initialization
DB_FILE = 'risk_metrics.db'

class RiskMetrics:
    """Database model for risk metrics storage"""
    
    def __init__(self):
        self.db_file = DB_FILE
        
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = None
        try:
            conn = sqlite3.connect(self.db_file)
            conn.row_factory = sqlite3.Row  # Enable column access by name
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            logging.error(f"Database error: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
    
    def create_tables(self):
        """Create database tables if they don't exist"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Risk analysis results table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS risk_analysis (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_key TEXT NOT NULL,
                        analysis_type TEXT NOT NULL,
                        analysis_data TEXT NOT NULL,
                        risk_score REAL,
                        confidence_level REAL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Project metrics table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS project_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_key TEXT NOT NULL,
                        metric_name TEXT NOT NULL,
                        metric_value REAL,
                        metric_data TEXT,
                        measurement_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Risk predictions table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS risk_predictions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_key TEXT NOT NULL,
                        prediction_type TEXT NOT NULL,
                        prediction_data TEXT NOT NULL,
                        accuracy_score REAL,
                        prediction_date TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Automated insights table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS automated_insights (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_key TEXT NOT NULL,
                        insight_type TEXT NOT NULL,
                        insight_title TEXT NOT NULL,
                        insight_description TEXT NOT NULL,
                        severity_level TEXT NOT NULL,
                        recommendations TEXT,
                        is_active BOOLEAN DEFAULT 1,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Historical trends table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS historical_trends (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_key TEXT NOT NULL,
                        trend_type TEXT NOT NULL,
                        time_period TEXT NOT NULL,
                        trend_data TEXT NOT NULL,
                        trend_direction TEXT,
                        trend_strength REAL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Create indexes for better query performance
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_risk_analysis_project ON risk_analysis(project_key)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_project_metrics_project ON project_metrics(project_key)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_risk_predictions_project ON risk_predictions(project_key)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_automated_insights_project ON automated_insights(project_key)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_historical_trends_project ON historical_trends(project_key)')
                
                conn.commit()
                logging.info("Database tables created successfully")
                
        except Exception as e:
            logging.error(f"Error creating database tables: {str(e)}")
            raise
    
    def store_risk_analysis(self, project_key: str, analysis_type: str, analysis_data: Dict, risk_score: float = None, confidence_level: float = None):
        """Store risk analysis results"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Check if analysis already exists for today
                cursor.execute('''
                    SELECT id FROM risk_analysis 
                    WHERE project_key = ? AND analysis_type = ? 
                    AND DATE(created_at) = DATE('now')
                ''', (project_key, analysis_type))
                
                existing = cursor.fetchone()
                
                if existing:
                    # Update existing record
                    cursor.execute('''
                        UPDATE risk_analysis 
                        SET analysis_data = ?, risk_score = ?, confidence_level = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ''', (json.dumps(analysis_data), risk_score, confidence_level, existing['id']))
                else:
                    # Insert new record
                    cursor.execute('''
                        INSERT INTO risk_analysis (project_key, analysis_type, analysis_data, risk_score, confidence_level)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (project_key, analysis_type, json.dumps(analysis_data), risk_score, confidence_level))
                
                conn.commit()
                logging.info(f"Risk analysis stored for project {project_key}, type {analysis_type}")
                
        except Exception as e:
            logging.error(f"Error storing risk analysis: {str(e)}")
            raise
    
    def get_risk_analysis(self, project_key: str, analysis_type: str = None, days_back: int = 30) -> List[Dict]:
        """Retrieve risk analysis results"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                if analysis_type:
                    cursor.execute('''
                        SELECT * FROM risk_analysis 
                        WHERE project_key = ? AND analysis_type = ?
                        AND created_at >= datetime('now', '-{} days')
                        ORDER BY created_at DESC
                    '''.format(days_back), (project_key, analysis_type))
                else:
                    cursor.execute('''
                        SELECT * FROM risk_analysis 
                        WHERE project_key = ?
                        AND created_at >= datetime('now', '-{} days')
                        ORDER BY created_at DESC
                    '''.format(days_back), (project_key,))
                
                results = []
                for row in cursor.fetchall():
                    result = dict(row)
                    result['analysis_data'] = json.loads(result['analysis_data'])
                    results.append(result)
                
                return results
                
        except Exception as e:
            logging.error(f"Error retrieving risk analysis: {str(e)}")
            return []
    
    def store_project_metric(self, project_key: str, metric_name: str, metric_value: float, metric_data: Dict = None):
        """Store project metric value"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO project_metrics (project_key, metric_name, metric_value, metric_data)
                    VALUES (?, ?, ?, ?)
                ''', (project_key, metric_name, metric_value, json.dumps(metric_data) if metric_data else None))
                
                conn.commit()
                logging.debug(f"Metric {metric_name} stored for project {project_key}")
                
        except Exception as e:
            logging.error(f"Error storing project metric: {str(e)}")
            raise
    
    def get_project_metrics(self, project_key: str, metric_name: str = None, days_back: int = 90) -> List[Dict]:
        """Retrieve project metrics"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                if metric_name:
                    cursor.execute('''
                        SELECT * FROM project_metrics 
                        WHERE project_key = ? AND metric_name = ?
                        AND measurement_date >= datetime('now', '-{} days')
                        ORDER BY measurement_date DESC
                    '''.format(days_back), (project_key, metric_name))
                else:
                    cursor.execute('''
                        SELECT * FROM project_metrics 
                        WHERE project_key = ?
                        AND measurement_date >= datetime('now', '-{} days')
                        ORDER BY measurement_date DESC
                    '''.format(days_back), (project_key,))
                
                results = []
                for row in cursor.fetchall():
                    result = dict(row)
                    if result['metric_data']:
                        result['metric_data'] = json.loads(result['metric_data'])
                    results.append(result)
                
                return results
                
        except Exception as e:
            logging.error(f"Error retrieving project metrics: {str(e)}")
            return []
    
    def store_prediction(self, project_key: str, prediction_type: str, prediction_data: Dict, accuracy_score: float = None, prediction_date: datetime = None):
        """Store risk prediction"""
        try:
            if prediction_date is None:
                prediction_date = datetime.now()
                
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO risk_predictions (project_key, prediction_type, prediction_data, accuracy_score, prediction_date)
                    VALUES (?, ?, ?, ?, ?)
                ''', (project_key, prediction_type, json.dumps(prediction_data), accuracy_score, prediction_date.isoformat()))
                
                conn.commit()
                logging.info(f"Prediction {prediction_type} stored for project {project_key}")
                
        except Exception as e:
            logging.error(f"Error storing prediction: {str(e)}")
            raise
    
    def get_predictions(self, project_key: str, prediction_type: str = None, days_back: int = 30) -> List[Dict]:
        """Retrieve predictions"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                if prediction_type:
                    cursor.execute('''
                        SELECT * FROM risk_predictions 
                        WHERE project_key = ? AND prediction_type = ?
                        AND created_at >= datetime('now', '-{} days')
                        ORDER BY created_at DESC
                    '''.format(days_back), (project_key, prediction_type))
                else:
                    cursor.execute('''
                        SELECT * FROM risk_predictions 
                        WHERE project_key = ?
                        AND created_at >= datetime('now', '-{} days')
                        ORDER BY created_at DESC
                    '''.format(days_back), (project_key,))
                
                results = []
                for row in cursor.fetchall():
                    result = dict(row)
                    result['prediction_data'] = json.loads(result['prediction_data'])
                    results.append(result)
                
                return results
                
        except Exception as e:
            logging.error(f"Error retrieving predictions: {str(e)}")
            return []
    
    def store_insight(self, project_key: str, insight_type: str, title: str, description: str, severity: str, recommendations: List[str] = None):
        """Store automated insight"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Check if similar insight already exists
                cursor.execute('''
                    SELECT id FROM automated_insights 
                    WHERE project_key = ? AND insight_type = ? AND insight_title = ?
                    AND created_at >= datetime('now', '-1 day')
                ''', (project_key, insight_type, title))
                
                existing = cursor.fetchone()
                
                if not existing:
                    cursor.execute('''
                        INSERT INTO automated_insights 
                        (project_key, insight_type, insight_title, insight_description, severity_level, recommendations)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ''', (project_key, insight_type, title, description, severity, json.dumps(recommendations) if recommendations else None))
                    
                    conn.commit()
                    logging.info(f"Insight stored for project {project_key}: {title}")
                
        except Exception as e:
            logging.error(f"Error storing insight: {str(e)}")
            raise
    
    def get_insights(self, project_key: str, insight_type: str = None, active_only: bool = True, days_back: int = 7) -> List[Dict]:
        """Retrieve automated insights"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                query = '''
                    SELECT * FROM automated_insights 
                    WHERE project_key = ?
                    AND created_at >= datetime('now', '-{} days')
                '''.format(days_back)
                
                params = [project_key]
                
                if insight_type:
                    query += ' AND insight_type = ?'
                    params.append(insight_type)
                
                if active_only:
                    query += ' AND is_active = 1'
                
                query += ' ORDER BY created_at DESC'
                
                cursor.execute(query, params)
                
                results = []
                for row in cursor.fetchall():
                    result = dict(row)
                    if result['recommendations']:
                        result['recommendations'] = json.loads(result['recommendations'])
                    results.append(result)
                
                return results
                
        except Exception as e:
            logging.error(f"Error retrieving insights: {str(e)}")
            return []
    
    def store_trend(self, project_key: str, trend_type: str, time_period: str, trend_data: Dict, trend_direction: str = None, trend_strength: float = None):
        """Store historical trend data"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO historical_trends 
                    (project_key, trend_type, time_period, trend_data, trend_direction, trend_strength)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (project_key, trend_type, time_period, json.dumps(trend_data), trend_direction, trend_strength))
                
                conn.commit()
                logging.debug(f"Trend {trend_type} stored for project {project_key}")
                
        except Exception as e:
            logging.error(f"Error storing trend: {str(e)}")
            raise
    
    def get_trends(self, project_key: str, trend_type: str = None, days_back: int = 90) -> List[Dict]:
        """Retrieve historical trends"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                if trend_type:
                    cursor.execute('''
                        SELECT * FROM historical_trends 
                        WHERE project_key = ? AND trend_type = ?
                        AND created_at >= datetime('now', '-{} days')
                        ORDER BY created_at DESC
                    '''.format(days_back), (project_key, trend_type))
                else:
                    cursor.execute('''
                        SELECT * FROM historical_trends 
                        WHERE project_key = ?
                        AND created_at >= datetime('now', '-{} days')
                        ORDER BY created_at DESC
                    '''.format(days_back), (project_key,))
                
                results = []
                for row in cursor.fetchall():
                    result = dict(row)
                    result['trend_data'] = json.loads(result['trend_data'])
                    results.append(result)
                
                return results
                
        except Exception as e:
            logging.error(f"Error retrieving trends: {str(e)}")
            return []
    
    def cleanup_old_data(self, days_to_keep: int = 90):
        """Clean up old data beyond retention period"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                tables = ['risk_analysis', 'project_metrics', 'risk_predictions', 'automated_insights', 'historical_trends']
                
                for table in tables:
                    cursor.execute(f'''
                        DELETE FROM {table} 
                        WHERE created_at < datetime('now', '-{days_to_keep} days')
                    ''')
                
                deleted_rows = cursor.rowcount
                conn.commit()
                
                if deleted_rows > 0:
                    logging.info(f"Cleaned up {deleted_rows} old records")
                
        except Exception as e:
            logging.error(f"Error cleaning up old data: {str(e)}")
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                stats = {}
                tables = ['risk_analysis', 'project_metrics', 'risk_predictions', 'automated_insights', 'historical_trends']
                
                for table in tables:
                    cursor.execute(f'SELECT COUNT(*) as count FROM {table}')
                    stats[f'{table}_count'] = cursor.fetchone()['count']
                
                # Get database file size
                if os.path.exists(self.db_file):
                    stats['database_size_mb'] = round(os.path.getsize(self.db_file) / (1024 * 1024), 2)
                else:
                    stats['database_size_mb'] = 0
                
                return stats
                
        except Exception as e:
            logging.error(f"Error getting database stats: {str(e)}")
            return {}

def init_db():
    """Initialize the database"""
    try:
        risk_metrics = RiskMetrics()
        risk_metrics.create_tables()
        logging.info("Database initialized successfully")
        return True
    except Exception as e:
        logging.error(f"Database initialization failed: {str(e)}")
        return False

# Utility functions for common database operations
def store_analysis_results(project_key: str, analysis_results: Dict):
    """Store comprehensive analysis results"""
    try:
        risk_metrics = RiskMetrics()
        
        # Store overall risk analysis
        if 'overall_risk_score' in analysis_results:
            risk_metrics.store_risk_analysis(
                project_key=project_key,
                analysis_type='comprehensive',
                analysis_data=analysis_results,
                risk_score=analysis_results['overall_risk_score']
            )
        
        # Store individual metric components
        for metric_name, metric_data in analysis_results.items():
            if isinstance(metric_data, dict) and 'score' in str(metric_data):
                # Extract numeric scores for trending
                for key, value in metric_data.items():
                    if isinstance(value, (int, float)) and 'score' in key:
                        risk_metrics.store_project_metric(
                            project_key=project_key,
                            metric_name=f"{metric_name}_{key}",
                            metric_value=value,
                            metric_data={'context': metric_name}
                        )
        
        # Generate and store insights
        if 'risk_level' in analysis_results:
            risk_level = analysis_results['risk_level']
            if risk_level in ['high', 'critical']:
                risk_metrics.store_insight(
                    project_key=project_key,
                    insight_type='risk_alert',
                    title=f'Project Risk Level: {risk_level.title()}',
                    description=f'Project {project_key} shows {risk_level} risk level requiring attention',
                    severity=risk_level,
                    recommendations=['Review risk mitigation strategies', 'Consider resource reallocation']
                )
        
        logging.info(f"Analysis results stored for project {project_key}")
        return True
        
    except Exception as e:
        logging.error(f"Error storing analysis results: {str(e)}")
        return False

def get_project_dashboard_data(project_key: str) -> Dict[str, Any]:
    """Get comprehensive dashboard data for a project"""
    try:
        risk_metrics = RiskMetrics()
        
        dashboard_data = {
            'recent_analysis': risk_metrics.get_risk_analysis(project_key, days_back=7),
            'key_metrics': risk_metrics.get_project_metrics(project_key, days_back=30),
            'predictions': risk_metrics.get_predictions(project_key, days_back=30),
            'active_insights': risk_metrics.get_insights(project_key, active_only=True),
            'trends': risk_metrics.get_trends(project_key, days_back=60)
        }
        
        return dashboard_data
        
    except Exception as e:
        logging.error(f"Error getting dashboard data: {str(e)}")
        return {}
