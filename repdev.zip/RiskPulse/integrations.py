import os
import json
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import requests
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
import threading
import time
from dataclasses import dataclass

@dataclass
class IntegrationAlert:
    """Data class for integration alerts"""
    type: str
    severity: str
    title: str
    message: str
    project_key: str
    timestamp: datetime
    data: Dict[str, Any]

class SlackIntegration:
    """Advanced Slack integration for real-time risk alerts and notifications"""
    
    def __init__(self):
        self.slack_token = os.environ.get('SLACK_BOT_TOKEN')
        self.slack_channel_id = os.environ.get('SLACK_CHANNEL_ID')
        self.client = None
        self.is_connected = False
        
        if self.slack_token and self.slack_channel_id:
            try:
                self.client = WebClient(token=self.slack_token)
                self._test_connection()
                logging.info("Slack integration initialized successfully")
            except Exception as e:
                logging.error(f"Slack initialization failed: {str(e)}")
        else:
            logging.warning("Slack credentials not provided - integration disabled")
    
    def _test_connection(self):
        """Test Slack connection"""
        try:
            response = self.client.auth_test()
            if response["ok"]:
                self.is_connected = True
                logging.info(f"Connected to Slack as {response['user']}")
            else:
                logging.error("Slack connection test failed")
        except SlackApiError as e:
            logging.error(f"Slack connection error: {e.response['error']}")
    
    def send_risk_alert(self, alert: IntegrationAlert) -> bool:
        """Send risk alert to Slack channel"""
        if not self.is_connected:
            logging.warning("Slack not connected - cannot send alert")
            return False
        
        try:
            # Create rich message format
            blocks = self._create_alert_blocks(alert)
            
            response = self.client.chat_postMessage(
                channel=self.slack_channel_id,
                text=f"Risk Alert: {alert.title}",
                blocks=blocks
            )
            
            if response["ok"]:
                logging.info(f"Risk alert sent to Slack: {alert.title}")
                return True
            else:
                logging.error("Failed to send Slack message")
                return False
                
        except SlackApiError as e:
            logging.error(f"Slack API error: {e.response['error']}")
            return False
    
    def _create_alert_blocks(self, alert: IntegrationAlert) -> List[Dict]:
        """Create Slack block layout for risk alerts"""
        severity_color = {
            'critical': '#FF0000',
            'high': '#FF6600',
            'medium': '#FFCC00',
            'low': '#00CC00'
        }.get(alert.severity, '#808080')
        
        severity_emoji = {
            'critical': '🚨',
            'high': '⚠️',
            'medium': '📋',
            'low': 'ℹ️'
        }.get(alert.severity, '📊')
        
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{severity_emoji} {alert.title}"
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Project:* {alert.project_key}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Severity:* {alert.severity.upper()}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Type:* {alert.type}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Time:* {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"
                    }
                ]
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": alert.message
                }
            }
        ]
        
        # Add data insights if available
        if alert.data:
            data_text = self._format_alert_data(alert.data)
            if data_text:
                blocks.append({
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Key Metrics:*\n{data_text}"
                    }
                })
        
        # Add action buttons
        blocks.append({
            "type": "actions",
            "elements": [
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": "View Dashboard"
                    },
                    "style": "primary",
                    "url": f"{os.environ.get('BASE_URL', 'http://localhost:5000')}/?project={alert.project_key}"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": "View Analysis"
                    },
                    "url": f"{os.environ.get('BASE_URL', 'http://localhost:5000')}/analysis/{alert.project_key}"
                }
            ]
        })
        
        return blocks
    
    def _format_alert_data(self, data: Dict[str, Any]) -> str:
        """Format alert data for display"""
        formatted_items = []
        
        for key, value in data.items():
            if isinstance(value, float):
                if 0 < value < 1:
                    formatted_items.append(f"• {key.replace('_', ' ').title()}: {value:.1%}")
                else:
                    formatted_items.append(f"• {key.replace('_', ' ').title()}: {value:.1f}")
            elif isinstance(value, int):
                formatted_items.append(f"• {key.replace('_', ' ').title()}: {value}")
            elif isinstance(value, str):
                formatted_items.append(f"• {key.replace('_', ' ').title()}: {value}")
        
        return '\n'.join(formatted_items[:5])  # Limit to 5 items
    
    def send_daily_summary(self, project_summaries: List[Dict[str, Any]]) -> bool:
        """Send daily project risk summary"""
        if not self.is_connected:
            return False
        
        try:
            blocks = self._create_summary_blocks(project_summaries)
            
            response = self.client.chat_postMessage(
                channel=self.slack_channel_id,
                text="Daily Risk Summary",
                blocks=blocks
            )
            
            return response["ok"]
            
        except SlackApiError as e:
            logging.error(f"Failed to send daily summary: {e}")
            return False
    
    def _create_summary_blocks(self, summaries: List[Dict[str, Any]]) -> List[Dict]:
        """Create blocks for daily summary"""
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"📊 Daily Risk Summary - {datetime.now().strftime('%Y-%m-%d')}"
                }
            }
        ]
        
        for summary in summaries[:5]:  # Limit to 5 projects
            project_text = f"*{summary['project_key']}*\n"
            project_text += f"Risk Level: {summary.get('risk_level', 'Unknown')}\n"
            project_text += f"Completion: {summary.get('completion_percentage', 0):.0f}%\n"
            project_text += f"Issues: {summary.get('total_issues', 0)} total, {summary.get('overdue_issues', 0)} overdue"
            
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": project_text
                }
            })
        
        return blocks


class TeamsIntegration:
    """Microsoft Teams integration for risk notifications"""
    
    def __init__(self):
        self.webhook_url = os.environ.get('TEAMS_WEBHOOK_URL')
        self.is_connected = bool(self.webhook_url)
        
        if self.is_connected:
            logging.info("Teams integration initialized successfully")
        else:
            logging.warning("Teams webhook URL not provided - integration disabled")
    
    def send_risk_alert(self, alert: IntegrationAlert) -> bool:
        """Send risk alert to Teams channel"""
        if not self.is_connected:
            logging.warning("Teams not connected - cannot send alert")
            return False
        
        try:
            card = self._create_alert_card(alert)
            
            response = requests.post(
                self.webhook_url,
                json=card,
                headers={'Content-Type': 'application/json'},
                timeout=30
            )
            
            if response.status_code == 200:
                logging.info(f"Risk alert sent to Teams: {alert.title}")
                return True
            else:
                logging.error(f"Teams API error: {response.status_code}")
                return False
                
        except Exception as e:
            logging.error(f"Teams integration error: {str(e)}")
            return False
    
    def _create_alert_card(self, alert: IntegrationAlert) -> Dict[str, Any]:
        """Create Teams adaptive card for risk alerts"""
        severity_color = {
            'critical': 'attention',
            'high': 'warning',
            'medium': 'accent',
            'low': 'good'
        }.get(alert.severity, 'default')
        
        card = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": {
                'critical': 'FF0000',
                'high': 'FF6600',
                'medium': 'FFCC00',
                'low': '00CC00'
            }.get(alert.severity, '808080'),
            "summary": f"Risk Alert: {alert.title}",
            "sections": [
                {
                    "activityTitle": f"🚨 {alert.title}",
                    "activitySubtitle": f"Project: {alert.project_key}",
                    "activityImage": "https://via.placeholder.com/64x64/FF6600/FFFFFF?text=!",
                    "facts": [
                        {
                            "name": "Severity",
                            "value": alert.severity.upper()
                        },
                        {
                            "name": "Type",
                            "value": alert.type
                        },
                        {
                            "name": "Timestamp",
                            "value": alert.timestamp.strftime('%Y-%m-%d %H:%M:%S')
                        }
                    ],
                    "markdown": True,
                    "text": alert.message
                }
            ],
            "potentialAction": [
                {
                    "@type": "OpenUri",
                    "name": "View Dashboard",
                    "targets": [
                        {
                            "os": "default",
                            "uri": f"{os.environ.get('BASE_URL', 'http://localhost:5000')}/?project={alert.project_key}"
                        }
                    ]
                }
            ]
        }
        
        # Add data facts if available
        if alert.data:
            for key, value in list(alert.data.items())[:3]:  # Limit to 3 additional facts
                if isinstance(value, (int, float)):
                    card["sections"][0]["facts"].append({
                        "name": key.replace('_', ' ').title(),
                        "value": f"{value:.1%}" if 0 < value < 1 else str(value)
                    })
        
        return card


class IntegrationManager:
    """Manages all external integrations and real-time notifications"""
    
    def __init__(self):
        self.slack = SlackIntegration()
        self.teams = TeamsIntegration()
        self.alert_queue = []
        self.alert_history = []
        self.notification_rules = self._load_notification_rules()
        
        # Start background notification processor
        self._start_notification_processor()
        logging.info("Integration manager initialized")
    
    def _load_notification_rules(self) -> Dict[str, Any]:
        """Load notification rules and thresholds"""
        return {
            'risk_thresholds': {
                'critical': {'min_score': 0.8, 'immediate': True},
                'high': {'min_score': 0.6, 'immediate': True},
                'medium': {'min_score': 0.4, 'immediate': False},
                'low': {'min_score': 0.0, 'immediate': False}
            },
            'notification_intervals': {
                'critical': timedelta(minutes=5),   # Every 5 minutes
                'high': timedelta(minutes=30),      # Every 30 minutes
                'medium': timedelta(hours=2),       # Every 2 hours
                'low': timedelta(hours=8)           # Every 8 hours
            },
            'escalation_rules': {
                'unresolved_critical': timedelta(hours=1),
                'unresolved_high': timedelta(hours=4),
                'repeat_threshold': 3
            }
        }
    
    def send_risk_alert(self, alert_data: Dict[str, Any]) -> bool:
        """Process and send risk alert through appropriate channels"""
        try:
            alert = IntegrationAlert(
                type=alert_data.get('type', 'risk_alert'),
                severity=alert_data.get('severity', 'medium'),
                title=alert_data.get('title', 'Risk Alert'),
                message=alert_data.get('message', 'A risk has been detected'),
                project_key=alert_data.get('project_key', 'UNKNOWN'),
                timestamp=datetime.now(),
                data=alert_data.get('data', {})
            )
            
            # Check if alert should be sent based on rules
            if not self._should_send_alert(alert):
                return False
            
            # Add to queue for processing
            self.alert_queue.append(alert)
            
            # Send immediate alerts for critical/high severity
            if alert.severity in ['critical', 'high']:
                return self._send_alert_immediately(alert)
            
            return True
            
        except Exception as e:
            logging.error(f"Error processing risk alert: {str(e)}")
            return False
    
    def _should_send_alert(self, alert: IntegrationAlert) -> bool:
        """Determine if alert should be sent based on rules and history"""
        # Check for duplicate alerts within time window
        recent_alerts = [
            a for a in self.alert_history 
            if a.project_key == alert.project_key 
            and a.type == alert.type
            and a.timestamp > datetime.now() - timedelta(hours=1)
        ]
        
        if len(recent_alerts) >= 3:  # Don't spam same alert
            return False
        
        # Check minimum threshold
        risk_score = alert.data.get('risk_score', 0.5)
        min_threshold = self.notification_rules['risk_thresholds'].get(
            alert.severity, {}
        ).get('min_score', 0.4)
        
        return risk_score >= min_threshold
    
    def _send_alert_immediately(self, alert: IntegrationAlert) -> bool:
        """Send alert immediately through all available channels"""
        results = []
        
        # Send to Slack
        if self.slack.is_connected:
            results.append(self.slack.send_risk_alert(alert))
        
        # Send to Teams
        if self.teams.is_connected:
            results.append(self.teams.send_risk_alert(alert))
        
        # Add to history
        self.alert_history.append(alert)
        
        # Clean up old history
        cutoff_time = datetime.now() - timedelta(days=7)
        self.alert_history = [a for a in self.alert_history if a.timestamp > cutoff_time]
        
        return any(results)
    
    def _start_notification_processor(self):
        """Start background thread for processing queued notifications"""
        def processor():
            while True:
                try:
                    if self.alert_queue:
                        alert = self.alert_queue.pop(0)
                        self._send_alert_immediately(alert)
                    
                    time.sleep(10)  # Check every 10 seconds
                    
                except Exception as e:
                    logging.error(f"Notification processor error: {str(e)}")
                    time.sleep(60)  # Wait longer on error
        
        processor_thread = threading.Thread(target=processor, daemon=True)
        processor_thread.start()
        logging.info("Notification processor started")
    
    def send_daily_summary(self, project_summaries: List[Dict[str, Any]]) -> bool:
        """Send daily summary to all channels"""
        results = []
        
        if self.slack.is_connected:
            results.append(self.slack.send_daily_summary(project_summaries))
        
        # Teams daily summary would be implemented similarly
        
        return any(results)
    
    def send_ml_model_update(self, model_metrics: Dict[str, Any]) -> bool:
        """Send ML model performance updates"""
        alert_data = {
            'type': 'ml_model_update',
            'severity': 'medium',
            'title': 'ML Model Performance Update',
            'message': f"Risk prediction models have been updated with new accuracy: {model_metrics.get('accuracy', 0.8):.1%}",
            'project_key': 'SYSTEM',
            'data': {
                'accuracy': model_metrics.get('accuracy', 0.8),
                'mse': model_metrics.get('mse', 0.1),
                'training_samples': model_metrics.get('training_samples', 0),
                'last_update': datetime.now().isoformat()
            }
        }
        
        return self.send_risk_alert(alert_data)
    
    def send_prediction_alert(self, prediction_results: Dict[str, Any], project_key: str) -> bool:
        """Send alerts based on prediction results"""
        completion_prob = prediction_results.get('completion_probability', {}).get('mean', 0.7)
        budget_risk = prediction_results.get('budget_overrun_risk', {}).get('mean', 0.3)
        
        # Determine severity based on predictions
        if completion_prob < 0.4 or budget_risk > 0.7:
            severity = 'critical'
        elif completion_prob < 0.6 or budget_risk > 0.5:
            severity = 'high'
        elif completion_prob < 0.8 or budget_risk > 0.3:
            severity = 'medium'
        else:
            severity = 'low'
        
        # Create message based on risk factors
        risk_factors = []
        if completion_prob < 0.6:
            risk_factors.append(f"Low completion probability ({completion_prob:.1%})")
        if budget_risk > 0.4:
            risk_factors.append(f"High budget overrun risk ({budget_risk:.1%})")
        
        if not risk_factors:
            return True  # No alerts needed for good predictions
        
        message = f"Predictive analysis indicates risks: {', '.join(risk_factors)}"
        
        alert_data = {
            'type': 'prediction_alert',
            'severity': severity,
            'title': f'Predictive Risk Alert - {project_key}',
            'message': message,
            'project_key': project_key,
            'data': {
                'completion_probability': completion_prob,
                'budget_overrun_risk': budget_risk,
                'timeline_variance': prediction_results.get('timeline_variance', {}).get('mean_days', 0)
            }
        }
        
        return self.send_risk_alert(alert_data)


class RealTimeDataProcessor:
    """Processes real-time data updates and triggers ML model retraining"""
    
    def __init__(self, risk_predictor, integration_manager):
        self.risk_predictor = risk_predictor
        self.integration_manager = integration_manager
        self.data_buffer = []
        self.processing_lock = threading.Lock()
        self.last_model_update = datetime.now()
        self.update_threshold = timedelta(hours=4)
        
        # Start real-time processor
        self._start_real_time_processor()
        logging.info("Real-time data processor initialized")
    
    def process_project_update(self, project_key: str, project_data: Dict[str, Any]) -> bool:
        """Process real-time project data update"""
        try:
            with self.processing_lock:
                # Add to buffer
                self.data_buffer.append({
                    'project_key': project_key,
                    'data': project_data,
                    'timestamp': datetime.now(),
                    'processed': False
                })
                
                # Trigger immediate analysis for critical changes
                self._analyze_immediate_risks(project_key, project_data)
                
                # Update ML model if needed
                if self._should_update_model():
                    self._trigger_model_update()
                
                return True
                
        except Exception as e:
            logging.error(f"Error processing project update: {str(e)}")
            return False
    
    def _analyze_immediate_risks(self, project_key: str, project_data: Dict[str, Any]):
        """Analyze data for immediate risk indicators"""
        issues = project_data.get('issues', [])
        if not issues:
            return
        
        # Check for critical indicators
        total_issues = len(issues)
        overdue_issues = len([i for i in issues if self._is_overdue(i)])
        blocked_issues = len([i for i in issues if 'block' in i.get('status', {}).get('name', '').lower()])
        
        # Critical thresholds
        if overdue_issues / total_issues > 0.3:  # More than 30% overdue
            self.integration_manager.send_risk_alert({
                'type': 'overdue_spike',
                'severity': 'high',
                'title': f'High Overdue Issue Count - {project_key}',
                'message': f'{overdue_issues} of {total_issues} issues are overdue ({overdue_issues/total_issues:.1%})',
                'project_key': project_key,
                'data': {
                    'overdue_ratio': overdue_issues / total_issues,
                    'total_issues': total_issues,
                    'overdue_count': overdue_issues
                }
            })
        
        if blocked_issues > 0:
            self.integration_manager.send_risk_alert({
                'type': 'blocked_issues',
                'severity': 'medium',
                'title': f'Blocked Issues Detected - {project_key}',
                'message': f'{blocked_issues} issues are currently blocked',
                'project_key': project_key,
                'data': {
                    'blocked_count': blocked_issues,
                    'blocked_ratio': blocked_issues / total_issues
                }
            })
    
    def _should_update_model(self) -> bool:
        """Check if ML model should be updated"""
        time_condition = datetime.now() - self.last_model_update > self.update_threshold
        data_condition = len([d for d in self.data_buffer if not d['processed']]) >= 20
        
        return time_condition or data_condition
    
    def _trigger_model_update(self):
        """Trigger ML model update with new data"""
        try:
            unprocessed_data = [d for d in self.data_buffer if not d['processed']]
            
            if len(unprocessed_data) < 5:
                return
            
            # Update model with new data
            success = self.risk_predictor.update_model_real_time({
                'batch_data': unprocessed_data,
                'update_type': 'incremental'
            })
            
            if success:
                # Mark data as processed
                for data_point in unprocessed_data:
                    data_point['processed'] = True
                
                self.last_model_update = datetime.now()
                
                # Send update notification
                self.integration_manager.send_ml_model_update({
                    'accuracy': 0.85,  # Would get actual metrics from model
                    'training_samples': len(unprocessed_data),
                    'update_timestamp': datetime.now().isoformat()
                })
                
                logging.info(f"ML model updated with {len(unprocessed_data)} new samples")
            
        except Exception as e:
            logging.error(f"Model update error: {str(e)}")
    
    def _start_real_time_processor(self):
        """Start background real-time data processing"""
        def processor():
            while True:
                try:
                    # Process any pending data
                    with self.processing_lock:
                        pending_data = [d for d in self.data_buffer if not d.get('analyzed', False)]
                        
                        for data_point in pending_data:
                            # Run real-time risk analysis
                            self._run_real_time_analysis(data_point)
                            data_point['analyzed'] = True
                    
                    # Clean up old data
                    cutoff_time = datetime.now() - timedelta(hours=24)
                    self.data_buffer = [d for d in self.data_buffer if d['timestamp'] > cutoff_time]
                    
                    time.sleep(30)  # Process every 30 seconds
                    
                except Exception as e:
                    logging.error(f"Real-time processor error: {str(e)}")
                    time.sleep(60)
        
        processor_thread = threading.Thread(target=processor, daemon=True)
        processor_thread.start()
        logging.info("Real-time data processor started")
    
    def _run_real_time_analysis(self, data_point: Dict[str, Any]):
        """Run real-time risk analysis on data point"""
        try:
            project_key = data_point['project_key']
            project_data = data_point['data']
            
            # Run Monte Carlo prediction
            prediction_results = self.risk_predictor.predict_with_monte_carlo(
                project_data.get('issues', [])
            )
            
            # Send prediction-based alerts
            self.integration_manager.send_prediction_alert(prediction_results, project_key)
            
        except Exception as e:
            logging.error(f"Real-time analysis error: {str(e)}")
    
    def _is_overdue(self, issue: Dict) -> bool:
        """Check if issue is overdue"""
        due_date = issue.get('duedate')
        if not due_date:
            return False
        
        try:
            due_date_obj = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            return due_date_obj < datetime.now() and issue.get('status', {}).get('category') != 'Done'
        except:
            return False