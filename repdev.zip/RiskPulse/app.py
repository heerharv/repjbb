import os
import requests
import logging
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
from requests.auth import HTTPBasicAuth
import json
from datetime import datetime, timedelta
from risk_engine import RiskEngine
from data_analyzer import DataAnalyzer
from database import init_db, RiskMetrics
from scheduler import start_scheduler
import numpy as np

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "your-secret-key-here")
CORS(app)  # Enables CORS for all routes

# Initialize database
init_db()

# Initialize Risk Engine
risk_engine = RiskEngine()
data_analyzer = DataAnalyzer()

# Start automated risk calculations scheduler
start_scheduler(risk_engine)

# JIRA Configuration
JIRA_DOMAIN = os.environ.get("JIRA_DOMAIN", "uncia-team-vmevzjmu.atlassian.net")
JIRA_EMAIL = os.environ.get("JIRA_EMAIL", "heerha@uncia.ai")
JIRA_API_TOKEN = os.environ.get("JIRA_API_TOKEN", "ATATT3xFfGF02OVl2RLVinvafOJwvPadlqht-3HJ_MgBlv5RsOyvFS4cK096yscLLJlu3FurBnJ7vdPFzcb6mcRn_PEOstXoTMFnvNu7B6yyY56sFQ7bCdJTkrWN8_4vmdFhLriUPNoHalA1RYQosGN-Hvsy2NyseSbK1zET-FR_bZ0xd7WFKa8=06DE82DA")

def get_jira_auth():
    return HTTPBasicAuth(JIRA_EMAIL, JIRA_API_TOKEN)

def get_jira_headers():
    return {
        "Accept": "application/json",
        "Content-Type": "application/json"
    }

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('risk-dashboard.html')

@app.route('/api/status')
def api_status():
    """API information and available endpoints"""
    return jsonify({
        "message": "🚀 UNCIA Jira Dashboard with Intelligent Risk Engine is Running!",
        "status": "success",
        "authentication": "working" if JIRA_API_TOKEN else "missing",
        "risk_engine": "active",
        "endpoints": {
            "test_connection": "/api/jira/test",
            "all_projects": "/api/jira-projects", 
            "project_details": "/api/jira/project/{project_key}",
            "project_issues": "/api/jira/issues/{project_key}",
            "project_dashboard": "/api/jira/dashboard/{project_key}",
            "project_board": "/api/jira/board/{project_key}",
            "users": "/api/jira/users",
            # Risk Management Endpoints
            "risk_dashboard": "/api/risk/dashboard/{project_key}",
            "risk_board": "/api/risk/board/{project_key}",
            "risk_create": "/api/risk/create-integrated",
            "risk_metrics": "/api/metrics/integrated/{project_key}",
            "risk_update": "/api/risk/update/{issue_key}",
            # New Risk Engine Endpoints
            "risk_analysis": "/api/risk-engine/analysis/{project_key}",
            "benefit_case": "/api/risk-engine/benefit-case/{project_key}",
            "say_do_ratio": "/api/risk-engine/say-do-ratio/{project_key}",
            "dependency_impact": "/api/risk-engine/dependency-impact/{project_key}",
            "spillover_analysis": "/api/risk-engine/spillover/{project_key}",
            "idle_time": "/api/risk-engine/idle-time/{project_key}",
            "cost_analysis": "/api/risk-engine/cost-analysis/{project_key}",
            "timeline_analysis": "/api/risk-engine/timeline-analysis/{project_key}",
            "resource_analysis": "/api/risk-engine/resource-analysis/{project_key}",
            "resource_utilization": "/api/risk-engine/resource-utilization/{project_key}",
            "risk_impact": "/api/risk-engine/risk-impact/{project_key}",
            "speed_to_market": "/api/risk-engine/speed-to-market/{project_key}",
            "success_criteria": "/api/risk-engine/success-criteria/{project_key}",
            "predictive_analytics": "/api/risk-engine/predictive/{project_key}"
        },
        "risk_features": {
            "intelligent_analysis": True,
            "predictive_analytics": True,
            "automated_calculations": True,
            "ml_powered": True,
            "real_time_monitoring": True
        }
    })

@app.route('/api/jira/test')
def test_jira_connection():
    """Test Jira API connection"""
    try:
        url = f"https://{JIRA_DOMAIN}/rest/api/3/myself"
        response = requests.get(url, headers=get_jira_headers(), auth=get_jira_auth(), timeout=10)
        
        if response.status_code == 200:
            user_data = response.json()
            return jsonify({
                "status": "success",
                "message": "🎉 Connected to Jira successfully!",
                "user": {
                    "displayName": user_data.get('displayName'),
                    "emailAddress": user_data.get('emailAddress'),
                    "accountType": user_data.get('accountType'),
                    "accountId": user_data.get('accountId')
                },
                "domain": JIRA_DOMAIN,
                "token_status": "working"
            })
        else:
            return jsonify({
                "status": "error",
                "message": f"Connection failed with status {response.status_code}",
                "details": response.text
            }), response.status_code
            
    except Exception as e:
        return jsonify({
            "status": "error", 
            "message": f"Connection test failed: {str(e)}"
        }), 500

@app.route('/api/jira-projects')
def get_all_projects():
    """Get all available Jira projects"""
    try:
        url = f"https://{JIRA_DOMAIN}/rest/api/3/project"
        response = requests.get(url, headers=get_jira_headers(), auth=get_jira_auth())
        
        if response.status_code == 200:
            projects = response.json()
            
            # Process projects data
            processed_projects = []
            for project in projects:
                processed_project = {
                    "key": project.get('key'),
                    "name": project.get('name'),
                    "projectTypeKey": project.get('projectTypeKey'),
                    "lead": project.get('lead', {}).get('displayName') if project.get('lead') else None,
                    "description": project.get('description', ''),
                    "url": project.get('self'),
                    "avatarUrls": project.get('avatarUrls', {}),
                    "style": project.get('style')
                }
                processed_projects.append(processed_project)
            
            return jsonify({
                "total": len(processed_projects),
                "projects": processed_projects
            })
        else:
            return jsonify({"error": f"Failed to fetch projects: {response.text}"}), response.status_code
            
    except Exception as e:
        return jsonify({"error": f"Exception occurred: {str(e)}"}), 500

@app.route('/api/jira/project/<project_key>')
def get_project_details(project_key):
    """Get detailed project information"""
    try:
        url = f"https://{JIRA_DOMAIN}/rest/api/3/project/{project_key}"
        response = requests.get(url, headers=get_jira_headers(), auth=get_jira_auth())
        
        if response.status_code == 200:
            project_data = response.json()
            
            # Get additional project statistics
            stats_url = f"https://{JIRA_DOMAIN}/rest/api/3/project/{project_key}/statuses"
            stats_response = requests.get(stats_url, headers=get_jira_headers(), auth=get_jira_auth())
            
            result = {
                "project_info": project_data,
                "statuses": stats_response.json() if stats_response.status_code == 200 else []
            }
            
            return jsonify(result)
        else:
            return jsonify({"error": f"Failed to fetch project details: {response.text}"}), response.status_code
            
    except Exception as e:
        return jsonify({"error": f"Exception occurred: {str(e)}"}), 500

@app.route('/api/jira/issues/<project_key>')
def get_project_issues(project_key):
    """Get all issues for a specific project with detailed information"""
    try:
        url = f"https://{JIRA_DOMAIN}/rest/api/3/search"
        
        # JQL query to get all issues from the specific project
        jql_query = f"project = {project_key} ORDER BY created DESC"
        
        params = {
            "jql": jql_query,
            "maxResults": 1000,
            "fields": [
                "summary", "description", "status", "assignee", "reporter",
                "priority", "issuetype", "created", "updated", "labels",
                "components", "fixVersions", "resolution", "resolutiondate",
                "worklog", "comment", "progress", "timeestimate", "timespent",
                "duedate", "customfield_10016", "customfield_10020"  # Story points and Sprint
            ]
        }
        
        response = requests.get(url, headers=get_jira_headers(), auth=get_jira_auth(), params=params)
        
        if response.status_code == 200:
            issues_data = response.json()
            
            # Process and structure the data
            processed_issues = []
            for issue in issues_data.get('issues', []):
                fields = issue.get('fields', {})
                
                processed_issue = {
                    "key": issue.get('key'),
                    "id": issue.get('id'),
                    "summary": fields.get('summary'),
                    "description": fields.get('description'),
                    "status": {
                        "name": fields.get('status', {}).get('name'),
                        "category": fields.get('status', {}).get('statusCategory', {}).get('name')
                    },
                    "assignee": {
                        "name": fields.get('assignee', {}).get('displayName') if fields.get('assignee') else "Unassigned",
                        "email": fields.get('assignee', {}).get('emailAddress') if fields.get('assignee') else None
                    },
                    "reporter": {
                        "name": fields.get('reporter', {}).get('displayName') if fields.get('reporter') else None,
                        "email": fields.get('reporter', {}).get('emailAddress') if fields.get('reporter') else None
                    },
                    "priority": {
                        "name": fields.get('priority', {}).get('name') if fields.get('priority') else None,
                        "iconUrl": fields.get('priority', {}).get('iconUrl') if fields.get('priority') else None
                    },
                    "issuetype": {
                        "name": fields.get('issuetype', {}).get('name'),
                        "iconUrl": fields.get('issuetype', {}).get('iconUrl')
                    },
                    "created": fields.get('created'),
                    "updated": fields.get('updated'),
                    "labels": fields.get('labels', []),
                    "components": [comp.get('name') for comp in fields.get('components', [])],
                    "fixVersions": [version.get('name') for version in fields.get('fixVersions', [])],
                    "resolution": fields.get('resolution', {}).get('name') if fields.get('resolution') else None,
                    "resolutiondate": fields.get('resolutiondate'),
                    "progress": fields.get('progress', {}),
                    "timeestimate": fields.get('timeestimate'),
                    "timespent": fields.get('timespent'),
                    "duedate": fields.get('duedate'),
                    "storypoints": fields.get('customfield_10016'),
                    "sprint": fields.get('customfield_10020')
                }
                processed_issues.append(processed_issue)
            
            return jsonify({
                "total": issues_data.get('total'),
                "issues": processed_issues
            })
        else:
            return jsonify({"error": f"Failed to fetch issues: {response.text}"}), response.status_code
            
    except Exception as e:
        return jsonify({"error": f"Exception occurred: {str(e)}"}), 500

# Risk Engine Endpoints

@app.route('/api/risk-engine/analysis/<project_key>')
def get_risk_analysis(project_key):
    """Get comprehensive risk analysis for a project"""
    try:
        # Fetch project data
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        # Run risk analysis
        analysis = risk_engine.analyze_project_risks(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "analysis": analysis,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        logging.error(f"Risk analysis error: {str(e)}")
        return jsonify({"error": f"Risk analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/benefit-case/<project_key>')
def get_benefit_case_analysis(project_key):
    """Get benefit case analysis (tangible/intangible)"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        benefit_case = risk_engine.calculate_benefit_case(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "benefit_case": benefit_case
        })
        
    except Exception as e:
        return jsonify({"error": f"Benefit case analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/say-do-ratio/<project_key>')
def get_say_do_ratio(project_key):
    """Calculate Say-Do ratio"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        ratio = risk_engine.calculate_say_do_ratio(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "say_do_ratio": ratio
        })
        
    except Exception as e:
        return jsonify({"error": f"Say-Do ratio calculation failed: {str(e)}"}), 500

@app.route('/api/risk-engine/dependency-impact/<project_key>')
def get_dependency_impact(project_key):
    """Analyze dependency impact"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        impact = risk_engine.analyze_dependency_impact(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "dependency_impact": impact
        })
        
    except Exception as e:
        return jsonify({"error": f"Dependency impact analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/spillover/<project_key>')
def get_spillover_analysis(project_key):
    """Analyze spillover effects"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        spillover = risk_engine.analyze_spillover_effects(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "spillover_analysis": spillover
        })
        
    except Exception as e:
        return jsonify({"error": f"Spillover analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/idle-time/<project_key>')
def get_idle_time_analysis(project_key):
    """Track idle time"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        idle_time = risk_engine.track_idle_time(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "idle_time_analysis": idle_time
        })
        
    except Exception as e:
        return jsonify({"error": f"Idle time analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/cost-analysis/<project_key>')
def get_cost_analysis(project_key):
    """Compare estimated vs actual costs"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        cost_analysis = risk_engine.analyze_cost_variance(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "cost_analysis": cost_analysis
        })
        
    except Exception as e:
        return jsonify({"error": f"Cost analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/timeline-analysis/<project_key>')
def get_timeline_analysis(project_key):
    """Compare estimated vs actual timeline"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        timeline_analysis = risk_engine.analyze_timeline_variance(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "timeline_analysis": timeline_analysis
        })
        
    except Exception as e:
        return jsonify({"error": f"Timeline analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/resource-analysis/<project_key>')
def get_resource_analysis(project_key):
    """Compare estimated vs actual resources"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        resource_analysis = risk_engine.analyze_resource_variance(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "resource_analysis": resource_analysis
        })
        
    except Exception as e:
        return jsonify({"error": f"Resource analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/resource-utilization/<project_key>')
def get_resource_utilization(project_key):
    """Analyze resource utilization"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        utilization = risk_engine.analyze_resource_utilization(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "resource_utilization": utilization
        })
        
    except Exception as e:
        return jsonify({"error": f"Resource utilization analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/risk-impact/<project_key>')
def get_risk_impact_assessment(project_key):
    """Assess risk impact"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        risk_impact = risk_engine.assess_risk_impact(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "risk_impact_assessment": risk_impact
        })
        
    except Exception as e:
        return jsonify({"error": f"Risk impact assessment failed: {str(e)}"}), 500

@app.route('/api/risk-engine/speed-to-market/<project_key>')
def get_speed_to_market(project_key):
    """Analyze speed to market with bug tracking"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        speed_analysis = risk_engine.analyze_speed_to_market(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "speed_to_market": speed_analysis
        })
        
    except Exception as e:
        return jsonify({"error": f"Speed to market analysis failed: {str(e)}"}), 500

@app.route('/api/risk-engine/success-criteria/<project_key>')
def get_success_criteria(project_key):
    """Evaluate success criteria"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        success_criteria = risk_engine.evaluate_success_criteria(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "success_criteria": success_criteria
        })
        
    except Exception as e:
        return jsonify({"error": f"Success criteria evaluation failed: {str(e)}"}), 500

@app.route('/api/risk-engine/predictive/<project_key>')
def get_predictive_analytics(project_key):
    """Get predictive analytics"""
    try:
        project_data = get_project_data(project_key)
        if not project_data:
            return jsonify({"error": "Failed to fetch project data"}), 400
        
        predictions = risk_engine.generate_predictive_analytics(project_data)
        
        return jsonify({
            "status": "success",
            "project_key": project_key,
            "predictive_analytics": predictions
        })
        
    except Exception as e:
        return jsonify({"error": f"Predictive analytics failed: {str(e)}"}), 500

def get_project_data(project_key):
    """Helper function to fetch comprehensive project data"""
    try:
        # Get project issues
        issues_response = get_project_issues(project_key)
        if hasattr(issues_response, 'get_json'):
            issues_data = issues_response.get_json()
        else:
            issues_data = issues_response[0].get_json() if isinstance(issues_response, tuple) else issues_response
        
        # Get project details
        project_response = get_project_details(project_key)
        if hasattr(project_response, 'get_json'):
            project_details = project_response.get_json()
        else:
            project_details = project_response[0].get_json() if isinstance(project_response, tuple) else project_response
        
        return {
            "project_key": project_key,
            "issues": issues_data.get('issues', []) if 'issues' in issues_data else [],
            "project_info": project_details.get('project_info', {}) if 'project_info' in project_details else {},
            "total_issues": issues_data.get('total', 0) if 'total' in issues_data else 0
        }
        
    except Exception as e:
        logging.error(f"Error fetching project data: {str(e)}")
        return None

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
