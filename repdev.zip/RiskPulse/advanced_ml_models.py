import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingClassifier, IsolationForest
from sklearn.linear_model import LinearRegression, SGDRegressor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error, accuracy_score, r2_score
from sklearn.cluster import KMeans
from datetime import datetime, timedelta
import joblib
import logging
from typing import Dict, List, Any, Optional, Tuple
import threading
import time
import warnings
import os
import json
from scipy import stats
from scipy.stats import norm, beta
import random
warnings.filterwarnings('ignore')

class RealTimeRiskPredictor:
    """Advanced Machine Learning models with real-time retraining and Monte Carlo simulations"""
    
    def __init__(self):
        self.completion_model = None
        self.cost_model = None
        self.quality_model = None
        self.timeline_model = None
        self.anomaly_detector = None
        self.clustering_model = None
        self.online_model = None
        
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.is_trained = False
        self.model_performance = {}
        self.training_history = []
        self.real_time_buffer = []
        self.retrain_threshold = 0.1
        self.min_samples_retrain = 50
        
        # Real-time learning configuration
        self._training_lock = threading.Lock()
        self._last_retrain = datetime.now()
        self._retrain_interval = timedelta(hours=6)
        
        # Monte Carlo simulation parameters
        self.monte_carlo_simulations = 1000
        self.confidence_intervals = [0.05, 0.95]
        self.feature_importance_threshold = 0.01
        
        # Performance tracking
        self.model_metrics = {
            'accuracy_history': [],
            'mse_history': [],
            'r2_history': [],
            'last_updated': None,
            'model_drift_score': 0.0
        }
        
        # AI-powered recommendations engine
        self.recommendation_engine = AIRecommendationEngine()
        
        self._initialize_models()
        logging.info("Advanced real-time ML models initialized")
    
    def _initialize_models(self):
        """Initialize ML models with optimized parameters"""
        self.completion_model = RandomForestRegressor(
            n_estimators=150,
            max_depth=12,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
        
        self.cost_model = GradientBoostingClassifier(
            n_estimators=120,
            learning_rate=0.1,
            max_depth=7,
            subsample=0.8,
            random_state=42
        )
        
        self.quality_model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1
        )
        
        self.timeline_model = LinearRegression()
        
        # Online learning model for real-time updates
        self.online_model = SGDRegressor(
            learning_rate='adaptive',
            eta0=0.01,
            alpha=0.0001,
            random_state=42
        )
        
        # Anomaly detection
        self.anomaly_detector = IsolationForest(
            contamination=0.1,
            random_state=42
        )
        
        # Pattern recognition clustering
        self.clustering_model = KMeans(
            n_clusters=5,
            random_state=42
        )
    
    def predict_with_monte_carlo(self, issues: List[Dict]) -> Dict[str, Any]:
        """Advanced prediction using Monte Carlo simulations"""
        try:
            features = self._extract_features(issues)
            
            if not self.is_trained:
                return self._heuristic_monte_carlo_predictions(features, issues)
            
            # Run Monte Carlo simulations
            completion_probs = []
            budget_overruns = []
            timeline_predictions = []
            
            for _ in range(self.monte_carlo_simulations):
                # Add noise to features for simulation
                noisy_features = self._add_simulation_noise(features)
                
                # Predict with noisy data
                completion_prob = self._predict_completion_probability(noisy_features)
                budget_overrun = self._predict_budget_overrun(noisy_features)
                timeline_pred = self._predict_timeline_variance(noisy_features, issues)
                
                completion_probs.append(completion_prob)
                budget_overruns.append(budget_overrun)
                timeline_predictions.append(timeline_pred)
            
            # Calculate statistics
            results = {
                'completion_probability': {
                    'mean': float(np.mean(completion_probs)),
                    'median': float(np.median(completion_probs)),
                    'std': float(np.std(completion_probs)),
                    'confidence_interval': [
                        float(np.percentile(completion_probs, self.confidence_intervals[0] * 100)),
                        float(np.percentile(completion_probs, self.confidence_intervals[1] * 100))
                    ],
                    'probability_of_success': float(np.mean([p > 0.8 for p in completion_probs]))
                },
                'budget_overrun_risk': {
                    'mean': float(np.mean(budget_overruns)),
                    'median': float(np.median(budget_overruns)),
                    'std': float(np.std(budget_overruns)),
                    'confidence_interval': [
                        float(np.percentile(budget_overruns, self.confidence_intervals[0] * 100)),
                        float(np.percentile(budget_overruns, self.confidence_intervals[1] * 100))
                    ],
                    'high_risk_probability': float(np.mean([p > 0.3 for p in budget_overruns]))
                },
                'timeline_variance': {
                    'mean_days': float(np.mean(timeline_predictions)),
                    'median_days': float(np.median(timeline_predictions)),
                    'std_days': float(np.std(timeline_predictions)),
                    'confidence_interval': [
                        float(np.percentile(timeline_predictions, self.confidence_intervals[0] * 100)),
                        float(np.percentile(timeline_predictions, self.confidence_intervals[1] * 100))
                    ]
                },
                'risk_scenarios': self._generate_risk_scenarios(completion_probs, budget_overruns, timeline_predictions),
                'simulation_metadata': {
                    'simulations_run': self.monte_carlo_simulations,
                    'confidence_level': (self.confidence_intervals[1] - self.confidence_intervals[0]) * 100,
                    'timestamp': datetime.now().isoformat()
                }
            }
            
            # Generate AI-powered recommendations
            results['ai_recommendations'] = self.recommendation_engine.generate_recommendations(results, issues)
            
            return results
            
        except Exception as e:
            logging.error(f"Monte Carlo prediction error: {str(e)}")
            return self._fallback_predictions()
    
    def _add_simulation_noise(self, features: np.ndarray) -> np.ndarray:
        """Add controlled noise to features for Monte Carlo simulation"""
        noise_level = 0.05  # 5% noise
        noise = np.random.normal(0, noise_level, features.shape)
        return features + noise
    
    def _generate_risk_scenarios(self, completion_probs: List[float], 
                                budget_overruns: List[float], 
                                timeline_predictions: List[float]) -> Dict[str, Any]:
        """Generate different risk scenarios from Monte Carlo results"""
        scenarios = {
            'best_case': {
                'completion_probability': float(np.percentile(completion_probs, 90)),
                'budget_overrun': float(np.percentile(budget_overruns, 10)),
                'timeline_variance': float(np.percentile(timeline_predictions, 10)),
                'description': 'Optimistic scenario with favorable conditions'
            },
            'worst_case': {
                'completion_probability': float(np.percentile(completion_probs, 10)),
                'budget_overrun': float(np.percentile(budget_overruns, 90)),
                'timeline_variance': float(np.percentile(timeline_predictions, 90)),
                'description': 'Pessimistic scenario with multiple challenges'
            },
            'most_likely': {
                'completion_probability': float(np.median(completion_probs)),
                'budget_overrun': float(np.median(budget_overruns)),
                'timeline_variance': float(np.median(timeline_predictions)),
                'description': 'Most probable outcome based on current trends'
            }
        }
        
        return scenarios
    
    def update_model_real_time(self, new_data: Dict[str, Any]) -> bool:
        """Real-time model updates with new project data"""
        try:
            with self._training_lock:
                # Add to real-time buffer
                self.real_time_buffer.append({
                    'data': new_data,
                    'timestamp': datetime.now(),
                    'processed': False
                })
                
                # Check if retraining is needed
                if self._should_retrain():
                    success = self._incremental_retrain()
                    if success:
                        self._update_performance_metrics()
                        logging.info("Real-time model update completed")
                    return success
                
                return True
                
        except Exception as e:
            logging.error(f"Real-time update error: {str(e)}")
            return False
    
    def _should_retrain(self) -> bool:
        """Determine if model retraining is needed"""
        # Check time-based condition
        time_condition = datetime.now() - self._last_retrain > self._retrain_interval
        
        # Check data volume condition
        unprocessed_data = [d for d in self.real_time_buffer if not d['processed']]
        volume_condition = len(unprocessed_data) >= self.min_samples_retrain
        
        # Check performance degradation
        performance_condition = self.model_metrics.get('model_drift_score', 0) > self.retrain_threshold
        
        return time_condition and (volume_condition or performance_condition)
    
    def _incremental_retrain(self) -> bool:
        """Perform incremental retraining with new data"""
        try:
            unprocessed_data = [d for d in self.real_time_buffer if not d['processed']]
            
            if len(unprocessed_data) < 5:
                return False
            
            # Prepare incremental training data
            X_new, y_new = self._prepare_incremental_data(unprocessed_data)
            
            if X_new.shape[0] == 0:
                return False
            
            # Update online model
            if self.online_model is not None:
                X_scaled = self.scaler.transform(X_new)
                self.online_model.partial_fit(X_scaled, y_new)
            
            # Mark data as processed
            for data_point in unprocessed_data:
                data_point['processed'] = True
            
            self._last_retrain = datetime.now()
            logging.info(f"Incremental retraining completed with {len(unprocessed_data)} samples")
            
            return True
            
        except Exception as e:
            logging.error(f"Incremental retraining error: {str(e)}")
            return False
    
    def _prepare_incremental_data(self, data_points: List[Dict]) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare data for incremental learning"""
        X = []
        y = []
        
        for point in data_points:
            try:
                issues = point['data'].get('issues', [])
                if not issues:
                    continue
                
                features = self._extract_features(issues)
                
                # Calculate actual outcome for supervision
                actual_completion = self._calculate_actual_completion(issues)
                
                X.append(features.flatten())
                y.append(actual_completion)
                
            except Exception as e:
                logging.warning(f"Error processing data point: {str(e)}")
                continue
        
        return np.array(X), np.array(y)
    
    def _calculate_actual_completion(self, issues: List[Dict]) -> float:
        """Calculate actual completion rate for supervision"""
        if not issues:
            return 0.0
        
        completed = len([i for i in issues if i.get('status', {}).get('category') == 'Done'])
        return completed / len(issues)
    
    def _update_performance_metrics(self):
        """Update model performance tracking"""
        try:
            # Calculate current performance metrics
            if len(self.real_time_buffer) > 10:
                recent_data = self.real_time_buffer[-10:]
                X_test, y_test = self._prepare_incremental_data(recent_data)
                
                if X_test.shape[0] > 0 and self.online_model is not None:
                    X_scaled = self.scaler.transform(X_test)
                    y_pred = self.online_model.predict(X_scaled)
                    
                    mse = mean_squared_error(y_test, y_pred)
                    r2 = r2_score(y_test, y_pred)
                    
                    self.model_metrics['mse_history'].append(mse)
                    self.model_metrics['r2_history'].append(r2)
                    self.model_metrics['last_updated'] = datetime.now().isoformat()
                    
                    # Calculate model drift
                    if len(self.model_metrics['mse_history']) > 1:
                        recent_mse = np.mean(self.model_metrics['mse_history'][-5:])
                        baseline_mse = np.mean(self.model_metrics['mse_history'][:5]) if len(self.model_metrics['mse_history']) > 5 else recent_mse
                        
                        if baseline_mse > 0:
                            drift_score = (recent_mse - baseline_mse) / baseline_mse
                            self.model_metrics['model_drift_score'] = max(0, drift_score)
                        
        except Exception as e:
            logging.error(f"Performance metrics update error: {str(e)}")
    
    def _extract_features(self, issues: List[Dict]) -> np.ndarray:
        """Extract comprehensive features for ML models"""
        if not issues:
            return np.zeros((1, 15))
        
        total_issues = len(issues)
        completed_issues = len([i for i in issues if i.get('status', {}).get('category') == 'Done'])
        in_progress_issues = len([i for i in issues if 'progress' in i.get('status', {}).get('name', '').lower()])
        
        # Story points analysis
        total_story_points = sum(i.get('storypoints', 0) or 0 for i in issues)
        completed_story_points = sum(
            i.get('storypoints', 0) or 0 for i in issues 
            if i.get('status', {}).get('category') == 'Done'
        )
        
        # Time-based features
        avg_cycle_time = self._calculate_average_cycle_time(issues)
        overdue_ratio = len([i for i in issues if self._is_overdue(i)]) / total_issues if total_issues > 0 else 0
        
        # Priority and type distribution
        high_priority_ratio = len([i for i in issues if self._is_high_priority(i)]) / total_issues if total_issues > 0 else 0
        bug_ratio = len([i for i in issues if i.get('issuetype', {}).get('name', '').lower() == 'bug']) / total_issues if total_issues > 0 else 0
        
        # Team and workload metrics
        workload_variance = self._calculate_workload_variance(issues)
        assignee_diversity = len(set(i.get('assignee', {}).get('name', 'Unassigned') for i in issues))
        
        # Complexity indicators
        avg_description_length = np.mean([len(i.get('description', '') or '') for i in issues])
        component_diversity = len(set(comp for i in issues for comp in i.get('components', [])))
        
        # Temporal patterns
        creation_velocity = self._calculate_creation_velocity(issues)
        resolution_velocity = self._calculate_resolution_velocity(issues)
        
        # Risk indicators
        blocked_issues = len([i for i in issues if 'block' in i.get('status', {}).get('name', '').lower()])
        scope_changes = len([i for i in issues if any('scope' in label.lower() for label in i.get('labels', []))])
        
        features = [
            total_issues,
            completed_issues / total_issues if total_issues > 0 else 0,
            in_progress_issues / total_issues if total_issues > 0 else 0,
            total_story_points,
            completed_story_points / total_story_points if total_story_points > 0 else 0,
            avg_cycle_time,
            overdue_ratio,
            high_priority_ratio,
            bug_ratio,
            workload_variance,
            assignee_diversity,
            avg_description_length / 1000,  # Normalized
            component_diversity,
            creation_velocity,
            resolution_velocity,
            blocked_issues / total_issues if total_issues > 0 else 0,
            scope_changes / total_issues if total_issues > 0 else 0
        ]
        
        return np.array(features).reshape(1, -1)
    
    def _calculate_average_cycle_time(self, issues: List[Dict]) -> float:
        """Calculate average cycle time for completed issues"""
        cycle_times = []
        
        for issue in issues:
            if issue.get('status', {}).get('category') == 'Done':
                created = issue.get('created')
                resolved = issue.get('resolutiondate')
                
                if created and resolved:
                    try:
                        created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                        resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                        cycle_time = (resolved_date - created_date).days
                        if cycle_time > 0:
                            cycle_times.append(cycle_time)
                    except:
                        continue
        
        return float(np.mean(cycle_times)) if cycle_times else 7.0
    
    def _calculate_creation_velocity(self, issues: List[Dict]) -> float:
        """Calculate issue creation velocity"""
        if not issues:
            return 0.0
        
        creation_dates = []
        for issue in issues:
            created = issue.get('created')
            if created:
                try:
                    created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                    creation_dates.append(created_date)
                except:
                    continue
        
        if len(creation_dates) < 2:
            return 0.0
        
        creation_dates.sort()
        days_span = (creation_dates[-1] - creation_dates[0]).days
        return len(creation_dates) / max(days_span, 1)
    
    def _calculate_resolution_velocity(self, issues: List[Dict]) -> float:
        """Calculate issue resolution velocity"""
        resolved_dates = []
        for issue in issues:
            if issue.get('status', {}).get('category') == 'Done':
                resolved = issue.get('resolutiondate')
                if resolved:
                    try:
                        resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                        resolved_dates.append(resolved_date)
                    except:
                        continue
        
        if len(resolved_dates) < 2:
            return 0.0
        
        resolved_dates.sort()
        days_span = (resolved_dates[-1] - resolved_dates[0]).days
        return len(resolved_dates) / max(days_span, 1)
    
    def _is_overdue(self, issue: Dict) -> bool:
        """Check if issue is overdue"""
        due_date = issue.get('duedate')
        if not due_date:
            return False
        
        try:
            due_date_obj = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            return due_date_obj < datetime.now() and issue.get('status', {}).get('category') != 'Done'
        except:
            return False
    
    def _is_high_priority(self, issue: Dict) -> bool:
        """Check if issue has high priority"""
        priority = issue.get('priority', {}).get('name', '').lower()
        return priority in ['high', 'highest', 'critical', 'blocker']
    
    def _calculate_workload_variance(self, issues: List[Dict]) -> float:
        """Calculate workload variance across team members"""
        assignee_counts = {}
        
        for issue in issues:
            assignee = issue.get('assignee', {}).get('name', 'Unassigned')
            if assignee != 'Unassigned':
                assignee_counts[assignee] = assignee_counts.get(assignee, 0) + 1
        
        if len(assignee_counts) < 2:
            return 0.0
        
        workloads = list(assignee_counts.values())
        return float(np.var(workloads) / np.mean(workloads)) if np.mean(workloads) > 0 else 0.0
    
    def _predict_completion_probability(self, features: np.ndarray) -> float:
        """Predict project completion probability"""
        try:
            if self.completion_model and self.is_trained:
                scaled_features = self.scaler.transform(features)
                prediction = self.completion_model.predict(scaled_features)[0]
                return float(max(0.0, min(1.0, prediction)))
            else:
                return self._heuristic_completion_probability(features)
        except Exception as e:
            logging.error(f"Completion prediction error: {str(e)}")
            return 0.7
    
    def _predict_budget_overrun(self, features: np.ndarray) -> float:
        """Predict budget overrun probability"""
        try:
            feature_vec = features[0]
            overdue_ratio = feature_vec[6] if len(feature_vec) > 6 else 0
            workload_variance = feature_vec[9] if len(feature_vec) > 9 else 0
            bug_ratio = feature_vec[8] if len(feature_vec) > 8 else 0
            
            overrun_prob = (overdue_ratio * 0.4 + workload_variance * 0.3 + bug_ratio * 0.3)
            return float(max(0.0, min(1.0, overrun_prob)))
            
        except Exception as e:
            logging.error(f"Budget overrun prediction error: {str(e)}")
            return 0.3
    
    def _predict_timeline_variance(self, features: np.ndarray, issues: List[Dict]) -> float:
        """Predict timeline variance in days"""
        try:
            feature_vec = features[0]
            completion_ratio = feature_vec[1] if len(feature_vec) > 1 else 0
            avg_cycle_time = feature_vec[5] if len(feature_vec) > 5 else 7
            
            remaining_work = 1 - completion_ratio
            estimated_days = remaining_work * len(issues) * avg_cycle_time / max(1, len(issues) * 0.1)
            
            # Add uncertainty based on project complexity
            complexity_factor = 1 + feature_vec[9] if len(feature_vec) > 9 else 1
            variance_days = estimated_days * complexity_factor * 0.2
            
            return float(max(0, variance_days))
            
        except Exception as e:
            logging.error(f"Timeline variance prediction error: {str(e)}")
            return 10.0
    
    def _heuristic_completion_probability(self, features: np.ndarray) -> float:
        """Heuristic completion probability calculation"""
        feature_vec = features[0]
        completion_ratio = feature_vec[1] if len(feature_vec) > 1 else 0
        story_point_ratio = feature_vec[4] if len(feature_vec) > 4 else 0
        overdue_ratio = feature_vec[6] if len(feature_vec) > 6 else 0
        
        base_prob = (completion_ratio + story_point_ratio) / 2
        risk_factor = 1 - (overdue_ratio * 0.3)
        
        return float(max(0.1, min(0.95, base_prob * risk_factor)))
    
    def _heuristic_monte_carlo_predictions(self, features: np.ndarray, issues: List[Dict]) -> Dict[str, Any]:
        """Generate Monte Carlo predictions using heuristic models"""
        completion_probs = []
        budget_overruns = []
        timeline_predictions = []
        
        for _ in range(self.monte_carlo_simulations):
            noisy_features = self._add_simulation_noise(features)
            
            completion_prob = self._heuristic_completion_probability(noisy_features)
            budget_overrun = self._predict_budget_overrun(noisy_features)
            timeline_pred = self._predict_timeline_variance(noisy_features, issues)
            
            completion_probs.append(completion_prob)
            budget_overruns.append(budget_overrun)
            timeline_predictions.append(timeline_pred)
        
        return {
            'completion_probability': {
                'mean': float(np.mean(completion_probs)),
                'median': float(np.median(completion_probs)),
                'std': float(np.std(completion_probs)),
                'confidence_interval': [
                    float(np.percentile(completion_probs, 5)),
                    float(np.percentile(completion_probs, 95))
                ]
            },
            'budget_overrun_risk': {
                'mean': float(np.mean(budget_overruns)),
                'median': float(np.median(budget_overruns)),
                'std': float(np.std(budget_overruns)),
                'confidence_interval': [
                    float(np.percentile(budget_overruns, 5)),
                    float(np.percentile(budget_overruns, 95))
                ]
            },
            'timeline_variance': {
                'mean_days': float(np.mean(timeline_predictions)),
                'median_days': float(np.median(timeline_predictions)),
                'std_days': float(np.std(timeline_predictions))
            },
            'risk_scenarios': self._generate_risk_scenarios(completion_probs, budget_overruns, timeline_predictions),
            'ai_recommendations': self.recommendation_engine.generate_recommendations({}, issues)
        }
    
    def _fallback_predictions(self) -> Dict[str, Any]:
        """Fallback predictions when models fail"""
        return {
            'completion_probability': {'mean': 0.7, 'confidence_interval': [0.6, 0.8]},
            'budget_overrun_risk': {'mean': 0.3, 'confidence_interval': [0.2, 0.4]},
            'timeline_variance': {'mean_days': 15.0},
            'risk_scenarios': {},
            'ai_recommendations': []
        }


class AIRecommendationEngine:
    """AI-powered recommendation system for risk mitigation"""
    
    def __init__(self):
        self.recommendation_rules = self._load_recommendation_rules()
        self.priority_weights = {
            'critical': 1.0,
            'high': 0.8,
            'medium': 0.6,
            'low': 0.4
        }
    
    def generate_recommendations(self, predictions: Dict[str, Any], issues: List[Dict]) -> List[Dict[str, Any]]:
        """Generate AI-powered risk mitigation recommendations"""
        recommendations = []
        
        try:
            # Analyze completion probability risks
            if predictions.get('completion_probability', {}).get('mean', 0.7) < 0.6:
                recommendations.extend(self._completion_risk_recommendations(predictions, issues))
            
            # Analyze budget overrun risks
            if predictions.get('budget_overrun_risk', {}).get('mean', 0.3) > 0.4:
                recommendations.extend(self._budget_risk_recommendations(predictions, issues))
            
            # Analyze timeline risks
            if predictions.get('timeline_variance', {}).get('mean_days', 10) > 20:
                recommendations.extend(self._timeline_risk_recommendations(predictions, issues))
            
            # Issue-specific recommendations
            recommendations.extend(self._analyze_issue_patterns(issues))
            
            # Team performance recommendations
            recommendations.extend(self._team_performance_recommendations(issues))
            
            # Prioritize and limit recommendations
            recommendations = self._prioritize_recommendations(recommendations)
            
            return recommendations[:10]  # Top 10 recommendations
            
        except Exception as e:
            logging.error(f"Recommendation generation error: {str(e)}")
            return self._default_recommendations()
    
    def _completion_risk_recommendations(self, predictions: Dict[str, Any], issues: List[Dict]) -> List[Dict[str, Any]]:
        """Generate recommendations for completion risks"""
        recommendations = []
        
        completion_mean = predictions.get('completion_probability', {}).get('mean', 0.7)
        
        if completion_mean < 0.4:
            recommendations.append({
                'type': 'completion_risk',
                'priority': 'critical',
                'title': 'Critical Completion Risk Detected',
                'description': 'Project has very low completion probability. Immediate intervention required.',
                'actions': [
                    'Conduct emergency project review meeting',
                    'Reassess project scope and timeline',
                    'Consider additional resources or scope reduction',
                    'Implement daily standups for closer monitoring'
                ],
                'impact': 'high',
                'effort': 'high',
                'timeline': '1-3 days'
            })
        elif completion_mean < 0.6:
            recommendations.append({
                'type': 'completion_risk',
                'priority': 'high',
                'title': 'Low Completion Probability',
                'description': 'Project completion is at risk. Proactive measures needed.',
                'actions': [
                    'Review and prioritize critical path items',
                    'Identify and remove blockers',
                    'Consider parallel work streams',
                    'Increase team communication frequency'
                ],
                'impact': 'medium',
                'effort': 'medium',
                'timeline': '1 week'
            })
        
        return recommendations
    
    def _budget_risk_recommendations(self, predictions: Dict[str, Any], issues: List[Dict]) -> List[Dict[str, Any]]:
        """Generate recommendations for budget risks"""
        recommendations = []
        
        budget_risk = predictions.get('budget_overrun_risk', {}).get('mean', 0.3)
        
        if budget_risk > 0.6:
            recommendations.append({
                'type': 'budget_risk',
                'priority': 'critical',
                'title': 'High Budget Overrun Risk',
                'description': 'Project is likely to exceed budget. Cost control measures needed.',
                'actions': [
                    'Implement strict budget tracking',
                    'Review all upcoming expenses',
                    'Consider feature prioritization',
                    'Negotiate with vendors for better rates'
                ],
                'impact': 'high',
                'effort': 'medium',
                'timeline': '2-5 days'
            })
        elif budget_risk > 0.4:
            recommendations.append({
                'type': 'budget_risk',
                'priority': 'medium',
                'title': 'Budget Monitoring Required',
                'description': 'Moderate budget overrun risk detected.',
                'actions': [
                    'Set up weekly budget reviews',
                    'Monitor resource utilization',
                    'Look for cost optimization opportunities'
                ],
                'impact': 'medium',
                'effort': 'low',
                'timeline': '1 week'
            })
        
        return recommendations
    
    def _timeline_risk_recommendations(self, predictions: Dict[str, Any], issues: List[Dict]) -> List[Dict[str, Any]]:
        """Generate recommendations for timeline risks"""
        recommendations = []
        
        timeline_variance = predictions.get('timeline_variance', {}).get('mean_days', 10)
        
        if timeline_variance > 30:
            recommendations.append({
                'type': 'timeline_risk',
                'priority': 'high',
                'title': 'Significant Timeline Delays Expected',
                'description': f'Project may be delayed by ~{int(timeline_variance)} days.',
                'actions': [
                    'Fast-track critical deliverables',
                    'Increase team capacity temporarily',
                    'Implement aggressive scope management',
                    'Consider overtime or weekend work'
                ],
                'impact': 'high',
                'effort': 'high',
                'timeline': '1-2 weeks'
            })
        elif timeline_variance > 20:
            recommendations.append({
                'type': 'timeline_risk',
                'priority': 'medium',
                'title': 'Timeline Optimization Needed',
                'description': f'Potential delay of ~{int(timeline_variance)} days identified.',
                'actions': [
                    'Optimize task dependencies',
                    'Improve team coordination',
                    'Remove non-critical activities'
                ],
                'impact': 'medium',
                'effort': 'medium',
                'timeline': '1 week'
            })
        
        return recommendations
    
    def _analyze_issue_patterns(self, issues: List[Dict]) -> List[Dict[str, Any]]:
        """Analyze issue patterns for recommendations"""
        recommendations = []
        
        if not issues:
            return recommendations
        
        # High bug ratio analysis
        bug_count = len([i for i in issues if i.get('issuetype', {}).get('name', '').lower() == 'bug'])
        bug_ratio = bug_count / len(issues)
        
        if bug_ratio > 0.3:
            recommendations.append({
                'type': 'quality_risk',
                'priority': 'high',
                'title': 'High Bug Density Detected',
                'description': f'{bug_ratio:.1%} of issues are bugs, indicating quality problems.',
                'actions': [
                    'Implement additional code review processes',
                    'Increase automated testing coverage',
                    'Conduct root cause analysis for frequent bugs',
                    'Consider pair programming for complex features'
                ],
                'impact': 'high',
                'effort': 'medium',
                'timeline': '2-3 weeks'
            })
        
        # Overdue issues analysis
        overdue_count = len([i for i in issues if self._is_overdue(i)])
        if overdue_count > 0:
            overdue_ratio = overdue_count / len(issues)
            if overdue_ratio > 0.2:
                recommendations.append({
                    'type': 'schedule_risk',
                    'priority': 'high',
                    'title': 'Multiple Overdue Issues',
                    'description': f'{overdue_count} issues are overdue ({overdue_ratio:.1%}).',
                    'actions': [
                        'Prioritize overdue items immediately',
                        'Reassess task estimates and deadlines',
                        'Identify resource constraints',
                        'Implement daily tracking for overdue items'
                    ],
                    'impact': 'high',
                    'effort': 'low',
                    'timeline': '3-5 days'
                })
        
        return recommendations
    
    def _team_performance_recommendations(self, issues: List[Dict]) -> List[Dict[str, Any]]:
        """Generate team performance recommendations"""
        recommendations = []
        
        # Workload distribution analysis
        assignee_counts = {}
        for issue in issues:
            assignee = issue.get('assignee', {}).get('name', 'Unassigned')
            assignee_counts[assignee] = assignee_counts.get(assignee, 0) + 1
        
        if 'Unassigned' in assignee_counts and assignee_counts['Unassigned'] > len(issues) * 0.2:
            recommendations.append({
                'type': 'resource_optimization',
                'priority': 'medium',
                'title': 'High Number of Unassigned Issues',
                'description': f'{assignee_counts["Unassigned"]} issues are unassigned.',
                'actions': [
                    'Assign ownership to all active issues',
                    'Review team capacity and availability',
                    'Consider backlog grooming session',
                    'Implement assignment policies'
                ],
                'impact': 'medium',
                'effort': 'low',
                'timeline': '1-2 days'
            })
        
        # Check workload imbalance
        if len(assignee_counts) > 1:
            assigned_counts = {k: v for k, v in assignee_counts.items() if k != 'Unassigned'}
            if assigned_counts:
                workloads = list(assigned_counts.values())
                if len(workloads) > 1:
                    workload_cv = np.std(workloads) / np.mean(workloads)
                    if workload_cv > 0.5:  # High coefficient of variation
                        recommendations.append({
                            'type': 'workload_balance',
                            'priority': 'medium',
                            'title': 'Uneven Workload Distribution',
                            'description': 'Team workload is significantly imbalanced.',
                            'actions': [
                                'Rebalance task assignments',
                                'Consider skill-based task distribution',
                                'Implement pair programming for knowledge sharing',
                                'Monitor individual capacity regularly'
                            ],
                            'impact': 'medium',
                            'effort': 'medium',
                            'timeline': '1 week'
                        })
        
        return recommendations
    
    def _prioritize_recommendations(self, recommendations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Prioritize recommendations based on impact and urgency"""
        def priority_score(rec):
            priority_weight = self.priority_weights.get(rec.get('priority', 'medium'), 0.6)
            impact_weight = {'high': 1.0, 'medium': 0.7, 'low': 0.4}.get(rec.get('impact', 'medium'), 0.7)
            effort_weight = {'low': 1.0, 'medium': 0.7, 'high': 0.4}.get(rec.get('effort', 'medium'), 0.7)
            
            return priority_weight * impact_weight * effort_weight
        
        return sorted(recommendations, key=priority_score, reverse=True)
    
    def _is_overdue(self, issue: Dict) -> bool:
        """Check if issue is overdue"""
        due_date = issue.get('duedate')
        if not due_date:
            return False
        
        try:
            due_date_obj = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            return due_date_obj < datetime.now() and issue.get('status', {}).get('category') != 'Done'
        except:
            return False
    
    def _load_recommendation_rules(self) -> Dict[str, Any]:
        """Load recommendation rules and patterns"""
        return {
            'completion_thresholds': {'critical': 0.4, 'high': 0.6, 'medium': 0.8},
            'budget_thresholds': {'critical': 0.6, 'high': 0.4, 'medium': 0.3},
            'timeline_thresholds': {'critical': 30, 'high': 20, 'medium': 10},
            'quality_thresholds': {'bug_ratio': 0.3, 'defect_density': 0.2}
        }
    
    def _default_recommendations(self) -> List[Dict[str, Any]]:
        """Default recommendations when analysis fails"""
        return [{
            'type': 'general',
            'priority': 'medium',
            'title': 'Regular Project Health Check',
            'description': 'Maintain regular monitoring of project health metrics.',
            'actions': ['Monitor key project metrics weekly', 'Conduct team retrospectives'],
            'impact': 'medium',
            'effort': 'low',
            'timeline': 'ongoing'
        }]


class MonteCarloSimulator:
    """Advanced Monte Carlo simulation engine for project risk analysis"""
    
    def __init__(self, simulations: int = 1000):
        self.simulations = simulations
        self.random_seed = 42
        
    def run_project_simulation(self, project_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run comprehensive Monte Carlo simulation for project outcomes"""
        try:
            np.random.seed(self.random_seed)
            
            # Initialize simulation parameters
            issues = project_data.get('issues', [])
            if not issues:
                return self._empty_simulation_result()
            
            # Run simulations
            completion_times = []
            cost_outcomes = []
            quality_scores = []
            risk_materializations = []
            
            for sim in range(self.simulations):
                # Simulate project execution
                sim_result = self._simulate_project_execution(issues, sim)
                
                completion_times.append(sim_result['completion_time'])
                cost_outcomes.append(sim_result['final_cost'])
                quality_scores.append(sim_result['quality_score'])
                risk_materializations.append(sim_result['risks_materialized'])
            
            # Analyze results
            results = {
                'completion_analysis': self._analyze_completion_distribution(completion_times),
                'cost_analysis': self._analyze_cost_distribution(cost_outcomes),
                'quality_analysis': self._analyze_quality_distribution(quality_scores),
                'risk_analysis': self._analyze_risk_distribution(risk_materializations),
                'scenario_planning': self._generate_scenario_plans(completion_times, cost_outcomes, quality_scores),
                'sensitivity_analysis': self._perform_sensitivity_analysis(issues),
                'simulation_metadata': {
                    'total_simulations': self.simulations,
                    'confidence_level': 95,
                    'timestamp': datetime.now().isoformat()
                }
            }
            
            return results
            
        except Exception as e:
            logging.error(f"Monte Carlo simulation error: {str(e)}")
            return self._empty_simulation_result()
    
    def _simulate_project_execution(self, issues: List[Dict], simulation_id: int) -> Dict[str, Any]:
        """Simulate a single project execution scenario"""
        # Base project parameters
        total_issues = len(issues)
        completed_issues = len([i for i in issues if i.get('status', {}).get('category') == 'Done'])
        remaining_issues = total_issues - completed_issues
        
        # Stochastic parameters
        velocity_factor = np.random.normal(1.0, 0.2)  # Team velocity variation
        complexity_factor = np.random.lognormal(0, 0.3)  # Task complexity variation
        external_delay_prob = np.random.random()  # External delays probability
        quality_factor = np.random.beta(7, 3)  # Quality outcomes (skewed positive)
        
        # Simulate completion time
        base_completion_days = remaining_issues * np.random.normal(3, 1)  # 3 days per issue avg
        completion_time = base_completion_days * complexity_factor / velocity_factor
        
        # Add external delays
        if external_delay_prob > 0.8:  # 20% chance of external delays
            external_delay = np.random.exponential(5)  # Exponential delay distribution
            completion_time += external_delay
        
        # Simulate cost
        base_cost_per_day = np.random.normal(1000, 200)  # Daily cost variation
        final_cost = completion_time * base_cost_per_day
        
        # Add cost overruns
        if completion_time > base_completion_days * 1.2:  # If significantly delayed
            cost_overrun_factor = np.random.uniform(1.1, 1.5)
            final_cost *= cost_overrun_factor
        
        # Simulate quality
        quality_score = quality_factor
        
        # Degrade quality under pressure
        if completion_time < base_completion_days * 0.8:  # Rushed delivery
            quality_score *= np.random.uniform(0.7, 0.9)
        
        # Simulate risk materialization
        risks_materialized = []
        risk_probabilities = {
            'scope_creep': 0.3,
            'resource_unavailability': 0.2,
            'technical_debt': 0.25,
            'integration_issues': 0.15,
            'stakeholder_changes': 0.2
        }
        
        for risk, prob in risk_probabilities.items():
            if np.random.random() < prob:
                risks_materialized.append(risk)
        
        return {
            'completion_time': max(1, completion_time),
            'final_cost': max(100, final_cost),
            'quality_score': max(0.1, min(1.0, quality_score)),
            'risks_materialized': risks_materialized,
            'simulation_id': simulation_id
        }
    
    def _analyze_completion_distribution(self, completion_times: List[float]) -> Dict[str, Any]:
        """Analyze completion time distribution"""
        completion_array = np.array(completion_times)
        
        return {
            'mean_days': float(np.mean(completion_array)),
            'median_days': float(np.median(completion_array)),
            'std_days': float(np.std(completion_array)),
            'min_days': float(np.min(completion_array)),
            'max_days': float(np.max(completion_array)),
            'percentiles': {
                'p10': float(np.percentile(completion_array, 10)),
                'p25': float(np.percentile(completion_array, 25)),
                'p75': float(np.percentile(completion_array, 75)),
                'p90': float(np.percentile(completion_array, 90)),
                'p95': float(np.percentile(completion_array, 95))
            },
            'probability_distributions': {
                'within_30_days': float(np.mean(completion_array <= 30)),
                'within_60_days': float(np.mean(completion_array <= 60)),
                'within_90_days': float(np.mean(completion_array <= 90)),
                'over_120_days': float(np.mean(completion_array > 120))
            }
        }
    
    def _analyze_cost_distribution(self, cost_outcomes: List[float]) -> Dict[str, Any]:
        """Analyze cost distribution"""
        cost_array = np.array(cost_outcomes)
        
        return {
            'mean_cost': float(np.mean(cost_array)),
            'median_cost': float(np.median(cost_array)),
            'std_cost': float(np.std(cost_array)),
            'percentiles': {
                'p10': float(np.percentile(cost_array, 10)),
                'p50': float(np.percentile(cost_array, 50)),
                'p90': float(np.percentile(cost_array, 90)),
                'p95': float(np.percentile(cost_array, 95))
            },
            'budget_analysis': {
                'budget_baseline': float(np.percentile(cost_array, 50)),
                'conservative_budget': float(np.percentile(cost_array, 80)),
                'contingency_budget': float(np.percentile(cost_array, 95))
            }
        }
    
    def _analyze_quality_distribution(self, quality_scores: List[float]) -> Dict[str, Any]:
        """Analyze quality score distribution"""
        quality_array = np.array(quality_scores)
        
        return {
            'mean_quality': float(np.mean(quality_array)),
            'median_quality': float(np.median(quality_array)),
            'std_quality': float(np.std(quality_array)),
            'quality_ranges': {
                'excellent': float(np.mean(quality_array >= 0.9)),
                'good': float(np.mean((quality_array >= 0.7) & (quality_array < 0.9))),
                'acceptable': float(np.mean((quality_array >= 0.5) & (quality_array < 0.7))),
                'poor': float(np.mean(quality_array < 0.5))
            }
        }
    
    def _analyze_risk_distribution(self, risk_materializations: List[List[str]]) -> Dict[str, Any]:
        """Analyze risk materialization patterns"""
        all_risks = [risk for risks in risk_materializations for risk in risks]
        risk_counts = {}
        
        for risk in all_risks:
            risk_counts[risk] = risk_counts.get(risk, 0) + 1
        
        total_simulations = len(risk_materializations)
        
        return {
            'risk_probabilities': {
                risk: count / total_simulations 
                for risk, count in risk_counts.items()
            },
            'average_risks_per_scenario': float(np.mean([len(risks) for risks in risk_materializations])),
            'no_risk_probability': float(np.mean([len(risks) == 0 for risks in risk_materializations])),
            'high_risk_scenarios': float(np.mean([len(risks) >= 3 for risks in risk_materializations]))
        }
    
    def _generate_scenario_plans(self, completion_times: List[float], 
                                cost_outcomes: List[float], 
                                quality_scores: List[float]) -> Dict[str, Any]:
        """Generate scenario-based planning recommendations"""
        completion_array = np.array(completion_times)
        cost_array = np.array(cost_outcomes)
        quality_array = np.array(quality_scores)
        
        scenarios = {}
        
        # Optimistic scenario (10th percentile)
        scenarios['optimistic'] = {
            'probability': 0.1,
            'completion_days': float(np.percentile(completion_array, 10)),
            'cost': float(np.percentile(cost_array, 10)),
            'quality': float(np.percentile(quality_array, 90)),
            'description': 'Best-case scenario with favorable conditions',
            'planning_assumptions': [
                'Team operates at peak efficiency',
                'No external delays occur',
                'Technical complexity is manageable',
                'No major scope changes'
            ]
        }
        
        # Most likely scenario (50th percentile)
        scenarios['most_likely'] = {
            'probability': 0.5,
            'completion_days': float(np.percentile(completion_array, 50)),
            'cost': float(np.percentile(cost_array, 50)),
            'quality': float(np.percentile(quality_array, 50)),
            'description': 'Expected outcome based on current trends',
            'planning_assumptions': [
                'Normal team velocity',
                'Typical complexity challenges',
                'Some minor delays expected',
                'Standard quality processes'
            ]
        }
        
        # Conservative scenario (90th percentile)
        scenarios['conservative'] = {
            'probability': 0.9,
            'completion_days': float(np.percentile(completion_array, 90)),
            'cost': float(np.percentile(cost_array, 90)),
            'quality': float(np.percentile(quality_array, 10)),
            'description': 'Conservative planning with contingencies',
            'planning_assumptions': [
                'Account for potential delays',
                'Include risk mitigation time',
                'Budget for additional resources',
                'Plan for rework and quality issues'
            ]
        }
        
        return scenarios
    
    def _perform_sensitivity_analysis(self, issues: List[Dict]) -> Dict[str, Any]:
        """Perform sensitivity analysis on key parameters"""
        # This is a simplified sensitivity analysis
        # In practice, you would vary each parameter and measure impact
        
        base_metrics = {
            'team_size': len(set(i.get('assignee', {}).get('name', 'Unassigned') for i in issues if i.get('assignee'))),
            'issue_complexity': np.mean([len(i.get('description', '') or '') for i in issues]),
            'bug_ratio': len([i for i in issues if i.get('issuetype', {}).get('name', '').lower() == 'bug']) / max(1, len(issues))
        }
        
        sensitivity_factors = {
            'team_size': {
                'impact_on_completion': 0.8,  # Adding team members reduces time by 20%
                'impact_on_cost': 1.5,       # But increases cost by 50%
                'impact_on_quality': 1.1     # Slight quality improvement
            },
            'scope_reduction': {
                'impact_on_completion': 0.7,  # 30% time reduction
                'impact_on_cost': 0.8,       # 20% cost reduction
                'impact_on_quality': 1.2     # Better quality due to focus
            },
            'quality_focus': {
                'impact_on_completion': 1.2,  # 20% more time needed
                'impact_on_cost': 1.1,       # 10% cost increase
                'impact_on_quality': 1.4     # 40% quality improvement
            }
        }
        
        return {
            'base_metrics': base_metrics,
            'sensitivity_factors': sensitivity_factors,
            'recommendations': [
                'Adding team members provides diminishing returns after 50% increase',
                'Scope reduction is most effective for timeline compression',
                'Quality focus pays dividends in long-term maintenance'
            ]
        }
    
    def _empty_simulation_result(self) -> Dict[str, Any]:
        """Return empty simulation result for error cases"""
        return {
            'completion_analysis': {'mean_days': 30, 'confidence_interval': [20, 40]},
            'cost_analysis': {'mean_cost': 50000, 'confidence_interval': [40000, 60000]},
            'quality_analysis': {'mean_quality': 0.7},
            'risk_analysis': {'risk_probabilities': {}},
            'scenario_planning': {},
            'sensitivity_analysis': {}
        }