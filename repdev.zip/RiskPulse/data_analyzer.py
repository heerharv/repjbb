import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import logging
import statistics
from collections import defaultdict, Counter
import re

class DataAnalyzer:
    """Advanced data analysis for JIRA project data"""
    
    def __init__(self):
        self.analysis_cache = {}
        self.trend_window_days = 30
        
    def analyze_project_health(self, issues: List[Dict]) -> Dict[str, Any]:
        """Comprehensive project health analysis"""
        try:
            if not issues:
                return {"error": "No issues to analyze"}
            
            health_metrics = {
                "velocity_analysis": self._analyze_velocity_trends(issues),
                "quality_metrics": self._analyze_quality_metrics(issues),
                "team_performance": self._analyze_team_performance(issues),
                "workflow_efficiency": self._analyze_workflow_efficiency(issues),
                "risk_indicators": self._identify_risk_indicators(issues),
                "predictive_insights": self._generate_predictive_insights(issues)
            }
            
            # Calculate overall health score
            health_metrics["overall_health_score"] = self._calculate_health_score(health_metrics)
            health_metrics["health_level"] = self._determine_health_level(health_metrics["overall_health_score"])
            
            return health_metrics
            
        except Exception as e:
            logging.error(f"Project health analysis error: {str(e)}")
            return {"error": f"Analysis failed: {str(e)}"}
    
    def _analyze_velocity_trends(self, issues: List[Dict]) -> Dict[str, Any]:
        """Analyze velocity trends over time"""
        try:
            # Group issues by time periods (sprints or weeks)
            time_periods = self._group_issues_by_time_period(issues)
            
            velocity_data = []
            for period, period_issues in time_periods.items():
                completed_issues = [i for i in period_issues if i.get('status', {}).get('category') == 'Done']
                story_points = sum(i.get('storypoints', 0) or 0 for i in completed_issues)
                velocity_data.append({
                    "period": period,
                    "story_points": story_points,
                    "issues_completed": len(completed_issues),
                    "total_issues": len(period_issues)
                })
            
            # Calculate trend
            if len(velocity_data) >= 2:
                recent_velocity = np.mean([d["story_points"] for d in velocity_data[-3:]])
                older_velocity = np.mean([d["story_points"] for d in velocity_data[:-3]]) if len(velocity_data) > 3 else velocity_data[0]["story_points"]
                
                trend = "improving" if recent_velocity > older_velocity * 1.1 else "declining" if recent_velocity < older_velocity * 0.9 else "stable"
            else:
                trend = "insufficient_data"
            
            return {
                "velocity_history": velocity_data,
                "average_velocity": np.mean([d["story_points"] for d in velocity_data]) if velocity_data else 0,
                "trend": trend,
                "volatility": np.std([d["story_points"] for d in velocity_data]) if len(velocity_data) > 1 else 0,
                "predictability_score": self._calculate_predictability_score(velocity_data)
            }
            
        except Exception as e:
            logging.error(f"Velocity analysis error: {str(e)}")
            return {"error": "Velocity analysis failed"}
    
    def _group_issues_by_time_period(self, issues: List[Dict]) -> Dict[str, List[Dict]]:
        """Group issues by time periods (weekly basis)"""
        periods = defaultdict(list)
        
        for issue in issues:
            created_date = issue.get('created')
            if created_date:
                try:
                    date_obj = datetime.fromisoformat(created_date.replace('Z', '+00:00'))
                    # Group by week
                    week_start = date_obj - timedelta(days=date_obj.weekday())
                    week_key = week_start.strftime("%Y-W%U")
                    periods[week_key].append(issue)
                except:
                    periods["unknown"].append(issue)
            else:
                periods["unknown"].append(issue)
        
        return dict(periods)
    
    def _calculate_predictability_score(self, velocity_data: List[Dict]) -> float:
        """Calculate predictability score based on velocity consistency"""
        if len(velocity_data) < 3:
            return 0.5
        
        velocities = [d["story_points"] for d in velocity_data]
        mean_velocity = np.mean(velocities)
        
        if mean_velocity == 0:
            return 0.0
        
        coefficient_of_variation = np.std(velocities) / mean_velocity
        
        # Lower coefficient of variation = higher predictability
        predictability = max(0, 1 - coefficient_of_variation)
        return min(1.0, predictability)
    
    def _analyze_quality_metrics(self, issues: List[Dict]) -> Dict[str, Any]:
        """Analyze quality metrics"""
        try:
            total_issues = len(issues)
            if total_issues == 0:
                return {"error": "No issues to analyze"}
            
            # Bug analysis
            bug_issues = [i for i in issues if i.get('issuetype', {}).get('name', '').lower() == 'bug']
            bug_ratio = len(bug_issues) / total_issues
            
            # Defect density
            story_issues = [i for i in issues if i.get('issuetype', {}).get('name', '').lower() in ['story', 'feature']]
            defect_density = len(bug_issues) / max(1, len(story_issues))
            
            # Resolution time analysis
            resolution_times = []
            for issue in bug_issues:
                if issue.get('status', {}).get('category') == 'Done':
                    created = issue.get('created')
                    resolved = issue.get('resolutiondate')
                    if created and resolved:
                        try:
                            created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                            resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                            resolution_time = (resolved_date - created_date).days
                            resolution_times.append(resolution_time)
                        except:
                            continue
            
            # Rework analysis
            rework_indicators = self._identify_rework_patterns(issues)
            
            # Quality score calculation
            quality_score = self._calculate_quality_score(bug_ratio, defect_density, resolution_times, rework_indicators)
            
            return {
                "bug_ratio": bug_ratio,
                "defect_density": defect_density,
                "total_bugs": len(bug_issues),
                "average_resolution_time": np.mean(resolution_times) if resolution_times else 0,
                "median_resolution_time": np.median(resolution_times) if resolution_times else 0,
                "rework_indicators": rework_indicators,
                "quality_score": quality_score,
                "quality_trend": self._analyze_quality_trend(issues)
            }
            
        except Exception as e:
            logging.error(f"Quality metrics analysis error: {str(e)}")
            return {"error": "Quality analysis failed"}
    
    def _identify_rework_patterns(self, issues: List[Dict]) -> Dict[str, Any]:
        """Identify patterns indicating rework"""
        rework_patterns = {
            "reopened_issues": 0,
            "multiple_assignee_changes": 0,
            "long_cycle_times": 0,
            "scope_changes": 0
        }
        
        for issue in issues:
            # Check for potential rework indicators
            labels = issue.get('labels', [])
            
            # Look for rework-related labels
            if any('rework' in label.lower() or 'reopen' in label.lower() for label in labels):
                rework_patterns["reopened_issues"] += 1
            
            if any('scope' in label.lower() or 'change' in label.lower() for label in labels):
                rework_patterns["scope_changes"] += 1
            
            # Check cycle time
            created = issue.get('created')
            resolved = issue.get('resolutiondate')
            if created and resolved:
                try:
                    created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                    resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                    cycle_time = (resolved_date - created_date).days
                    
                    # Consider > 30 days as long cycle time
                    if cycle_time > 30:
                        rework_patterns["long_cycle_times"] += 1
                except:
                    continue
        
        return rework_patterns
    
    def _calculate_quality_score(self, bug_ratio: float, defect_density: float, resolution_times: List[float], rework_indicators: Dict) -> float:
        """Calculate overall quality score"""
        # Lower values are better for quality
        bug_score = max(0, 1 - (bug_ratio * 2))  # Scale factor
        defect_score = max(0, 1 - (defect_density * 1.5))
        
        # Resolution time score (shorter is better)
        avg_resolution = np.mean(resolution_times) if resolution_times else 7
        resolution_score = max(0, 1 - (avg_resolution / 30))  # 30 days as baseline
        
        # Rework score
        total_rework = sum(rework_indicators.values())
        rework_score = max(0, 1 - (total_rework / 20))  # 20 as baseline
        
        # Weighted average
        quality_score = (bug_score * 0.3 + defect_score * 0.25 + resolution_score * 0.25 + rework_score * 0.2)
        
        return min(1.0, max(0.0, quality_score))
    
    def _analyze_quality_trend(self, issues: List[Dict]) -> str:
        """Analyze quality trend over time"""
        try:
            # Group issues by time and analyze bug ratio trends
            time_periods = self._group_issues_by_time_period(issues)
            
            bug_ratios = []
            for period, period_issues in time_periods.items():
                if period != "unknown" and period_issues:
                    bugs = len([i for i in period_issues if i.get('issuetype', {}).get('name', '').lower() == 'bug'])
                    ratio = bugs / len(period_issues)
                    bug_ratios.append(ratio)
            
            if len(bug_ratios) < 2:
                return "insufficient_data"
            
            # Compare recent vs older periods
            recent_avg = np.mean(bug_ratios[-3:]) if len(bug_ratios) >= 3 else bug_ratios[-1]
            older_avg = np.mean(bug_ratios[:-3]) if len(bug_ratios) > 3 else bug_ratios[0]
            
            if recent_avg < older_avg * 0.8:
                return "improving"
            elif recent_avg > older_avg * 1.2:
                return "declining"
            else:
                return "stable"
                
        except Exception as e:
            logging.error(f"Quality trend analysis error: {str(e)}")
            return "analysis_failed"
    
    def _analyze_team_performance(self, issues: List[Dict]) -> Dict[str, Any]:
        """Analyze team performance metrics"""
        try:
            # Assignee workload analysis
            assignee_metrics = defaultdict(lambda: {
                'assigned': 0,
                'completed': 0,
                'in_progress': 0,
                'story_points': 0,
                'avg_cycle_time': 0,
                'cycle_times': []
            })
            
            for issue in issues:
                assignee = issue.get('assignee', {}).get('name', 'Unassigned')
                if assignee != 'Unassigned':
                    assignee_metrics[assignee]['assigned'] += 1
                    
                    if issue.get('status', {}).get('category') == 'Done':
                        assignee_metrics[assignee]['completed'] += 1
                        
                        # Calculate cycle time
                        created = issue.get('created')
                        resolved = issue.get('resolutiondate')
                        if created and resolved:
                            try:
                                created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                                resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                                cycle_time = (resolved_date - created_date).days
                                assignee_metrics[assignee]['cycle_times'].append(cycle_time)
                            except:
                                continue
                    
                    elif 'progress' in issue.get('status', {}).get('name', '').lower():
                        assignee_metrics[assignee]['in_progress'] += 1
                    
                    assignee_metrics[assignee]['story_points'] += issue.get('storypoints', 0) or 0
            
            # Calculate averages and performance metrics
            team_performance = {}
            for assignee, metrics in assignee_metrics.items():
                if metrics['cycle_times']:
                    avg_cycle_time = np.mean(metrics['cycle_times'])
                else:
                    avg_cycle_time = 0
                
                completion_rate = metrics['completed'] / max(1, metrics['assigned'])
                
                team_performance[assignee] = {
                    'completion_rate': completion_rate,
                    'average_cycle_time': avg_cycle_time,
                    'total_story_points': metrics['story_points'],
                    'productivity_score': self._calculate_productivity_score(metrics),
                    'workload_balance': self._assess_workload_balance(metrics, assignee_metrics)
                }
            
            # Team-wide metrics
            team_wide_metrics = self._calculate_team_wide_metrics(team_performance)
            
            return {
                'individual_performance': team_performance,
                'team_metrics': team_wide_metrics,
                'collaboration_score': self._assess_collaboration(issues),
                'knowledge_distribution': self._analyze_knowledge_distribution(issues)
            }
            
        except Exception as e:
            logging.error(f"Team performance analysis error: {str(e)}")
            return {"error": "Team performance analysis failed"}
    
    def _calculate_productivity_score(self, metrics: Dict) -> float:
        """Calculate individual productivity score"""
        completion_rate = metrics['completed'] / max(1, metrics['assigned'])
        
        # Factor in cycle time (shorter is better)
        avg_cycle_time = np.mean(metrics['cycle_times']) if metrics['cycle_times'] else 14  # 2 weeks default
        cycle_score = max(0, 1 - (avg_cycle_time / 21))  # 3 weeks as baseline
        
        # Factor in story points delivery
        story_point_factor = min(1, metrics['story_points'] / max(1, metrics['assigned'] * 3))  # 3 points per issue average
        
        # Weighted productivity score
        productivity = (completion_rate * 0.4 + cycle_score * 0.3 + story_point_factor * 0.3)
        
        return min(1.0, max(0.0, productivity))
    
    def _assess_workload_balance(self, individual_metrics: Dict, all_metrics: Dict) -> str:
        """Assess individual workload balance compared to team"""
        if len(all_metrics) < 2:
            return "balanced"
        
        individual_assigned = individual_metrics['assigned']
        team_assignments = [m['assigned'] for m in all_metrics.values()]
        team_avg = np.mean(team_assignments)
        
        if individual_assigned > team_avg * 1.3:
            return "overloaded"
        elif individual_assigned < team_avg * 0.7:
            return "underutilized"
        else:
            return "balanced"
    
    def _calculate_team_wide_metrics(self, team_performance: Dict) -> Dict[str, Any]:
        """Calculate team-wide performance metrics"""
        if not team_performance:
            return {}
        
        completion_rates = [p['completion_rate'] for p in team_performance.values()]
        cycle_times = [p['average_cycle_time'] for p in team_performance.values() if p['average_cycle_time'] > 0]
        productivity_scores = [p['productivity_score'] for p in team_performance.values()]
        
        return {
            'average_completion_rate': np.mean(completion_rates),
            'average_cycle_time': np.mean(cycle_times) if cycle_times else 0,
            'team_productivity_score': np.mean(productivity_scores),
            'performance_variance': np.std(productivity_scores),
            'high_performers': len([p for p in productivity_scores if p > 0.8]),
            'underperformers': len([p for p in productivity_scores if p < 0.5])
        }
    
    def _assess_collaboration(self, issues: List[Dict]) -> float:
        """Assess team collaboration based on issue interactions"""
        collaboration_indicators = 0
        total_issues = len(issues)
        
        for issue in issues:
            assignee = issue.get('assignee', {}).get('name')
            reporter = issue.get('reporter', {}).get('name')
            
            # Different assignee and reporter indicates collaboration
            if assignee and reporter and assignee != reporter:
                collaboration_indicators += 1
            
            # Multiple people involved in components
            components = issue.get('components', [])
            if len(components) > 1:
                collaboration_indicators += 0.5
        
        return min(1.0, collaboration_indicators / max(1, total_issues))
    
    def _analyze_knowledge_distribution(self, issues: List[Dict]) -> Dict[str, Any]:
        """Analyze knowledge distribution across team"""
        component_assignees = defaultdict(set)
        skill_areas = defaultdict(int)
        
        for issue in issues:
            assignee = issue.get('assignee', {}).get('name', 'Unassigned')
            components = issue.get('components', [])
            
            for component in components:
                component_name = component.get('name', component) if isinstance(component, dict) else str(component)
                component_assignees[component_name].add(assignee)
                skill_areas[assignee] += 1
        
        # Calculate knowledge distribution metrics
        single_person_components = len([comp for comp, assignees in component_assignees.items() if len(assignees) == 1])
        total_components = len(component_assignees)
        
        knowledge_risk = single_person_components / max(1, total_components)
        
        return {
            'knowledge_risk_score': knowledge_risk,
            'component_coverage': dict(component_assignees),
            'skill_distribution': dict(skill_areas),
            'critical_knowledge_areas': [comp for comp, assignees in component_assignees.items() if len(assignees) == 1]
        }
    
    def _analyze_workflow_efficiency(self, issues: List[Dict]) -> Dict[str, Any]:
        """Analyze workflow efficiency metrics"""
        try:
            # Status transition analysis
            status_counts = Counter(issue.get('status', {}).get('name', 'Unknown') for issue in issues)
            
            # Bottleneck identification
            bottlenecks = self._identify_bottlenecks(issues)
            
            # Flow efficiency
            flow_efficiency = self._calculate_flow_efficiency(issues)
            
            # Cycle time distribution
            cycle_time_analysis = self._analyze_cycle_time_distribution(issues)
            
            return {
                'status_distribution': dict(status_counts),
                'bottlenecks': bottlenecks,
                'flow_efficiency': flow_efficiency,
                'cycle_time_analysis': cycle_time_analysis,
                'workflow_health_score': self._calculate_workflow_health_score(bottlenecks, flow_efficiency)
            }
            
        except Exception as e:
            logging.error(f"Workflow efficiency analysis error: {str(e)}")
            return {"error": "Workflow analysis failed"}
    
    def _identify_bottlenecks(self, issues: List[Dict]) -> List[Dict]:
        """Identify workflow bottlenecks"""
        status_counts = Counter()
        status_durations = defaultdict(list)
        
        for issue in issues:
            status = issue.get('status', {}).get('name', 'Unknown')
            status_counts[status] += 1
            
            # Calculate time in current status (simplified)
            updated = issue.get('updated')
            if updated:
                try:
                    updated_date = datetime.fromisoformat(updated.replace('Z', '+00:00'))
                    days_in_status = (datetime.now() - updated_date).days
                    status_durations[status].append(days_in_status)
                except:
                    continue
        
        bottlenecks = []
        total_issues = len(issues)
        
        for status, count in status_counts.items():
            if count > total_issues * 0.3:  # More than 30% of issues in one status
                avg_duration = np.mean(status_durations[status]) if status_durations[status] else 0
                bottlenecks.append({
                    'status': status,
                    'issue_count': count,
                    'percentage': (count / total_issues) * 100,
                    'average_duration_days': avg_duration,
                    'severity': 'high' if count > total_issues * 0.5 else 'medium'
                })
        
        return bottlenecks
    
    def _calculate_flow_efficiency(self, issues: List[Dict]) -> float:
        """Calculate flow efficiency (active time / total cycle time)"""
        flow_ratios = []
        
        for issue in issues:
            if issue.get('status', {}).get('category') == 'Done':
                time_estimate = issue.get('timeestimate', 0) or 0
                time_spent = issue.get('timespent', 0) or 0
                
                created = issue.get('created')
                resolved = issue.get('resolutiondate')
                
                if created and resolved and time_spent > 0 and time_estimate > 0:
                    try:
                        created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                        resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                        total_time = (resolved_date - created_date).total_seconds()
                        
                        if total_time > 0:
                            active_time = time_spent  # in seconds
                            flow_ratio = min(1.0, active_time / total_time)
                            flow_ratios.append(flow_ratio)
                    except:
                        continue
        
        return np.mean(flow_ratios) if flow_ratios else 0.3  # Default estimate
    
    def _analyze_cycle_time_distribution(self, issues: List[Dict]) -> Dict[str, Any]:
        """Analyze cycle time distribution"""
        cycle_times = []
        
        for issue in issues:
            if issue.get('status', {}).get('category') == 'Done':
                created = issue.get('created')
                resolved = issue.get('resolutiondate')
                
                if created and resolved:
                    try:
                        created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                        resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                        cycle_time = (resolved_date - created_date).days
                        if cycle_time >= 0:
                            cycle_times.append(cycle_time)
                    except:
                        continue
        
        if not cycle_times:
            return {"error": "No completed issues with valid dates"}
        
        return {
            'average': np.mean(cycle_times),
            'median': np.median(cycle_times),
            'percentile_85': np.percentile(cycle_times, 85),
            'percentile_95': np.percentile(cycle_times, 95),
            'standard_deviation': np.std(cycle_times),
            'min': min(cycle_times),
            'max': max(cycle_times),
            'distribution': self._create_cycle_time_histogram(cycle_times)
        }
    
    def _create_cycle_time_histogram(self, cycle_times: List[float]) -> Dict[str, int]:
        """Create histogram of cycle times"""
        bins = [0, 1, 3, 7, 14, 30, 60, float('inf')]
        labels = ['Same day', '1-3 days', '3-7 days', '1-2 weeks', '2-4 weeks', '1-2 months', '2+ months']
        
        histogram = {label: 0 for label in labels}
        
        for cycle_time in cycle_times:
            for i, bin_edge in enumerate(bins[1:]):
                if cycle_time <= bin_edge:
                    histogram[labels[i]] += 1
                    break
        
        return histogram
    
    def _calculate_workflow_health_score(self, bottlenecks: List[Dict], flow_efficiency: float) -> float:
        """Calculate overall workflow health score"""
        # Lower bottleneck impact = better score
        bottleneck_impact = sum(b.get('percentage', 0) for b in bottlenecks if b.get('severity') == 'high') / 100
        bottleneck_score = max(0, 1 - bottleneck_impact)
        
        # Higher flow efficiency = better score
        flow_score = flow_efficiency
        
        # Weighted combination
        workflow_health = (bottleneck_score * 0.6 + flow_score * 0.4)
        
        return min(1.0, max(0.0, workflow_health))
    
    def _identify_risk_indicators(self, issues: List[Dict]) -> List[Dict]:
        """Identify early risk indicators"""
        risk_indicators = []
        
        # Overdue issues
        overdue_count = len([i for i in issues if self._is_overdue(i)])
        if overdue_count > 0:
            risk_indicators.append({
                'type': 'overdue_issues',
                'severity': 'high' if overdue_count > len(issues) * 0.2 else 'medium',
                'count': overdue_count,
                'description': f'{overdue_count} issues are overdue'
            })
        
        # High priority backlog
        high_priority_todo = len([
            i for i in issues 
            if self._is_high_priority(i) and i.get('status', {}).get('category') not in ['Done']
        ])
        if high_priority_todo > 0:
            risk_indicators.append({
                'type': 'high_priority_backlog',
                'severity': 'medium',
                'count': high_priority_todo,
                'description': f'{high_priority_todo} high priority items in backlog'
            })
        
        # Blocked issues
        blocked_issues = len([i for i in issues if self._is_blocked(i)])
        if blocked_issues > 0:
            risk_indicators.append({
                'type': 'blocked_issues',
                'severity': 'high',
                'count': blocked_issues,
                'description': f'{blocked_issues} issues are blocked'
            })
        
        # Scope creep indicators
        scope_changes = len([i for i in issues if self._has_scope_changes(i)])
        if scope_changes > len(issues) * 0.1:  # More than 10% scope changes
            risk_indicators.append({
                'type': 'scope_creep',
                'severity': 'medium',
                'count': scope_changes,
                'description': f'Potential scope creep detected in {scope_changes} issues'
            })
        
        return risk_indicators
    
    def _is_overdue(self, issue: Dict) -> bool:
        """Check if issue is overdue"""
        due_date = issue.get('duedate')
        if not due_date:
            return False
        
        try:
            due_date_obj = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            return due_date_obj < datetime.now() and issue.get('status', {}).get('category') != 'Done'
        except:
            return False
    
    def _is_high_priority(self, issue: Dict) -> bool:
        """Check if issue has high priority"""
        priority = issue.get('priority', {}).get('name', '').lower()
        return priority in ['high', 'highest', 'critical', 'blocker']
    
    def _is_blocked(self, issue: Dict) -> bool:
        """Check if issue is blocked"""
        labels = issue.get('labels', [])
        status = issue.get('status', {}).get('name', '').lower()
        return any('block' in label.lower() for label in labels) or 'blocked' in status
    
    def _has_scope_changes(self, issue: Dict) -> bool:
        """Check if issue has scope change indicators"""
        labels = issue.get('labels', [])
        return any('scope' in label.lower() or 'change' in label.lower() for label in labels)
    
    def _generate_predictive_insights(self, issues: List[Dict]) -> Dict[str, Any]:
        """Generate predictive insights based on current trends"""
        try:
            insights = {
                'completion_forecast': self._forecast_completion(issues),
                'risk_escalation': self._predict_risk_escalation(issues),
                'resource_needs': self._predict_resource_needs(issues),
                'quality_outlook': self._predict_quality_outlook(issues)
            }
            
            return insights
            
        except Exception as e:
            logging.error(f"Predictive insights error: {str(e)}")
            return {"error": "Predictive analysis failed"}
    
    def _forecast_completion(self, issues: List[Dict]) -> Dict[str, Any]:
        """Forecast project completion based on current velocity"""
        completed_issues = len([i for i in issues if i.get('status', {}).get('category') == 'Done'])
        total_issues = len(issues)
        remaining_issues = total_issues - completed_issues
        
        if completed_issues == 0:
            return {"error": "No completed issues to base forecast on"}
        
        # Calculate average completion rate
        velocity_data = self._analyze_velocity_trends(issues)
        avg_velocity = velocity_data.get('average_velocity', 0)
        
        if avg_velocity == 0:
            return {"error": "No velocity data available"}
        
        # Estimate completion time
        weeks_to_completion = remaining_issues / max(1, avg_velocity / 7)  # Convert to weekly velocity
        completion_date = datetime.now() + timedelta(weeks=weeks_to_completion)
        
        return {
            'estimated_completion_date': completion_date.isoformat(),
            'weeks_remaining': weeks_to_completion,
            'confidence_level': self._calculate_forecast_confidence(velocity_data),
            'assumptions': [
                'Current velocity maintained',
                'No major scope changes',
                'Team capacity remains stable'
            ]
        }
    
    def _predict_risk_escalation(self, issues: List[Dict]) -> List[Dict]:
        """Predict which risks are likely to escalate"""
        risk_predictions = []
        
        # Analyze current risk indicators
        current_risks = self._identify_risk_indicators(issues)
        
        for risk in current_risks:
            if risk['type'] == 'overdue_issues' and risk['severity'] == 'medium':
                risk_predictions.append({
                    'risk_type': 'overdue_escalation',
                    'probability': 0.7,
                    'timeline': '1-2 weeks',
                    'impact': 'Project delays and stakeholder concerns'
                })
            
            if risk['type'] == 'blocked_issues':
                risk_predictions.append({
                    'risk_type': 'dependency_failure',
                    'probability': 0.6,
                    'timeline': '2-3 weeks',
                    'impact': 'Significant delays and resource reallocation needed'
                })
        
        return risk_predictions
    
    def _predict_resource_needs(self, issues: List[Dict]) -> Dict[str, Any]:
        """Predict future resource needs"""
        # Analyze current workload distribution
        assignee_workload = defaultdict(int)
        for issue in issues:
            if issue.get('status', {}).get('category') not in ['Done']:
                assignee = issue.get('assignee', {}).get('name', 'Unassigned')
                assignee_workload[assignee] += 1
        
        unassigned_count = assignee_workload.get('Unassigned', 0)
        
        resource_needs = {
            'additional_capacity_needed': unassigned_count > len(issues) * 0.2,
            'skill_gaps': self._identify_skill_gaps(issues),
            'capacity_utilization': self._calculate_capacity_utilization(assignee_workload),
            'recommendations': []
        }
        
        if unassigned_count > 0:
            resource_needs['recommendations'].append(f'Assign {unassigned_count} unassigned issues')
        
        return resource_needs
    
    def _predict_quality_outlook(self, issues: List[Dict]) -> Dict[str, Any]:
        """Predict quality outlook based on current trends"""
        quality_metrics = self._analyze_quality_metrics(issues)
        
        quality_trend = quality_metrics.get('quality_trend', 'stable')
        current_score = quality_metrics.get('quality_score', 0.5)
        
        if quality_trend == 'declining':
            predicted_score = max(0, current_score - 0.1)
            outlook = 'concerning'
        elif quality_trend == 'improving':
            predicted_score = min(1, current_score + 0.1)
            outlook = 'positive'
        else:
            predicted_score = current_score
            outlook = 'stable'
        
        return {
            'current_quality_score': current_score,
            'predicted_quality_score': predicted_score,
            'outlook': outlook,
            'trend': quality_trend,
            'recommendations': self._generate_quality_recommendations(quality_metrics)
        }
    
    def _calculate_forecast_confidence(self, velocity_data: Dict) -> float:
        """Calculate confidence in completion forecast"""
        predictability = velocity_data.get('predictability_score', 0.5)
        data_points = len(velocity_data.get('velocity_history', []))
        
        # More data points and higher predictability = higher confidence
        confidence = (predictability * 0.7) + (min(data_points / 10, 1) * 0.3)
        return min(1.0, confidence)
    
    def _identify_skill_gaps(self, issues: List[Dict]) -> List[str]:
        """Identify potential skill gaps based on issue types and components"""
        skill_gaps = []
        
        # Analyze unassigned issues by type
        unassigned_issues = [i for i in issues if i.get('assignee', {}).get('name', 'Unassigned') == 'Unassigned']
        
        if unassigned_issues:
            issue_types = Counter(i.get('issuetype', {}).get('name', 'Unknown') for i in unassigned_issues)
            for issue_type, count in issue_types.most_common(3):
                if count > 2:  # More than 2 unassigned issues of same type
                    skill_gaps.append(f'{issue_type} expertise needed')
        
        return skill_gaps
    
    def _calculate_capacity_utilization(self, assignee_workload: Dict) -> float:
        """Calculate team capacity utilization"""
        if not assignee_workload or 'Unassigned' in assignee_workload and len(assignee_workload) == 1:
            return 0.0
        
        # Remove unassigned from calculation
        assigned_workload = {k: v for k, v in assignee_workload.items() if k != 'Unassigned'}
        
        if not assigned_workload:
            return 0.0
        
        workloads = list(assigned_workload.values())
        avg_workload = np.mean(workloads)
        
        # Assume optimal workload is around 8-10 issues per person
        optimal_workload = 9
        utilization = min(1.0, avg_workload / optimal_workload)
        
        return utilization
    
    def _generate_quality_recommendations(self, quality_metrics: Dict) -> List[str]:
        """Generate quality improvement recommendations"""
        recommendations = []
        
        bug_ratio = quality_metrics.get('bug_ratio', 0)
        if bug_ratio > 0.15:  # More than 15% bugs
            recommendations.append('Implement stricter code review processes')
            recommendations.append('Increase automated testing coverage')
        
        avg_resolution_time = quality_metrics.get('average_resolution_time', 0)
        if avg_resolution_time > 14:  # More than 2 weeks
            recommendations.append('Improve bug triage and prioritization processes')
        
        rework_indicators = quality_metrics.get('rework_indicators', {})
        if rework_indicators.get('scope_changes', 0) > 3:
            recommendations.append('Strengthen requirements analysis and stakeholder alignment')
        
        return recommendations
    
    def _calculate_health_score(self, health_metrics: Dict) -> float:
        """Calculate overall project health score"""
        scores = []
        
        # Velocity score
        velocity_analysis = health_metrics.get('velocity_analysis', {})
        if 'predictability_score' in velocity_analysis:
            scores.append(velocity_analysis['predictability_score'])
        
        # Quality score
        quality_metrics = health_metrics.get('quality_metrics', {})
        if 'quality_score' in quality_metrics:
            scores.append(quality_metrics['quality_score'])
        
        # Team performance score
        team_performance = health_metrics.get('team_performance', {})
        team_metrics = team_performance.get('team_metrics', {})
        if 'team_productivity_score' in team_metrics:
            scores.append(team_metrics['team_productivity_score'])
        
        # Workflow efficiency score
        workflow_efficiency = health_metrics.get('workflow_efficiency', {})
        if 'workflow_health_score' in workflow_efficiency:
            scores.append(workflow_efficiency['workflow_health_score'])
        
        # Risk indicator penalty
        risk_indicators = health_metrics.get('risk_indicators', [])
        high_risk_count = len([r for r in risk_indicators if r.get('severity') == 'high'])
        risk_penalty = min(0.3, high_risk_count * 0.1)
        
        # Calculate weighted average
        if scores:
            base_score = np.mean(scores)
            health_score = max(0, base_score - risk_penalty)
        else:
            health_score = 0.5  # Default neutral score
        
        return min(1.0, health_score)
    
    def _determine_health_level(self, score: float) -> str:
        """Determine health level from score"""
        if score >= 0.8:
            return "excellent"
        elif score >= 0.6:
            return "good"
        elif score >= 0.4:
            return "fair"
        elif score >= 0.2:
            return "poor"
        else:
            return "critical"
