import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
from dataclasses import dataclass
from advanced_ml_models import RealTimeRiskPredictor, MonteCarloSimulator, AIRecommendationEngine
from data_analyzer import DataAnalyzer
from integrations import IntegrationManager, RealTimeDataProcessor
# Database service imports removed to avoid circular imports
import statistics

@dataclass
class RiskMetric:
    name: str
    value: float
    severity: str
    confidence: float
    trend: str
    recommendations: List[str]

class RiskEngine:
    def __init__(self):
        self.risk_predictor = RealTimeRiskPredictor()
        self.data_analyzer = DataAnalyzer()
        self.monte_carlo_simulator = MonteCarloSimulator()
        self.ai_recommendation_engine = AIRecommendationEngine()
        self.integration_manager = IntegrationManager()
        self.real_time_processor = RealTimeDataProcessor(self.risk_predictor, self.integration_manager)
        # Database service will be initialized later to avoid circular imports
        self.db_service = None
        
        self.severity_thresholds = {
            'low': 0.3,
            'medium': 0.6,
            'high': 0.8,
            'critical': 1.0
        }
        
        logging.info("Advanced Risk Engine with real-time ML and integrations initialized")
        
    def analyze_project_risks(self, project_data: Dict) -> Dict[str, Any]:
        """Comprehensive risk analysis of a project"""
        try:
            issues = project_data.get('issues', [])
            if not issues:
                return {"error": "No issues found for analysis"}
            
            # Calculate all risk metrics
            results = {
                "overview": self._calculate_risk_overview(issues),
                "benefit_case": self.calculate_benefit_case(project_data),
                "say_do_ratio": self.calculate_say_do_ratio(project_data),
                "dependency_impact": self.analyze_dependency_impact(project_data),
                "spillover_analysis": self.analyze_spillover_effects(project_data),
                "idle_time": self.track_idle_time(project_data),
                "cost_variance": self.analyze_cost_variance(project_data),
                "timeline_variance": self.analyze_timeline_variance(project_data),
                "resource_variance": self.analyze_resource_variance(project_data),
                "resource_utilization": self.analyze_resource_utilization(project_data),
                "risk_impact": self.assess_risk_impact(project_data),
                "speed_to_market": self.analyze_speed_to_market(project_data),
                "success_criteria": self.evaluate_success_criteria(project_data),
                "predictive_insights": self.generate_predictive_analytics(project_data)
            }
            
            # Calculate overall risk score
            results["overall_risk_score"] = self._calculate_overall_risk_score(results)
            results["risk_level"] = self._determine_risk_level(results["overall_risk_score"])
            results["timestamp"] = datetime.now().isoformat()
            
            return results
            
        except Exception as e:
            logging.error(f"Risk analysis error: {str(e)}")
            return {"error": f"Analysis failed: {str(e)}"}
    
    def calculate_benefit_case(self, project_data: Dict) -> Dict[str, Any]:
        """Calculate benefit case analysis (tangible/intangible)"""
        try:
            issues = project_data.get('issues', [])
            
            # Analyze story points and completion rates
            total_story_points = sum(issue.get('storypoints', 0) or 0 for issue in issues)
            completed_story_points = sum(
                issue.get('storypoints', 0) or 0 
                for issue in issues 
                if issue.get('status', {}).get('category') == 'Done'
            )
            
            # Calculate tangible benefits
            tangible_benefits = {
                "story_points_delivered": completed_story_points,
                "completion_rate": (completed_story_points / total_story_points * 100) if total_story_points > 0 else 0,
                "velocity": self._calculate_velocity(issues),
                "cost_savings": self._estimate_cost_savings(issues),
                "time_saved": self._estimate_time_savings(issues)
            }
            
            # Calculate intangible benefits
            intangible_benefits = {
                "team_satisfaction": self._assess_team_satisfaction(issues),
                "code_quality": self._assess_code_quality(issues),
                "knowledge_transfer": self._assess_knowledge_transfer(issues),
                "process_improvement": self._assess_process_improvement(issues),
                "stakeholder_confidence": self._assess_stakeholder_confidence(issues)
            }
            
            # Overall benefit score
            benefit_score = self._calculate_benefit_score(tangible_benefits, intangible_benefits)
            
            return {
                "tangible_benefits": tangible_benefits,
                "intangible_benefits": intangible_benefits,
                "overall_benefit_score": benefit_score,
                "benefit_trend": self._analyze_benefit_trend(issues),
                "recommendations": self._generate_benefit_recommendations(tangible_benefits, intangible_benefits)
            }
            
        except Exception as e:
            return {"error": f"Benefit case calculation failed: {str(e)}"}
    
    def calculate_say_do_ratio(self, project_data: Dict) -> Dict[str, Any]:
        """Calculate Say-Do ratio (promises vs delivery)"""
        try:
            issues = project_data.get('issues', [])
            
            # Analyze commitments vs deliveries
            committed_features = self._count_committed_features(issues)
            delivered_features = self._count_delivered_features(issues)
            
            # Calculate ratio
            say_do_ratio = (delivered_features / committed_features * 100) if committed_features > 0 else 0
            
            # Analyze timeline commitments
            timeline_commitments = self._analyze_timeline_commitments(issues)
            
            # Quality commitments
            quality_commitments = self._analyze_quality_commitments(issues)
            
            return {
                "overall_ratio": say_do_ratio,
                "feature_delivery": {
                    "committed": committed_features,
                    "delivered": delivered_features,
                    "ratio": say_do_ratio
                },
                "timeline_performance": timeline_commitments,
                "quality_performance": quality_commitments,
                "trend_analysis": self._analyze_say_do_trend(issues),
                "risk_level": self._assess_say_do_risk(say_do_ratio),
                "recommendations": self._generate_say_do_recommendations(say_do_ratio)
            }
            
        except Exception as e:
            return {"error": f"Say-Do ratio calculation failed: {str(e)}"}
    
    def analyze_dependency_impact(self, project_data: Dict) -> Dict[str, Any]:
        """Analyze dependency impact on project"""
        try:
            issues = project_data.get('issues', [])
            
            # Identify dependencies
            dependencies = self._identify_dependencies(issues)
            
            # Analyze critical path
            critical_path = self._analyze_critical_path(issues, dependencies)
            
            # Calculate dependency risk
            dependency_risk = self._calculate_dependency_risk(dependencies)
            
            # Analyze blocking issues
            blocking_issues = self._identify_blocking_issues(issues)
            
            return {
                "total_dependencies": len(dependencies),
                "critical_path_length": len(critical_path),
                "dependency_risk_score": dependency_risk,
                "blocking_issues": len(blocking_issues),
                "dependency_network": self._build_dependency_network(dependencies),
                "impact_analysis": {
                    "high_impact": [dep for dep in dependencies if dep.get('impact', 0) > 0.7],
                    "medium_impact": [dep for dep in dependencies if 0.4 <= dep.get('impact', 0) <= 0.7],
                    "low_impact": [dep for dep in dependencies if dep.get('impact', 0) < 0.4]
                },
                "mitigation_strategies": self._generate_dependency_mitigation(dependencies),
                "recommendations": self._generate_dependency_recommendations(dependency_risk)
            }
            
        except Exception as e:
            return {"error": f"Dependency impact analysis failed: {str(e)}"}
    
    def analyze_spillover_effects(self, project_data: Dict) -> Dict[str, Any]:
        """Analyze spillover effects and cross-project impacts"""
        try:
            issues = project_data.get('issues', [])
            
            # Analyze resource spillover
            resource_spillover = self._analyze_resource_spillover(issues)
            
            # Analyze timeline spillover
            timeline_spillover = self._analyze_timeline_spillover(issues)
            
            # Analyze scope spillover
            scope_spillover = self._analyze_scope_spillover(issues)
            
            # Calculate spillover risk
            spillover_risk = self._calculate_spillover_risk(resource_spillover, timeline_spillover, scope_spillover)
            
            return {
                "resource_spillover": resource_spillover,
                "timeline_spillover": timeline_spillover,
                "scope_spillover": scope_spillover,
                "overall_spillover_risk": spillover_risk,
                "affected_projects": self._identify_affected_projects(issues),
                "spillover_reasons": self._analyze_spillover_reasons(issues),
                "impact_magnitude": self._calculate_spillover_magnitude(spillover_risk),
                "mitigation_actions": self._generate_spillover_mitigation(spillover_risk),
                "recommendations": self._generate_spillover_recommendations(spillover_risk)
            }
            
        except Exception as e:
            return {"error": f"Spillover analysis failed: {str(e)}"}
    
    def track_idle_time(self, project_data: Dict) -> Dict[str, Any]:
        """Track idle time and resource gaps"""
        try:
            issues = project_data.get('issues', [])
            
            # Analyze idle periods
            idle_periods = self._identify_idle_periods(issues)
            
            # Calculate idle time by resource
            resource_idle_time = self._calculate_resource_idle_time(issues)
            
            # Analyze idle time patterns
            idle_patterns = self._analyze_idle_patterns(idle_periods)
            
            # Calculate idle time cost
            idle_cost = self._calculate_idle_cost(resource_idle_time)
            
            return {
                "total_idle_hours": sum(period['duration'] for period in idle_periods),
                "idle_periods": len(idle_periods),
                "resource_idle_breakdown": resource_idle_time,
                "idle_patterns": idle_patterns,
                "idle_cost_estimate": idle_cost,
                "efficiency_score": self._calculate_efficiency_score(resource_idle_time),
                "peak_idle_times": self._identify_peak_idle_times(idle_periods),
                "recommendations": self._generate_idle_time_recommendations(resource_idle_time)
            }
            
        except Exception as e:
            return {"error": f"Idle time tracking failed: {str(e)}"}
    
    def analyze_cost_variance(self, project_data: Dict) -> Dict[str, Any]:
        """Compare estimated vs actual costs"""
        try:
            issues = project_data.get('issues', [])
            
            # Calculate estimated costs
            estimated_costs = self._calculate_estimated_costs(issues)
            
            # Calculate actual costs
            actual_costs = self._calculate_actual_costs(issues)
            
            # Calculate variance
            cost_variance = self._calculate_cost_variance(estimated_costs, actual_costs)
            
            return {
                "estimated_total": estimated_costs['total'],
                "actual_total": actual_costs['total'],
                "variance_amount": cost_variance['amount'],
                "variance_percentage": cost_variance['percentage'],
                "cost_breakdown": {
                    "development": {
                        "estimated": estimated_costs['development'],
                        "actual": actual_costs['development'],
                        "variance": cost_variance['development']
                    },
                    "testing": {
                        "estimated": estimated_costs['testing'],
                        "actual": actual_costs['testing'],
                        "variance": cost_variance['testing']
                    },
                    "deployment": {
                        "estimated": estimated_costs['deployment'],
                        "actual": actual_costs['deployment'],
                        "variance": cost_variance['deployment']
                    }
                },
                "cost_trends": self._analyze_cost_trends(issues),
                "cost_drivers": self._identify_cost_drivers(issues),
                "recommendations": self._generate_cost_recommendations(cost_variance)
            }
            
        except Exception as e:
            return {"error": f"Cost variance analysis failed: {str(e)}"}
    
    def analyze_timeline_variance(self, project_data: Dict) -> Dict[str, Any]:
        """Compare estimated vs actual timeline"""
        try:
            issues = project_data.get('issues', [])
            
            # Calculate timeline metrics
            estimated_timeline = self._calculate_estimated_timeline(issues)
            actual_timeline = self._calculate_actual_timeline(issues)
            timeline_variance = self._calculate_timeline_variance(estimated_timeline, actual_timeline)
            
            return {
                "estimated_duration": estimated_timeline['total_days'],
                "actual_duration": actual_timeline['total_days'],
                "variance_days": timeline_variance['days'],
                "variance_percentage": timeline_variance['percentage'],
                "milestone_analysis": self._analyze_milestone_variance(issues),
                "delay_analysis": self._analyze_delays(issues),
                "acceleration_opportunities": self._identify_acceleration_opportunities(issues),
                "timeline_trends": self._analyze_timeline_trends(issues),
                "critical_path_delays": self._analyze_critical_path_delays(issues),
                "recommendations": self._generate_timeline_recommendations(timeline_variance)
            }
            
        except Exception as e:
            return {"error": f"Timeline variance analysis failed: {str(e)}"}
    
    def analyze_resource_variance(self, project_data: Dict) -> Dict[str, Any]:
        """Compare estimated vs actual resources"""
        try:
            issues = project_data.get('issues', [])
            
            # Calculate resource metrics
            estimated_resources = self._calculate_estimated_resources(issues)
            actual_resources = self._calculate_actual_resources(issues)
            resource_variance = self._calculate_resource_variance(estimated_resources, actual_resources)
            
            return {
                "estimated_hours": estimated_resources['total_hours'],
                "actual_hours": actual_resources['total_hours'],
                "variance_hours": resource_variance['hours'],
                "variance_percentage": resource_variance['percentage'],
                "resource_breakdown": self._analyze_resource_breakdown(issues),
                "skill_gap_analysis": self._analyze_skill_gaps(issues),
                "resource_allocation": self._analyze_resource_allocation(issues),
                "productivity_metrics": self._calculate_productivity_metrics(issues),
                "recommendations": self._generate_resource_recommendations(resource_variance)
            }
            
        except Exception as e:
            return {"error": f"Resource variance analysis failed: {str(e)}"}
    
    def analyze_resource_utilization(self, project_data: Dict) -> Dict[str, Any]:
        """Analyze resource utilization optimization"""
        try:
            issues = project_data.get('issues', [])
            
            # Calculate utilization metrics
            utilization_metrics = self._calculate_utilization_metrics(issues)
            
            # Identify optimization opportunities
            optimization_opportunities = self._identify_optimization_opportunities(issues)
            
            return {
                "overall_utilization": utilization_metrics['overall'],
                "team_utilization": utilization_metrics['by_team'],
                "individual_utilization": utilization_metrics['by_individual'],
                "capacity_analysis": self._analyze_capacity(issues),
                "bottleneck_analysis": self._identify_bottlenecks(issues),
                "optimization_opportunities": optimization_opportunities,
                "efficiency_score": self._calculate_team_efficiency(issues),
                "workload_distribution": self._analyze_workload_distribution(issues),
                "recommendations": self._generate_utilization_recommendations(utilization_metrics)
            }
            
        except Exception as e:
            return {"error": f"Resource utilization analysis failed: {str(e)}"}
    
    def assess_risk_impact(self, project_data: Dict) -> Dict[str, Any]:
        """Assess overall risk impact with predictive scoring"""
        try:
            issues = project_data.get('issues', [])
            
            # Calculate risk scores
            technical_risk = self._assess_technical_risk(issues)
            schedule_risk = self._assess_schedule_risk(issues)
            resource_risk = self._assess_resource_risk(issues)
            quality_risk = self._assess_quality_risk(issues)
            
            # Overall risk assessment
            overall_risk = self._calculate_overall_risk(technical_risk, schedule_risk, resource_risk, quality_risk)
            
            return {
                "overall_risk_score": overall_risk['score'],
                "risk_level": overall_risk['level'],
                "risk_breakdown": {
                    "technical": technical_risk,
                    "schedule": schedule_risk,
                    "resource": resource_risk,
                    "quality": quality_risk
                },
                "risk_trends": self._analyze_risk_trends(issues),
                "mitigation_priority": self._prioritize_mitigations(overall_risk),
                "risk_hotspots": self._identify_risk_hotspots(issues),
                "predictive_indicators": self._generate_risk_indicators(issues),
                "recommendations": self._generate_risk_recommendations(overall_risk)
            }
            
        except Exception as e:
            return {"error": f"Risk impact assessment failed: {str(e)}"}
    
    def analyze_speed_to_market(self, project_data: Dict) -> Dict[str, Any]:
        """Analyze speed to market with bug tracking correlation"""
        try:
            issues = project_data.get('issues', [])
            
            # Calculate speed metrics
            speed_metrics = self._calculate_speed_metrics(issues)
            
            # Analyze bug correlation
            bug_correlation = self._analyze_bug_correlation(issues)
            
            # Market readiness assessment
            market_readiness = self._assess_market_readiness(issues)
            
            return {
                "time_to_market": speed_metrics['time_to_market'],
                "development_velocity": speed_metrics['velocity'],
                "release_frequency": speed_metrics['release_frequency'],
                "bug_density": bug_correlation['density'],
                "quality_speed_tradeoff": bug_correlation['tradeoff'],
                "market_readiness_score": market_readiness['score'],
                "competitive_positioning": self._analyze_competitive_position(speed_metrics),
                "optimization_potential": self._identify_speed_optimizations(issues),
                "recommendations": self._generate_speed_recommendations(speed_metrics, bug_correlation)
            }
            
        except Exception as e:
            return {"error": f"Speed to market analysis failed: {str(e)}"}
    
    def evaluate_success_criteria(self, project_data: Dict) -> Dict[str, Any]:
        """Evaluate project success criteria with automated scoring"""
        try:
            issues = project_data.get('issues', [])
            
            # Define success criteria
            criteria = {
                "scope_completion": self._evaluate_scope_completion(issues),
                "quality_standards": self._evaluate_quality_standards(issues),
                "timeline_adherence": self._evaluate_timeline_adherence(issues),
                "budget_compliance": self._evaluate_budget_compliance(issues),
                "stakeholder_satisfaction": self._evaluate_stakeholder_satisfaction(issues),
                "team_performance": self._evaluate_team_performance(issues),
                "business_value": self._evaluate_business_value(issues),
                "technical_excellence": self._evaluate_technical_excellence(issues)
            }
            
            # Calculate overall success score
            success_score = self._calculate_success_score(criteria)
            
            return {
                "overall_success_score": success_score,
                "success_level": self._determine_success_level(success_score),
                "criteria_breakdown": criteria,
                "success_trends": self._analyze_success_trends(issues),
                "achievement_gaps": self._identify_achievement_gaps(criteria),
                "success_predictors": self._identify_success_predictors(issues),
                "recommendations": self._generate_success_recommendations(criteria)
            }
            
        except Exception as e:
            return {"error": f"Success criteria evaluation failed: {str(e)}"}
    
    def generate_predictive_analytics(self, project_data: Dict) -> Dict[str, Any]:
        """Generate predictive analytics and forecasts"""
        try:
            issues = project_data.get('issues', [])
            
            # Generate predictions using Monte Carlo simulation and advanced ML models  
            predictions = self.risk_predictor.predict_with_monte_carlo(issues)
            
            # Process real-time data update
            self.real_time_processor.process_project_update(
                project_data.get('key', 'UNKNOWN'), 
                project_data
            )
            
            # Trend analysis
            trends = self._analyze_predictive_trends(issues)
            
            # Risk forecasting
            risk_forecast = self._forecast_risks(issues)
            
            # Extract Monte Carlo simulation results
            completion_prob = predictions.get('completion_probability', {}).get('mean', 0.7)
            budget_overrun_prob = predictions.get('budget_overrun_risk', {}).get('mean', 0.3)
            timeline_variance = predictions.get('timeline_variance', {}).get('mean_days', 10)
            
            return {
                "completion_probability": completion_prob,
                "estimated_completion_date": self._calculate_completion_date(timeline_variance),
                "budget_overrun_probability": budget_overrun_prob,
                "quality_risk_forecast": risk_forecast.get('quality_risk', 0),
                "resource_shortage_risk": risk_forecast.get('resource_risk', 0),
                "trend_indicators": trends,
                "early_warning_signals": self._identify_warning_signals(issues),
                "monte_carlo_results": predictions,
                "ai_recommendations": predictions.get('ai_recommendations', []),
                "scenario_analysis": self._generate_scenarios(issues),
                "confidence_intervals": predictions.get('confidence_intervals', {}),
                "recommendations": self._generate_predictive_recommendations(predictions)
            }
            
        except Exception as e:
            return {"error": f"Predictive analytics failed: {str(e)}"}
    
    def _calculate_completion_date(self, timeline_variance_days: float) -> str:
        """Calculate estimated completion date based on timeline variance"""
        try:
            current_date = datetime.now()
            estimated_days = max(1, int(timeline_variance_days))
            completion_date = current_date + timedelta(days=estimated_days)
            return completion_date.strftime('%Y-%m-%d')
        except Exception:
            return (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
    
    # Helper methods for calculations
    def _calculate_risk_overview(self, issues: List[Dict]) -> Dict[str, Any]:
        """Calculate basic risk overview metrics"""
        total_issues = len(issues)
        if total_issues == 0:
            return {"total_issues": 0, "risk_score": 0}
        
        # Count issues by status
        status_counts = {}
        for issue in issues:
            status = issue.get('status', {}).get('name', 'Unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
        
        # Calculate basic risk indicators
        overdue_issues = sum(1 for issue in issues if self._is_overdue(issue))
        high_priority_issues = sum(1 for issue in issues if self._is_high_priority(issue))
        blocked_issues = sum(1 for issue in issues if self._is_blocked(issue))
        
        risk_score = (overdue_issues + high_priority_issues + blocked_issues) / total_issues
        
        return {
            "total_issues": total_issues,
            "status_distribution": status_counts,
            "overdue_issues": overdue_issues,
            "high_priority_issues": high_priority_issues,
            "blocked_issues": blocked_issues,
            "risk_score": risk_score
        }
    
    def _is_overdue(self, issue: Dict) -> bool:
        """Check if an issue is overdue"""
        due_date = issue.get('duedate')
        if not due_date:
            return False
        
        try:
            due_date_obj = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            return due_date_obj < datetime.now() and issue.get('status', {}).get('category') != 'Done'
        except:
            return False
    
    def _is_high_priority(self, issue: Dict) -> bool:
        """Check if an issue has high priority"""
        priority = issue.get('priority', {}).get('name', '').lower()
        return priority in ['high', 'highest', 'critical', 'blocker']
    
    def _is_blocked(self, issue: Dict) -> bool:
        """Check if an issue is blocked"""
        labels = issue.get('labels', [])
        return any('block' in label.lower() for label in labels)
    
    def _calculate_velocity(self, issues: List[Dict]) -> float:
        """Calculate team velocity based on completed story points"""
        completed_issues = [issue for issue in issues if issue.get('status', {}).get('category') == 'Done']
        if not completed_issues:
            return 0.0
        
        # Calculate velocity over time periods
        story_points = [issue.get('storypoints', 0) or 0 for issue in completed_issues]
        return sum(story_points) / len(set(self._get_sprint(issue) for issue in completed_issues if self._get_sprint(issue)))
    
    def _get_sprint(self, issue: Dict) -> str:
        """Extract sprint information from issue"""
        sprint_info = issue.get('sprint')
        if isinstance(sprint_info, list) and sprint_info:
            return sprint_info[-1].get('name', 'Unknown')
        return 'Unknown'
    
    def _estimate_cost_savings(self, issues: List[Dict]) -> float:
        """Estimate cost savings from project"""
        # Simplified calculation based on automation and efficiency gains
        automation_issues = [issue for issue in issues if 'automation' in issue.get('summary', '').lower()]
        return len(automation_issues) * 5000  # Estimated $5k savings per automation
    
    def _estimate_time_savings(self, issues: List[Dict]) -> float:
        """Estimate time savings in hours"""
        time_spent = sum(issue.get('timespent', 0) or 0 for issue in issues)
        return time_spent * 0.1  # 10% efficiency improvement estimate
    
    def _assess_team_satisfaction(self, issues: List[Dict]) -> float:
        """Assess team satisfaction based on work patterns"""
        # Analyze work distribution and completion patterns
        assignee_workload = {}
        for issue in issues:
            assignee = issue.get('assignee', {}).get('name', 'Unassigned')
            if assignee != 'Unassigned':
                assignee_workload[assignee] = assignee_workload.get(assignee, 0) + 1
        
        # Calculate satisfaction score based on workload distribution
        if not assignee_workload:
            return 0.5
        
        workloads = list(assignee_workload.values())
        workload_variance = statistics.variance(workloads) if len(workloads) > 1 else 0
        max_workload = max(workloads)
        
        # Lower variance and reasonable max workload indicate better satisfaction
        satisfaction_score = max(0, 1 - (workload_variance / (max_workload ** 2)))
        return min(1.0, satisfaction_score)
    
    def _assess_code_quality(self, issues: List[Dict]) -> float:
        """Assess code quality based on bug density and types"""
        total_issues = len(issues)
        if total_issues == 0:
            return 1.0
        
        bug_issues = [issue for issue in issues if issue.get('issuetype', {}).get('name', '').lower() == 'bug']
        bug_ratio = len(bug_issues) / total_issues
        
        # Higher bug ratio means lower quality
        quality_score = max(0, 1 - (bug_ratio * 2))  # Scale factor of 2
        return min(1.0, quality_score)
    
    def _assess_knowledge_transfer(self, issues: List[Dict]) -> float:
        """Assess knowledge transfer based on documentation and collaboration"""
        total_issues = len(issues)
        if total_issues == 0:
            return 0.5
        
        documented_issues = sum(1 for issue in issues if issue.get('description') and len(issue.get('description', '')) > 100)
        documentation_ratio = documented_issues / total_issues
        
        # Assess collaboration through assignee changes and comments
        collaborative_issues = sum(1 for issue in issues if self._has_collaboration_indicators(issue))
        collaboration_ratio = collaborative_issues / total_issues
        
        return (documentation_ratio + collaboration_ratio) / 2
    
    def _has_collaboration_indicators(self, issue: Dict) -> bool:
        """Check if issue has collaboration indicators"""
        # Look for multiple people involved, comments, etc.
        assignee = issue.get('assignee', {}).get('name')
        reporter = issue.get('reporter', {}).get('name')
        
        return assignee != reporter and assignee is not None and reporter is not None
    
    def _assess_process_improvement(self, issues: List[Dict]) -> float:
        """Assess process improvement based on cycle time trends"""
        # Analyze cycle times over time
        cycle_times = []
        for issue in issues:
            if issue.get('status', {}).get('category') == 'Done':
                created = issue.get('created')
                resolved = issue.get('resolutiondate')
                if created and resolved:
                    try:
                        created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
                        resolved_date = datetime.fromisoformat(resolved.replace('Z', '+00:00'))
                        cycle_time = (resolved_date - created_date).days
                        cycle_times.append(cycle_time)
                    except:
                        continue
        
        if len(cycle_times) < 2:
            return 0.5
        
        # Check if cycle times are improving (decreasing)
        first_half = cycle_times[:len(cycle_times)//2]
        second_half = cycle_times[len(cycle_times)//2:]
        
        avg_first = statistics.mean(first_half) if first_half else 0
        avg_second = statistics.mean(second_half) if second_half else 0
        
        if avg_first == 0:
            return 0.5
        
        improvement = (avg_first - avg_second) / avg_first
        return max(0, min(1, 0.5 + improvement))
    
    def _assess_stakeholder_confidence(self, issues: List[Dict]) -> float:
        """Assess stakeholder confidence based on delivery consistency"""
        total_issues = len(issues)
        if total_issues == 0:
            return 0.5
        
        # Analyze on-time delivery
        on_time_issues = sum(1 for issue in issues if self._is_delivered_on_time(issue))
        on_time_ratio = on_time_issues / total_issues
        
        # Analyze scope creep
        scope_changes = sum(1 for issue in issues if self._has_scope_changes(issue))
        scope_stability = 1 - (scope_changes / total_issues)
        
        return (on_time_ratio + scope_stability) / 2
    
    def _is_delivered_on_time(self, issue: Dict) -> bool:
        """Check if issue was delivered on time"""
        due_date = issue.get('duedate')
        resolved_date = issue.get('resolutiondate')
        
        if not due_date or not resolved_date:
            return True  # Assume on time if no dates
        
        try:
            due = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            resolved = datetime.fromisoformat(resolved_date.replace('Z', '+00:00'))
            return resolved <= due
        except:
            return True
    
    def _has_scope_changes(self, issue: Dict) -> bool:
        """Check if issue had scope changes"""
        labels = issue.get('labels', [])
        return any('scope' in label.lower() or 'change' in label.lower() for label in labels)
    
    def _calculate_benefit_score(self, tangible: Dict, intangible: Dict) -> float:
        """Calculate overall benefit score"""
        # Weight tangible benefits more heavily
        tangible_score = (
            min(tangible['completion_rate'] / 100, 1) * 0.3 +
            min(tangible['velocity'] / 10, 1) * 0.2 +
            min(tangible['cost_savings'] / 50000, 1) * 0.3 +
            min(tangible['time_saved'] / 1000, 1) * 0.2
        )
        
        intangible_score = (
            intangible['team_satisfaction'] * 0.2 +
            intangible['code_quality'] * 0.2 +
            intangible['knowledge_transfer'] * 0.2 +
            intangible['process_improvement'] * 0.2 +
            intangible['stakeholder_confidence'] * 0.2
        )
        
        return (tangible_score * 0.6 + intangible_score * 0.4)
    
    def _analyze_benefit_trend(self, issues: List[Dict]) -> str:
        """Analyze benefit trend over time"""
        # Simplified trend analysis
        recent_issues = [issue for issue in issues if self._is_recent(issue)]
        older_issues = [issue for issue in issues if not self._is_recent(issue)]
        
        if not recent_issues or not older_issues:
            return "stable"
        
        recent_completion = len([i for i in recent_issues if i.get('status', {}).get('category') == 'Done']) / len(recent_issues)
        older_completion = len([i for i in older_issues if i.get('status', {}).get('category') == 'Done']) / len(older_issues)
        
        if recent_completion > older_completion * 1.1:
            return "improving"
        elif recent_completion < older_completion * 0.9:
            return "declining"
        else:
            return "stable"
    
    def _is_recent(self, issue: Dict) -> bool:
        """Check if issue is recent (within last 30 days)"""
        created = issue.get('created')
        if not created:
            return False
        
        try:
            created_date = datetime.fromisoformat(created.replace('Z', '+00:00'))
            return (datetime.now() - created_date).days <= 30
        except:
            return False
    
    def _generate_benefit_recommendations(self, tangible: Dict, intangible: Dict) -> List[str]:
        """Generate recommendations for benefit improvement"""
        recommendations = []
        
        if tangible['completion_rate'] < 70:
            recommendations.append("Focus on improving completion rate through better sprint planning")
        
        if tangible['velocity'] < 5:
            recommendations.append("Consider team capacity planning and remove impediments to increase velocity")
        
        if intangible['team_satisfaction'] < 0.6:
            recommendations.append("Address workload distribution and team satisfaction issues")
        
        if intangible['code_quality'] < 0.7:
            recommendations.append("Implement more rigorous code review and testing practices")
        
        return recommendations
    
    # Additional helper methods would continue here...
    # For brevity, I'll include key methods and placeholder implementations for others
    
    def _count_committed_features(self, issues: List[Dict]) -> int:
        """Count committed features/stories"""
        return len([issue for issue in issues if issue.get('issuetype', {}).get('name', '').lower() in ['story', 'feature']])
    
    def _count_delivered_features(self, issues: List[Dict]) -> int:
        """Count delivered features/stories"""
        return len([
            issue for issue in issues 
            if issue.get('issuetype', {}).get('name', '').lower() in ['story', 'feature'] 
            and issue.get('status', {}).get('category') == 'Done'
        ])
    
    def _analyze_timeline_commitments(self, issues: List[Dict]) -> Dict:
        """Analyze timeline commitment performance"""
        return {
            "committed_deliveries": 0,
            "on_time_deliveries": 0,
            "performance_ratio": 0.0
        }
    
    def _analyze_quality_commitments(self, issues: List[Dict]) -> Dict:
        """Analyze quality commitment performance"""
        return {
            "quality_targets": 0,
            "quality_achievements": 0,
            "performance_ratio": 0.0
        }
    
    def _analyze_say_do_trend(self, issues: List[Dict]) -> str:
        """Analyze say-do trend"""
        return "stable"
    
    def _assess_say_do_risk(self, ratio: float) -> str:
        """Assess risk level based on say-do ratio"""
        if ratio >= 90:
            return "low"
        elif ratio >= 70:
            return "medium"
        else:
            return "high"
    
    def _generate_say_do_recommendations(self, ratio: float) -> List[str]:
        """Generate recommendations for say-do improvement"""
        if ratio < 70:
            return [
                "Improve estimation accuracy through historical data analysis",
                "Implement better scope management practices",
                "Enhance communication between stakeholders and delivery teams"
            ]
        return ["Continue current practices while monitoring for any decline"]
    
    # Placeholder implementations for remaining methods
    def _identify_dependencies(self, issues: List[Dict]) -> List[Dict]:
        return []
    
    def _analyze_critical_path(self, issues: List[Dict], dependencies: List[Dict]) -> List[Dict]:
        return []
    
    def _calculate_dependency_risk(self, dependencies: List[Dict]) -> float:
        return 0.3
    
    def _identify_blocking_issues(self, issues: List[Dict]) -> List[Dict]:
        return [issue for issue in issues if self._is_blocked(issue)]
    
    def _build_dependency_network(self, dependencies: List[Dict]) -> Dict:
        return {"nodes": [], "edges": []}
    
    def _generate_dependency_mitigation(self, dependencies: List[Dict]) -> List[str]:
        return ["Monitor dependencies closely", "Create contingency plans"]
    
    def _generate_dependency_recommendations(self, risk: float) -> List[str]:
        return ["Reduce external dependencies where possible"]
    
    def _calculate_overall_risk_score(self, results: Dict) -> float:
        """Calculate overall project risk score"""
        # Weight different risk factors
        weights = {
            'say_do_ratio': 0.15,
            'dependency_impact': 0.12,
            'cost_variance': 0.15,
            'timeline_variance': 0.15,
            'resource_variance': 0.13,
            'risk_impact': 0.15,
            'success_criteria': 0.15
        }
        
        score = 0.0
        for key, weight in weights.items():
            if key in results and isinstance(results[key], dict):
                # Extract risk score from each analysis
                if key == 'say_do_ratio':
                    ratio = results[key].get('overall_ratio', 100)
                    score += weight * (1 - min(ratio / 100, 1))
                elif 'risk_score' in results[key]:
                    score += weight * results[key]['risk_score']
                elif 'overall_risk_score' in results[key]:
                    score += weight * results[key]['overall_risk_score']
        
        return min(1.0, score)
    
    def _determine_risk_level(self, score: float) -> str:
        """Determine risk level from score"""
        if score < 0.3:
            return "low"
        elif score < 0.6:
            return "medium"
        elif score < 0.8:
            return "high"
        else:
            return "critical"
    
    # Continue with other placeholder implementations as needed...
    # (Additional methods would be implemented similarly)
    
    def _analyze_resource_spillover(self, issues): return {"risk_score": 0.2}
    def _analyze_timeline_spillover(self, issues): return {"risk_score": 0.3}
    def _analyze_scope_spillover(self, issues): return {"risk_score": 0.1}
    def _calculate_spillover_risk(self, r, t, s): return 0.25
    def _identify_affected_projects(self, issues): return []
    def _analyze_spillover_reasons(self, issues): return []
    def _calculate_spillover_magnitude(self, risk): return "medium"
    def _generate_spillover_mitigation(self, risk): return []
    def _generate_spillover_recommendations(self, risk): return []
    
    # Additional placeholder methods for remaining functionality...
    def _identify_idle_periods(self, issues): return []
    def _calculate_resource_idle_time(self, issues): return {}
    def _analyze_idle_patterns(self, periods): return {}
    def _calculate_idle_cost(self, idle_time): return 0
    def _calculate_efficiency_score(self, idle_time): return 0.8
    def _identify_peak_idle_times(self, periods): return []
    def _generate_idle_time_recommendations(self, idle_time): return []
    
    def _calculate_estimated_costs(self, issues): return {"total": 100000, "development": 60000, "testing": 25000, "deployment": 15000}
    def _calculate_actual_costs(self, issues): return {"total": 110000, "development": 70000, "testing": 25000, "deployment": 15000}
    def _calculate_cost_variance(self, est, act): return {"amount": 10000, "percentage": 10, "development": 10000, "testing": 0, "deployment": 0}
    def _analyze_cost_trends(self, issues): return []
    def _identify_cost_drivers(self, issues): return []
    def _generate_cost_recommendations(self, variance): return []
    
    def _calculate_estimated_timeline(self, issues): return {"total_days": 90}
    def _calculate_actual_timeline(self, issues): return {"total_days": 100}
    def _calculate_timeline_variance(self, est, act): return {"days": 10, "percentage": 11.1}
    def _analyze_milestone_variance(self, issues): return {}
    def _analyze_delays(self, issues): return {}
    def _identify_acceleration_opportunities(self, issues): return []
    def _analyze_timeline_trends(self, issues): return []
    def _analyze_critical_path_delays(self, issues): return []
    def _generate_timeline_recommendations(self, variance): return []
    
    def _calculate_estimated_resources(self, issues): return {"total_hours": 1000}
    def _calculate_actual_resources(self, issues): return {"total_hours": 1100}
    def _calculate_resource_variance(self, est, act): return {"hours": 100, "percentage": 10}
    def _analyze_resource_breakdown(self, issues): return {}
    def _analyze_skill_gaps(self, issues): return {}
    def _analyze_resource_allocation(self, issues): return {}
    def _calculate_productivity_metrics(self, issues): return {}
    def _generate_resource_recommendations(self, variance): return []
    
    def _calculate_utilization_metrics(self, issues): return {"overall": 0.8, "by_team": {}, "by_individual": {}}
    def _identify_optimization_opportunities(self, issues): return []
    def _analyze_capacity(self, issues): return {}
    def _identify_bottlenecks(self, issues): return []
    def _calculate_team_efficiency(self, issues): return 0.85
    def _analyze_workload_distribution(self, issues): return {}
    def _generate_utilization_recommendations(self, metrics): return []
    
    def _assess_technical_risk(self, issues): return {"score": 0.3, "level": "medium"}
    def _assess_schedule_risk(self, issues): return {"score": 0.4, "level": "medium"}
    def _assess_resource_risk(self, issues): return {"score": 0.2, "level": "low"}
    def _assess_quality_risk(self, issues): return {"score": 0.3, "level": "medium"}
    def _calculate_overall_risk(self, t, s, r, q): return {"score": 0.325, "level": "medium"}
    def _analyze_risk_trends(self, issues): return []
    def _prioritize_mitigations(self, risk): return []
    def _identify_risk_hotspots(self, issues): return []
    def _generate_risk_indicators(self, issues): return {}
    def _generate_risk_recommendations(self, risk): return []
    
    def _calculate_speed_metrics(self, issues): return {"time_to_market": 90, "velocity": 5, "release_frequency": 2}
    def _analyze_bug_correlation(self, issues): return {"density": 0.1, "tradeoff": "balanced"}
    def _assess_market_readiness(self, issues): return {"score": 0.8}
    def _analyze_competitive_position(self, metrics): return "strong"
    def _identify_speed_optimizations(self, issues): return []
    def _generate_speed_recommendations(self, speed, bugs): return []
    
    def _evaluate_scope_completion(self, issues): return 0.85
    def _evaluate_quality_standards(self, issues): return 0.80
    def _evaluate_timeline_adherence(self, issues): return 0.75
    def _evaluate_budget_compliance(self, issues): return 0.90
    def _evaluate_stakeholder_satisfaction(self, issues): return 0.85
    def _evaluate_team_performance(self, issues): return 0.80
    def _evaluate_business_value(self, issues): return 0.75
    def _evaluate_technical_excellence(self, issues): return 0.80
    def _calculate_success_score(self, criteria): return sum(criteria.values()) / len(criteria)
    def _determine_success_level(self, score): return "good" if score > 0.8 else "fair" if score > 0.6 else "poor"
    def _analyze_success_trends(self, issues): return []
    def _identify_achievement_gaps(self, criteria): return []
    def _identify_success_predictors(self, issues): return []
    def _generate_success_recommendations(self, criteria): return []
    
    def _analyze_predictive_trends(self, issues): return {}
    def _forecast_risks(self, issues): return {"quality_risk": 0.3, "resource_risk": 0.2}
    def _identify_warning_signals(self, issues): return []
    def _generate_scenarios(self, issues): return {}
    def _generate_predictive_recommendations(self, predictions): return []
